window.bookingConfig = {};
window.availabilityCheckStatus = "Pending";
window.csrfToken = "";
window.accessToken = "";
window.greq = "";
window.bmiyek = "";
window.clientTransactionId = "";
window.totalCollectibleAmount = 0;
window.autoRestartAttempts = 0;
window.lastSessionTime = null;
window.isBookingStopped = false;
window.isTatkalFlowActive = false;
window.paxAutoDelays = [];
let timeOffset = 19800000;


function buildAllPayloadTemplates() {
    const { trainNumber, journeyDateForAPI, fromStation, toStation, coach, apiQuota, passengers, boardingStation, mobileNumber, username, paymentMethod } = window.bookingConfig;

    // --- Template for fetchAvailability ---
    const availabilityPayload = {
        paymentFlag: "N",
        concessionBooking: false,
        ftBooking: false,
        loyaltyRedemptionBooking: false,
        ticketType: "E",
        quotaCode: apiQuota,
        moreThanOneDay: true,
        trainNumber,
        fromStnCode: fromStation,
        toStnCode: toStation,
        isLogedinReq: true,
        journeyDate: journeyDateForAPI,
        classCode: coach,
    };
    window.availabilityPayloadTemplate = JSON.stringify(availabilityPayload);

    // --- Template for fetchBoardingStation ---
    const boardingPayload = {
        clusterFlag: "N",
        onwardFlag: "N",
        cod: "false",
        reservationMode: "WS_TA_B2C",
        autoUpgradationSelected: false,
        gnToCkOpted: false,
        paymentType: 1,
        twoPhaseAuthRequired: false,
        captureAddress: 0,
        alternateAvlInputDTO: [{
            trainNo: trainNumber,
            destStn: toStation,
            srcStn: fromStation,
            jrnyDate: journeyDateForAPI,
            quotaCode: apiQuota,
            jrnyClass: coach,
            concessionPassengers: false
        }],
        passBooking: false,
        journalistBooking: false
    };
    window.boardingPayloadTemplate = JSON.stringify(boardingPayload);

    // --- Template for finalBookingHit ---
    const finalBookingPayload = {
        clusterFlag: "N",
        onwardFlag: "N",
        cod: "false",
        reservationMode: "WS_TA_B2C",
        autoUpgradationSelected: true,
        gnToCkOpted: false,
        paymentType: (["paytm", "irctcqr", "phonepay"].includes(paymentMethod) ? "2" : "3"),
        twoPhaseAuthRequired: false,
        captureAddress: 0,
        wsUserLogin: username,
        moreThanOneDay: false,
        clientTransactionId: window.clientTransactionId,
        boardingStation: boardingStation,
        reservationUptoStation: toStation,
        mobileNumber: mobileNumber,
        ticketType: "E",
        captcha: "",
        bookOnlyIfCnf: true,
        lapAvlRequestDTO: [{
            trainNo: trainNumber,
            journeyDate: journeyDateForAPI,
            fromStation: fromStation,
            toStation: toStation,
            journeyClass: coach,
            quota: apiQuota,
            passengerList: passengers,
            coachId: null,
            reservationChoice: "4",
            ignoreChoiceIfWl: true,
            travelInsuranceOpted: "false",
            warrentType: 0,
            coachPreferred: false,
            autoUpgradation: false,
            addMealInput: null,
            concessionBooking: false,
            ssQuotaSplitCoach: "N"
        }],
        mainJourneyTxnId: null,
        mainJourneyPnr: "",
        generalistChildConfirm: false,
        ftBooking: false,
        loyaltyRedemptionBooking: false,
        loyaltyBankId: null,
        loyaltyNumber: null,
        nosbBooking: false,
        warrentType: 0,
        ftTnCAgree: false,
        bookingChoice: 1,
        bookingConfirmChoice: 1,
        returnJourney: null,
        connectingJourney: false,
        gstDetails: { gstIn: "", error: null }
    };
    window.bookingPayloadTemplate = JSON.stringify(finalBookingPayload);
}

// -- Sensor Data Logic --

async function getSensorDataFromStorage() {
    try {
        const data = await new Promise( (resolve) => {
            chrome.storage.local.get(["sensorData"], (result) => resolve(result));
        }
        );
        if (data && data.sensorData) {
            return data.sensorData;
        }
        return "";
    } catch (error) {
        clog(`[Warmup] ERROR: Failed to get sensor_data from storage: ${error.message}`);
        return "";
    }
}

async function getWarmUpUrl() {
    const CACHE_KEY = "warmUpUrl";
    const CACHE_TS_KEY = "warmUpUrlTs";
    const ONE_DAY_MS = 24 * 60 * 60 * 1000;

    try {
        const cachedUrl = sessionStorage.getItem(CACHE_KEY);
        const cachedTs = parseInt(sessionStorage.getItem(CACHE_TS_KEY) || "0", 10);

        if (cachedUrl && (Date.now() - cachedTs < ONE_DAY_MS)) {
            return cachedUrl;
        }
        const response = await fetch("https://www.irctc.co.in/nget/train-search", {
            cache: "no-store"
        });
        if (!response.ok)
            throw new Error(`HTTP status ${response.status}`);

        const html = await response.text();
        const doc = new DOMParser().parseFromString(html, "text/html");

        const scriptUrls = Array.from(doc.querySelectorAll('script[type="text/javascript"][src]')).map(script => script.getAttribute('src')).filter(src => src && !src.startsWith('/nget/') && !src.includes('?'));

        if (scriptUrls.length === 0)
            throw new Error("No suitable script URLs found on the page.");
        const targetUrl = scriptUrls.reduce( (shortest, current) => current.length < shortest.length ? current : shortest);
        const fullUrl = new URL(targetUrl,"https://www.irctc.co.in").href;

        sessionStorage.setItem(CACHE_KEY, fullUrl);
        sessionStorage.setItem(CACHE_TS_KEY, Date.now().toString());
        return fullUrl;
    } catch (error) {
        clog(`[Warmup] ERROR: Could not get a warmup URL: ${error.message}`);
        return null;
    }
}

function warmUpPaymentGateway() {
    const urls = [
        "https://www.wps.irctc.co.in/eticketing/PaymentRedirect",
        "https://www.wps.irctc.co.in/eticketing/BankResponse"
    ];

    urls.forEach(url => {
        fetch(url, {
            method: "HEAD",
            mode: "cors",
            cache: "no-store"
        })
            .then(res => console.log(`[Warmup] ${url} responded with ${res.status}`))
            .catch(err => console.log(`[Warmup] ${url} failed: ${err.message}`))
    });
}

async function warmUpCaptchaSolver() {
    const paymentGatewayUrl = "https://api.apitruecaptcha.org/one/gettext";
    fetch(paymentGatewayUrl, {
        method: "HEAD",
        mode: "cors",
        cache: "no-store"
    }).then(res => clog(`[Warmup] Payment gateway warmup request: ${res.status}`)).catch(err => clog(`[Warmup] Payment gateway warmup request failed: ${err.message}`));
}

function runWarmups() {
    warmUpPaymentGateway();
    warmUpCaptchaSolver();
    preconnect("https://secure.paytmpayments.com");
    preconnect("https://www.irctcipay.com");
    preconnect("https://securehdfc-acs2ui-b1-indmum-mumsif.hdfcbank.com");
    preconnect("https://mercury-t2.phonepe.com");
    preconnect("https://api.phonepe.com");
}


async function warmUpConnection() {
    const targetUrl = await getWarmUpUrl();
    if (!targetUrl) {
        clog("[Warmup] Halting warmup: No target URL available.");
        return;
    }

    const sensorData = await getSensorDataFromStorage();
    if (!sensorData) {
        return;
    }

    try {
        fetch(targetUrl, {
            method: "POST",
            headers: {
                "Accept": "*/*",
                "Content-Type": "text/plain;charset=UTF-8",
                "Origin": "https://www.irctc.co.in",
                "Referer": "https://www.irctc.co.in/nget/train-search",
                "User-Agent": navigator.userAgent
            },
            body: JSON.stringify({
                sensor_data: sensorData
            }),
            credentials: "include",
            cache: "no-store"
        });
    } catch (error) {
        clog(`[Warmup] WARN: Decoy request failed. Error: ${error.message}`);
    }
}

// -- Sensor Data Logic End --

// This is called once at the start of a booking sequence.
function BookingUI() {
    const fromStation = els.fromStation.value.trim();
    const paymentMethod = els.paymentMethod.value; // Get payment method

    window.bookingConfig = {
        trainNumber: els.trainNumber.value.trim(),
        journeyDate: els.journeyDate.value.trim(),
        journeyDateForAPI: els.journeyDate.value.replace(/-/g, ""),
        fromStation: fromStation,
        toStation: els.toStation.value.trim(),
        coach: els.coach.value.trim(),
        quota: els.quota.value.trim(),
        apiQuota: (els.quota.value.trim() === "8AM") ? "GN" : els.quota.value.trim(),
        boardingStation: (els.boardingStation.value.trim() || fromStation).toUpperCase(),
        passengers: getPassengerList(),
        bookOnlyIfCnf: els.bookOnlyIfCnf.checked,
        paymentMethod: paymentMethod,
        mobileNumber: els.mobileNumber.value.trim(),
        username: els.username.value.trim(),
        maxFare: els.maxFare.value.trim(),
    };

    if (paymentMethod === 'debitcard') {
        const [expiryMonth, expiryYear] = els.cardExpiry.value.split('/');
        window.bookingConfig.cardDetails = {
            number: els.cardNumber.value.replace(/\s/g, ''),
            expiryMonth: expiryMonth,
            expiryYear: `20${expiryYear}`,
            cvv: els.cardCvv.value.trim(),
            holderName: els.cardHolderName.value.trim(),
            staticPassword: els.staticPassword.value.trim()
        };
    }
}

// Helper function to centralize CSRF token updates from fetch responses.
function CSRFTokenResponse(response) {
    const newCsrfToken = response.headers.get("csrf-token");
    if (newCsrfToken && newCsrfToken !== window.csrfToken) {
        window.csrfToken = newCsrfToken;
        chrome.storage.local.set({
            csrfToken: newCsrfToken
        });
    }
}


// Encrypt the login payload
async function encryptLoginData(captcha, uid, timestamp, username, password) {
    const keyString = (captcha + uid + "AAAAAAAAAAAAAAAA").substring(0, 16);
    const encoder = new TextEncoder();
    const iv = encoder.encode(keyString);
    const key = await crypto.subtle.importKey("raw", iv, {
        name: "AES-CBC"
    }, false, ["encrypt"]);

    const encodedPassword = btoa(password);
    const plainText = `${username}#UP#${encodedPassword}#UP#${timestamp}`;
    let dataToEncrypt = encoder.encode(plainText);
    const padding = 16 - (dataToEncrypt.length % 16);
    const paddedData = new Uint8Array(dataToEncrypt.length + padding);
    paddedData.set(dataToEncrypt);
    paddedData.fill(padding, dataToEncrypt.length);

    const encryptedBuffer = await crypto.subtle.encrypt({
        name: "AES-CBC",
        iv
    }, key, paddedData);
    return arrayBufferToBase64(encryptedBuffer);
}

function arrayBufferToBase64(buffer) {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    for (let i = 0; i < bytes.byteLength; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

async function solveCaptcha(imageBase64) {
    const payload = JSON.stringify({
        userid: "amankrmishra",
        apikey: "XIkzbwSijmqpJP2EU1FH",
        data: imageBase64.replace(/^data:image\/\w+;base64,/, "")
    });

    const controller = new AbortController();
    const timeoutId = setTimeout( () => {
        controller.abort();
        clog("[Captcha Solver] Captcha API request timed out after 10 seconds.");
    }
    , 10000);

    try {
        const response = await fetch("https://api.apitruecaptcha.org/one/gettext", {
            method: "POST",
            body: payload,
            cache: "no-store",
            signal: controller.signal
        });
        clearTimeout(timeoutId);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        const data = await response.json();
        if (data.success && data.result) {
            const solution = data.result.trim();
            clog(`CAPTCHA Solved: ${solution}`);
            return solution;
        } else {
            throw new Error(data.error || "Unknown error from captcha API");
        }
    } catch (error) {
        clearTimeout(timeoutId);
        if (error.name === "AbortError") {
            throw new Error("Captcha API request timed out");
        }
        clog(`Error solving captcha: ${error.message}`);
        throw error;
    }
}


function getCurrentISTTime() {
    return new Date(Date.now() + timeOffset);
}

function isACCoachClass(coachCode) {
    return ["1A", "2A", "3A", "CC", "EC", "3E"].includes(coachCode.toUpperCase());
}

async function CountdownDelay(seconds, callback) {
    const startTime = performance.now();
    const totalDelayMs = seconds * 1000;

    function animateCountdown(currentTime) {
        if (window.isBookingStopped) {
            clog("[Delay Timer] Booking stopped. Countdown cancelled.");
            ui.hideLoading();
            return;
        }
        const elapsedTime = currentTime - startTime;
        const remainingTimeMs = Math.max(totalDelayMs - elapsedTime, 0);

        if (remainingTimeMs <= 0) {
            ui.hideLoading();
            clog("[Delay Timer] Countdown finished successfully.");
            callback();
            return;
        }

        const remainingSec = Math.floor(remainingTimeMs / 1000);
        const remainingMs = String(Math.floor(remainingTimeMs % 1000)).padStart(3, "0");
        ui.showLoading(`Submitting in ${seconds} sec. : <b>${remainingSec}s ${remainingMs} ms</b>`);
        requestAnimationFrame(animateCountdown);
    }
    requestAnimationFrame(animateCountdown);
}

async function showReverseCountdownTimer(targetDate, type="auto", quota="GN") {
    return new Promise( (resolve) => {
        if (window.isBookingStopped) {
            return resolve();
        }

        const targetTime = targetDate.getTime();
        if (targetTime - Date.now() <= 0) {
            clog("[Reverse Timer] Target time has already passed. Proceeding immediately.");
            return resolve();
        }

        let messagePrefix = "Countdown";
        if (type === "tatkal") {
            const coachClass = isACCoachClass(window.bookingConfig.coach) ? "AC" : "SL";
            messagePrefix = `Tatkal Booking (${coachClass}) opening`;
        } else if (type === "8AM") {
            messagePrefix = `Get Ready To Book Opening Ticket`;
        }

        function animateCountdown() {
            if (window.isBookingStopped) {
                clog("[Reverse Timer] Booking stopped during countdown. Cancelling wait.");
                ui.hideLoading();
                return resolve();
            }

            const now = Date.now();
            const timeRemainingMs = Math.max(targetTime - now, 0);

            if (timeRemainingMs <= 0) {
                clog("[Reverse Timer] Target time reached, resolving promise.");
                return resolve();
            }

            const totalSecondsRemaining = Math.floor(timeRemainingMs / 1000);
            const hours = Math.floor(totalSecondsRemaining / 3600);
            const minutes = Math.floor((totalSecondsRemaining % 3600) / 60);
            const seconds = totalSecondsRemaining % 60;
            const milliseconds = String(timeRemainingMs % 1000).padStart(3, '0');

            let timeString;
            if (hours > 0) {
                timeString = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
            } else {
                timeString = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${milliseconds}`;
            }
            ui.showLoading(`${messagePrefix} in:<br><b>${timeString}</b>`);

            requestAnimationFrame(animateCountdown);
        }

        requestAnimationFrame(animateCountdown);
    }
    );
}

function validateCurrentSession() {
    const tenMinutes = 6 * 60 * 1000;
    if (!window.accessToken || !window.csrfToken || !window.greq || !window.bmiyek) {
        clearSessionData();
        return false;
    }
    if (!window.lastSessionTime || (Date.now() - window.lastSessionTime >= tenMinutes)) {
        clearSessionData();
        return false;
    }
    return true;
}

function GenerateTransactionId() {
    const getRandomChar = (chars) => chars[Math.floor(Math.random() * chars.length)];

    const id = 'mb' + getRandomChar('0123456789') + getRandomChar('abcdef') + getRandomChar('ABCDEFGHIJKLMNOPQRSTUVWXYZ') + getRandomChar('ABCDEFGHIJKLMNOPQRSTUVWXYZ') + getRandomChar('0123456789') + getRandomChar('abcdef');

    window.clientTransactionId = id;
    clog(`[Transaction ID] Generated new client transaction ID: ${id}.`);
    return id;
}

async function MainFlow() {
    ui.hideLoading();
    ui.hideMessage();
    if (window.isBookingStopped) {
        return false;
    }

    const {quota, coach} = window.bookingConfig;
    const isSpecialQuota = ["TQ", "PT", "8AM"].includes(quota);

    if (isSpecialQuota) {
        window.isTatkalFlowActive = true;
        clog("[Orchestrator] Tatkal flow detected!");
    }

    const nowLocal = new Date();

    let targetTime = null;
    if (quota === "TQ" || quota === "PT") {
        const journeyDateStr = window.bookingConfig.journeyDate;
        const [year,month,day] = journeyDateStr.split('-').map(Number);

        const journeyDateUTC = new Date(Date.UTC(year, month - 1, day));
        journeyDateUTC.setUTCDate(journeyDateUTC.getUTCDate() - 1);

        const bookingYear = journeyDateUTC.getUTCFullYear();
        const bookingMonth = String(journeyDateUTC.getUTCMonth() + 1).padStart(2, '0');
        const bookingDay = String(journeyDateUTC.getUTCDate()).padStart(2, '0');

        const isAC = isACCoachClass(coach);
        const targetHourIST = isAC ? "09" : "10";
        const targetTimeStrIST = `${bookingYear}-${bookingMonth}-${bookingDay}T${targetHourIST}:59:58.000+05:30`;

        targetTime = new Date(targetTimeStrIST);
        clog(`[Orchestrator] Tatkal countdown set to: ${targetTime.toLocaleString()} (IST: ${targetTimeStrIST})`);

    } else if (quota === "8AM") {
        const journeyDateStr = window.bookingConfig.journeyDate;
        const targetTimeStrIST = `${journeyDateStr}T07:59:58.000+05:30`;
        targetTime = new Date(targetTimeStrIST);
        clog(`[Orchestrator] 8AM countdown set to: ${targetTime.toLocaleString()} (IST: ${targetTimeStrIST})`);
    }

    if (targetTime && nowLocal < targetTime) {
        await showReverseCountdownTimer(targetTime, quota === "8AM" ? "8AM" : "tatkal", quota);

        if (window.isBookingStopped) {
            clog("[Orchestrator] Booking stopped during countdown. Halting.");
            return false;
        }
        clog("[Orchestrator] Proceeding to availability check immediately.");
    }

    let finalAvailabilityResult = null;
    const maxPollAttempts = isSpecialQuota ? 40 : 1;
    const pollInterval = isSpecialQuota ? 450 : 0;
    for (let attempt = 1; attempt <= maxPollAttempts; attempt++) {
        if (window.isBookingStopped) {
            clog("[Orchestrator] Booking stopped during availability polling.");
            return false;
        }
        ui.showLoading(`Checking Availability...`);
        const availability = await fetchAvailability();
        if (!availability) {
            clog("[Orchestrator] Availability fetch failed on attempt " + attempt);
            if (attempt < maxPollAttempts)
                await new Promise(r => setTimeout(r, pollInterval + 200));
            continue;
        }

        const currentDayAvailability = availability.avlDayList.find(item => {
            const [day,month,year] = item.availablityDate.split('-');
            const [jYear,jMonth,jDay] = window.bookingConfig.journeyDate.split('-');
            return parseInt(day) === parseInt(jDay) && parseInt(month) === parseInt(jMonth) && parseInt(year) === parseInt(jYear);
        }
        );

        if (currentDayAvailability) {
            const status = currentDayAvailability.availablityStatus.toUpperCase();
            const reasonType = currentDayAvailability.reasonType;
            if (status.includes('NOT AVAILABLE') || status.includes('REGRET') || status.includes('DEPARTED')) {
                ui.showMessage(`ERROR: Train not available. Status: ${status}`, "error", 0);
                return false;
            }

            if ((isSpecialQuota && (reasonType === "S" || status.includes('AVL'))) || !isSpecialQuota) {
                if (!isSpecialQuota && status.includes('WL') && window.bookingConfig.bookOnlyIfCnf) {
                    ui.showMessage(`Train is waitlisted (${status}) and "Book Only if Confirmed" is selected.`, "error", 0);
                    return false;
                }
                finalAvailabilityResult = availability;
                break;
            }
        } else {
            clog(`[Orchestrator] No availability data for the journey date in attempt ${attempt}.`);
        }

        if (attempt < maxPollAttempts) {
            await new Promise(r => setTimeout(r, pollInterval));
        }
    }

    if (!finalAvailabilityResult) {
        ui.showMessage("Could not find suitable availability after polling. Please try again.", "error", 0);
        return false;
    }
    const boardingData = await fetchBoardingStation();
    if (!boardingData) {
        clog("[Orchestrator] Boarding station data fetch failed.");
        return false;
    }

    let paxDelaySeconds;
    const selectedPaxDelay = els.paxDelay.value;

    if (selectedPaxDelay === "auto") {
        clog("[Orchestrator] PAX Delay set to 'Auto'. Using dynamic calculation.");
        const passengersCount = window.bookingConfig.passengers.length;
        if (Array.isArray(window.paxAutoDelays) && window.paxAutoDelays.length > 0 && passengersCount > 0) {
            const delayIndex = Math.min(passengersCount - 1, window.paxAutoDelays.length - 1);
            paxDelaySeconds = window.paxAutoDelays[delayIndex];
            clog(`[Orchestrator] Using API-provided auto passenger delay: ${paxDelaySeconds}s for ${passengersCount} passengers.`);
        } else {
            const nowIST = new Date(new Date().getTime() + timeOffset);
            const currentMinutesOfDay = nowIST.getUTCHours() * 60 + nowIST.getUTCMinutes();
            const isPeakTime = (currentMinutesOfDay >= 460 && currentMinutesOfDay < 720);
            paxDelaySeconds = isPeakTime ? 35 : 5.5;
            clog(`[Orchestrator] Using default auto passenger delay (${isPeakTime ? "peak" : "off-peak"}): ${paxDelaySeconds}s.`);
        }
    } else {
        paxDelaySeconds = parseInt(selectedPaxDelay, 10);
    }

    await CountdownDelay(paxDelaySeconds, async () => {
        if (window.isBookingStopped) {
            clog("Booking stopped during passenger delay.");
            return;
        }
        const preBookingResult = await finalBookingHit();
        if (!preBookingResult) {
            return;
        }

        let captchaHandled = true;
        if (typeof preBookingResult === 'object' && preBookingResult.captcha) {
            captchaHandled = await handleBookingCaptcha(preBookingResult.captcha);
        }
        if (!captchaHandled) {
            return;
        }

        if (window.totalCollectibleAmount > 0) {
            ui.showMessage("Starting Final HIT for Payment.", "success");
            await initiatePaymentProcess(window.totalCollectibleAmount);
        } else {
            ui.showMessage("Could not determine total collectible amount for payment. Stopping.", "error", 0);
        }
    }
    );
    return true;
}

// 1. Retrieves the login captcha image and necessary tokens.
async function retrieveCaptcha(username, password) {
    let attempts = 0;
    const maxAttempts = 1;

    while (attempts < maxAttempts) {
        attempts++;
        if (window.isBookingStopped)
            return false;

        ui.showLoading(`Fetching captcha (Attempt ${attempts}/${maxAttempts})`);
        const controller = new AbortController();
        const timeoutId = setTimeout( () => {
            controller.abort();
        }
        , 10000);

        try {
            const response = await fetch("https://www.irctc.co.in/eticketing/protected/mapps1/loginCaptcha", {
                method: "GET",
                headers: {
                    "greq": "1752764050970",
                    "bmirak": "webbm",
                    "Content-Type": "application/json",
                    "Origin": "https://www.irctc.co.in",
                    "Referer": "https://www.irctc.co.in/nget/payment/bkgPaymentOptions",
                    "Accept-Encoding": "br, gzip, deflate"
                },
                credentials: "include",
                cache: "no-store",
                signal: controller.signal
            });
            clearTimeout(timeoutId);

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            const data = await response.json();

            if (ui.processErrorMsg(data))
                return false;

            window.greq = data.status;
            const captchaImageBase64 = `data:image/png;base64,${data.captchaQuestion}`;
            const captchaSolution = await solveCaptcha(captchaImageBase64);
            await new Promise(resolve => setTimeout(resolve, 1099)); // Important
            const loginResult = await loginOperation(captchaSolution, data.status, data.timeStamp, username, password);
            if (loginResult) {
                return true;
            }
            clog("[API Login] Retrying login due to captcha/retryable error.");
        } catch (error) {
            clearTimeout(timeoutId);
            if (error.name === "AbortError") {
                throw new Error("Captcha request timed out");
            }
            clog(`❌ Captcha retrieval/solving failed on attempt ${attempts}: ${error.message}`);
            if (attempts >= maxAttempts) {
                ui.showMessage("Failed to solve captcha after maximum attempts.", "error", 0);
                return false;
            }
        }
    }

    return false;
}

// 2. Submits login credentials and captcha solution.
async function loginOperation(captchaSolution, uid, timestamp, username, password) {
    if (window.isBookingStopped)
        return false;

    ui.showLoading("Verifying credentials...");

    const encryptedData = await encryptLoginData(captchaSolution, uid, timestamp, username, password);

    const postData = new URLSearchParams({
        grant_type: "password",
        data: encryptedData,
        captcha: captchaSolution,
        uid: uid,
        otpLogin: "false",
        lso: "",
        encodedPwd: "true"
    }).toString();

    const headers = {
        "bmirak": "webbm",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.52",
        "Content-Type": "application/x-www-form-urlencoded",
        "Origin": "https://www.irctc.co.in",
        "Referer": "https://www.irctc.co.in/nget/payment/bkgPaymentOptions",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "Accept-Encoding": "gzip, deflate, br"
    };

    try {
        const response = await fetch("https://www.irctc.co.in/authprovider/webtoken", {
            method: "POST",
            headers,
            body: postData,
            credentials: "include",
            cache: "no-store"
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        const data = await response.json();

        const errorDescription = data.error_description || "";

        if (errorDescription.toLowerCase().includes("invalid captcha")) {
            clog("Login failed: Invalid Captcha. Signaling for retry.");
            return false;
        }

        if (ui.processErrorMsg(data))
            return false;

        if (data.token_type === "bearer" && data.access_token) {
            window.accessToken = data.access_token;
            window.bmiyek = data.refresh_token || window.bmiyek;
            clog("Login Operation Successful. Tokens captured.");
            return true;
        }

        clog(`❌ Login operation failed: ${JSON.stringify(data)}`);
        return false;
    } catch (error) {
        clog(`❌ Fetch error during login operation: ${error.message}`);
        ui.showMessage("A network error occurred during login.", "error", 0);
        return false;
    }
}

// 3. Validates the newly acquired user session.
async function validateUser() {
    clog("[API Login] 3. Validating user session...");
    if (window.isBookingStopped || !window.accessToken)
        return false;
    ui.showLoading("Finalizing session...");

    try {
        const response = await fetch("https://www.irctc.co.in/eticketing/protected/mapps1/validateUser?source=3", {
            method: "GET",
            headers: {
                greq: window.greq,
                bmiyek: window.bmiyek,
                "Origin": "https://www.irctc.co.in",
                "Referer": "https://www.irctc.co.in/nget/payment/bkgPaymentOptions",
                "spa-csrf-token": "1752764050974",
                Authorization: `Bearer ${window.accessToken}`,
                "Accept-Encoding": "br, gzip, deflate"
            },
            credentials: "include",
            cache: "no-store"
        });

        CSRFTokenResponse(response);

        if (response.status === 401) {
            clearSessionData();
            ui.showMessage("Session unauthorized. Please try logging in again.", "error", 0);
            return false;
        }

        const userInfo = await response.json();
        if (ui.processErrorMsg(userInfo)) {
            return false;
        }

        window.lastSessionTime = Date.now();
        saveFormData();
        clog("✅✅✅ User Validation Successful! Welcome, " + userInfo.firstName);
        return true;
    } catch (error) {
        clog(`❌ Fetch error during validateUser: ${error.message}`);
        ui.showMessage("A network error occurred during session validation.", "error", 0);
        return false;
    }
}

// Fetches availability and fare information for a given train and route.
async function fetchAvailability() {
    await warmUpConnection();
    if (!validateMainFormFields() || !validateCurrentSession()) {
        return false;
    }

    const { trainNumber, journeyDateForAPI, fromStation, toStation, coach, apiQuota } = window.bookingConfig;

    const apiUrl = `https://www.irctc.co.in/eticketing/protected/mapps1/avlFarenquiry/${trainNumber}/${journeyDateForAPI}/${fromStation}/${toStation}/${coach}/${apiQuota}/N`;
    const headers = {
        "Accept": "application/json, text/plain, */*",
        "Content-Type": "application/json; charset=UTF-8",
        "cache": "no-store",
        "greq": window.greq,
        "Authorization": `Bearer ${window.accessToken}`,
        "bmirak": "webbm",
        "bmiyek": window.bmiyek,
        "Spa-Csrf-Token": window.csrfToken,
        "Origin": "https://www.irctc.co.in",
        "Referer": "https://www.irctc.co.in/nget/payment/bkgPaymentOptions",
    };

    try {
        const response = await fetch(apiUrl, {
            method: "POST",
            headers,
            credentials: "include",
            body: window.availabilityPayloadTemplate,
            cache: "no-store"
        });

        CSRFTokenResponse(response);

        if (response.status >= 400) {
            const errorMap = {
                401: "Session expired or unauthorized. Please re-login.",
                403: "IP Address blocked temporarily. Please try again later or change IP.",
                409: "Conflict detected (e.g., multiple logins/sessions).",
                503: "IRCTC Server Issues (503). Server is currently unavailable. Please retry.",
                510: "Account/Profile rate-limited or Fingerprint Issues. Consider changing browser profile or account."
            };
            const msg = errorMap[response.status] || `Availability check failed: HTTP ${response.status}`;
            ui.showMessage(msg, "error");
            if (response.status === 401) clearSessionData();
            return false;
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder("utf-8");
        let buffer = "";
        let result = {};

        while (true) {
            const { value, done } = await reader.read();
            if (value) buffer += decoder.decode(value, { stream: true });
            if (done) break;

            // Extract required fields
            if (!result.trainName && /"trainName"\s*:\s*"/.test(buffer)) {
                const match = buffer.match(/"trainName"\s*:\s*"([^"]+)"/);
                if (match) result.trainName = match[1];
            }
            if (!result.totalFare && /"totalFare"\s*:\s*"?[\d.]+/.test(buffer)) {
                const match = buffer.match(/"totalFare"\s*:\s*"?(.*?)"?(,|\})/);
                if (match) result.totalFare = parseFloat(match[1]);
            }
            if (!result.totalCollectibleAmount && /"totalCollectibleAmount"\s*:\s*"?(.*?)"?(,|\})/.test(buffer)) {
                const match = buffer.match(/"totalCollectibleAmount"\s*:\s*"?(.*?)"?(,|\})/);
                if (match) result.totalCollectibleAmount = parseFloat(match[1]);
            }
            if (!result.avlDayList && /"avlDayList"\s*:\s*\[/.test(buffer)) {
                const match = buffer.match(/"avlDayList"\s*:\s*(\[[\s\S]+?\])(?:,|\})/);
                if (match) {
                    try {
                        result.avlDayList = JSON.parse(match[1]);
                    } catch (e) {
                        clog("Failed to parse avlDayList: " + e.message);
                    }
                }
            }

            // Optional: Fast exit if all found
            if (result.trainName && result.totalFare && result.totalCollectibleAmount && result.avlDayList) {
                break;
            }
        }

        if (!result.avlDayList || !Array.isArray(result.avlDayList)) {
            ui.showMessage("Could not determine availability.", "error");
            return false;
        }

        // Final assignment
        window.lastAvailabilityResponse = result;
        return result;

    } catch (error) {
        clog(`[API] Availability & Fare: Fetch error: ${error.message}`);
        ui.showMessage("Network error during availability check.", "error");
        return false;
    }
}

// Fetches boarding station details and passenger delay information.
async function fetchBoardingStation() {
    await warmUpConnection();
    if (!validateCurrentSession()) {
        ui.showMessage("Session invalid. Please re-login.", "error");
        return null;
    }

    const { boardingStation } = window.bookingConfig;
    const apiUrl = "https://www.irctc.co.in/eticketing/protected/mapps1/boardingStationEnq";
    const maxAttempts = 10;
    const retryDelay = 5500;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        if (window.isBookingStopped) return null;
        ui.showLoading(`Filling Passenger Details..`);

        const headers = {
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json; charset=UTF-8",
            "cache": "no-store",
            "greq": window.greq,
            "Authorization": `Bearer ${window.accessToken}`,
            "bmirak": "webbm",
            "bmiyek": window.bmiyek,
            "Spa-Csrf-Token": window.csrfToken,
            "Origin": "https://www.irctc.co.in",
            "Referer": "https://www.irctc.co.in/nget/payment/bkgPaymentOptions",
        };

        try {
            const response = await fetch(apiUrl, {
                method: "POST",
                headers,
                credentials: "include",
                body: window.boardingPayloadTemplate,
                cache: "no-store"
            });

            CSRFTokenResponse(response);

            if (!response.ok) {
                const status = response.status;
                const errorText = await response.text();
                const retryableStatuses = [401, 403, 409, 503, 510];
                if (retryableStatuses.includes(status) && attempt < maxAttempts) {
                    ui.showLoading(`Server error (${status}). Retrying in ${retryDelay / 1000}s...`);
                    await new Promise(r => setTimeout(r, retryDelay));
                    continue;
                }
                ui.showMessage(`Boarding station enquiry failed: ${errorText.substring(0, 100)}`, "error");
                if (status === 401) clearSessionData();
                ui.hideLoading();
                return null;
            }

            // ✅ Stream parse begins
            const reader = response.body.getReader();
            const decoder = new TextDecoder("utf-8");

            let buffer = "";
            let done = false;
            let minPsgnInputTime = null;
            let boardingStationList = null;

            while (!done) {
                const { value, done: doneReading } = await reader.read();
                if (value) buffer += decoder.decode(value, { stream: true });
                done = doneReading;

                // ✅ Extract minPsgnInputTime
                if (!minPsgnInputTime) {
                    const matchMin = buffer.match(/"minPsgnInputTime"\s*:\s*"([^"]+)"/);
                    if (matchMin) {
                        minPsgnInputTime = matchMin[1];
                        try {
                            window.paxAutoDelays = minPsgnInputTime.split("#").map(e => parseInt(e, 10) / 1000);
                            clog(`Auto passenger delays: [${window.paxAutoDelays.join(", ")}]s.`);
                        } catch (e) {
                            clog(`Parse error: minPsgnInputTime → ${e.message}`);
                            window.paxAutoDelays = [];
                        }
                    }
                }

                // ✅ Extract boardingStationList
                if (!boardingStationList) {
                    const matchBoarding = buffer.match(/"boardingStationList"\s*:\s*(\[\{.*?\}\])/s);
                    if (matchBoarding) {
                        try {
                            boardingStationList = JSON.parse(matchBoarding[1]);
                        } catch (e) {
                            clog(`Parse error: boardingStationList → ${e.message}`);
                        }
                    }
                }

                if (minPsgnInputTime && boardingStationList) break;
            }

            // ✅ Validate boarding station match
            const isValid = boardingStationList?.some(item =>
                (item.stnNameCode.split('-')[1] || '').trim().toUpperCase() === boardingStation
            );

            if (!isValid) {
                ui.showMessage("Boarding Station Is Incorrect for this route. Please verify.", "error", 0);
                ui.hideLoading();
                return null;
            }

            clog("Boarding Station: Successfully fetched via stream.");
            ui.hideLoading();

            return {
                minPsgnInputTime,
                boardingStationList
            };

        } catch (error) {
            if (attempt < maxAttempts) {
                ui.showLoading(`Network error. Retrying in ${retryDelay / 1000}s...`);
                await new Promise(r => setTimeout(r, retryDelay));
                continue;
            }
            ui.showMessage("Network error during boarding station enquiry.", "error");
            ui.hideLoading();
            return null;
        }
    }

    clog("[API] Boarding Station: All retry attempts failed.");
    ui.hideLoading();
    return null;
}


async function finalBookingHit() {
    await warmUpConnection();
    if (!validateMainFormFields() || !validateCurrentSession()) {
        clog("[API] Pre-Booking: Form fields or session invalid.");
        return false;
    }

    const apiUrl = "https://www.irctc.co.in/eticketing/protected/mapps1/allLapAvlFareEnq/Y";
    const maxAttempts = 3;
    const retryDelay = 4500;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        if (window.isBookingStopped) return false;

        ui.showLoading(`Connecting to Payment Server...(Attempt ${attempt}/${maxAttempts})`);

        const headers = {
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json; charset=UTF-8",
            "cache": "no-store",
            "greq": window.greq,
            "Authorization": `Bearer ${window.accessToken}`,
            "bmirak": "webbm",
            "bmiyek": window.bmiyek,
            "Spa-Csrf-Token": window.csrfToken,
            "Origin": "https://www.irctc.co.in",
            "Referer": "https://www.irctc.co.in/nget/payment/bkgPaymentOptions",
        };

        try {
            const response = await fetch(apiUrl, {
                method: "POST",
                headers,
                body: window.bookingPayloadTemplate,
                credentials: "include",
                cache: "no-store"
            });

            CSRFTokenResponse(response);

            if (!response.ok) {
                const status = response.status;
                const errText = await response.text();
                const errorMessages = {
                    401: "Session expired or unauthorized. Please re-login.",
                    403: "IP Address blocked temporarily. Please try again later or change IP.",
                    409: "Conflict detected (e.g., multiple logins/sessions).",
                    510: "Account/Profile rate-limited or Fingerprint Issues. Consider changing browser profile or account.",
                    503: "IRCTC Server Issues (503). Server is currently unavailable. Please retry."
                };
                if (errorMessages[status]) {
                    ui.showMessage(errorMessages[status], "error", 0);
                    if (status === 401) clearSessionData();
                } else {
                    ui.showMessage(`Pre-booking check failed: ${errText.substring(0, 200)}`, "error", 0);
                }
                ui.hideLoading();
                return false;
            }

            const reader = response.body.getReader();
const decoder = new TextDecoder("utf-8");

let buffer = "";
let totalCollectibleAmount = 0;
let captchaDto = null;
let done = false;

while (!done) {
    const { value, done: doneReading } = await reader.read();
    if (value) buffer += decoder.decode(value, { stream: true });
    done = doneReading;

    // ✅ Extract totalCollectibleAmount (quoted string OR number)
    if (!totalCollectibleAmount) {
        const matchTotal = buffer.match(/"totalCollectibleAmount"\s*:\s*"?([\d.]+)"?/);
        if (matchTotal) {
            totalCollectibleAmount = parseFloat(matchTotal[1]);
        }
    }

    // ✅ Extract captchaDto (object as JSON string)
    if (!captchaDto) {
        const matchCaptcha = buffer.match(/"captchaDto"\s*:\s*(\{.*?\})(,|\s*})/s);
        if (matchCaptcha) {
            try {
                captchaDto = JSON.parse(matchCaptcha[1]);
            } catch (e) {
                clog(`[Parse Error] Captcha DTO malformed: ${e.message}`);
            }
        }
    }

    // 🎯 Stop early when both fields are found
    if (captchaDto && totalCollectibleAmount) break;
}

            window.totalCollectibleAmount = totalCollectibleAmount;
            ui.hideLoading();

            if (captchaDto) {
                return { captcha: captchaDto };
            }

            return totalCollectibleAmount > 0;

        } catch (error) {
            const status = error.status || 0;
            const retryable = [401, 403, 409, 503, 510];

            clog(`[Booking] Attempt ${attempt} failed: ${error.message}`);

            if ((retryable.includes(status) || !status) && attempt < maxAttempts) {
                ui.showLoading(`Pre-booking failed (${status || 'Network'}). Retrying...`);
                await new Promise(r => setTimeout(r, retryDelay));
                continue;
            }

            if (status === 401) clearSessionData();

            ui.showMessage("Network or booking error during pre-check.", "error");
            ui.hideLoading();
            return false;
        }
    }

    clog("[Booking] All retry attempts failed.");
    ui.hideLoading();
    return false;
}


async function handleBookingCaptcha(initialCaptchaDto) {
    let currentCaptchaData = initialCaptchaDto;
    if (window.isBookingStopped || !currentCaptchaData) {
        ui.hideLoading();
        return false;
    }

    let currentAttempt = 1;
    const maxAttempts = 20;

    while (currentAttempt <= maxAttempts) {
        if (window.isBookingStopped) {
            ui.hideLoading();
            return false;
        }

        try {
            const {captchaType, captchaQuestion} = currentCaptchaData;
            ui.showLoading(`Solving Started.. (Attempt ${currentAttempt}/${maxAttempts})`);
            const solvePromise = solveCaptcha(`data:image/png;base64,${captchaQuestion}`);
            const solvedText = await solvePromise;
            if (window.isBookingStopped)
                return false;
            ui.showLoading(`Be ready!!!! (Attempt ${currentAttempt}/${maxAttempts})`);
            const verificationResult = await verifySolvedCaptcha(captchaType, solvedText);
            if (verificationResult.success) {
                clog("[Captcha] Captcha successfully verified.");
                ui.hideLoading();
                return true;
            }
            clog(`[Captcha] Verification failed on attempt ${currentAttempt}. Reason: ${verificationResult.error}`);

            if (verificationResult.error === "no_seats_available") {
                return false;
            }

            if (currentAttempt < maxAttempts) {
                ui.showMessage(`Captcha attempt ${currentAttempt} failed. Fetching a new one...`, "warning");

                const newPreBookingResult = await finalBookingHit();

                if (newPreBookingResult && newPreBookingResult.captcha) {
                    currentCaptchaData = newPreBookingResult.captcha;
                } else {
                    ui.showMessage("Failed to retrieve a new captcha after failed attempt. Stopping.", "error", 0);
                    return false;
                }
            }
        } catch (error) {
            ui.showMessage(`Captcha attempt ${currentAttempt} failed (network/API error). Retrying...`, "warning");
        }

        currentAttempt++;
    }
    ui.showMessage("Captcha failed after maximum attempts. Stopping automation.", "error", 0);
    ui.hideLoading();
    return false;
}

async function verifySolvedCaptcha(captchaType, captchaText) {
    await warmUpConnection();
    const apiUrl = `https://www.irctc.co.in/eticketing/protected/mapps1/captchaverify/${window.clientTransactionId}/${captchaType}/${captchaText}`;
        const headers = {
        "Accept": "application/json, text/plain, */*",
        "Content-Type": "application/json; charset=UTF-8",
        "cache": "no-store",
        "greq": window.greq,
        "Authorization": `Bearer ${window.accessToken}`,
        "bmirak": "webbm",
        "bmiyek": window.bmiyek,
        "Spa-Csrf-Token": window.csrfToken,
        "Origin": "https://www.irctc.co.in",
        "Referer": "https://www.irctc.co.in/nget/payment/bkgPaymentOptions",
        };

    try {
        const response = await fetch(apiUrl, {
            method: "GET",
            headers,
            credentials: "include",
            cache: "no-store"
        });

        CSRFTokenResponse(response);

        if (!response.ok) {
            const errorText = await response.text();
            return {
                success: false,
                error: `HTTP ${response.status}`
            };
        }

        const data = await response.json();

        if (data.status === "SUCCESS") {
            return {
                success: true
            };
        }

        if (data.status === "FAIL") {
            const errorMessage = (data.error || "").toLowerCase();
            if (errorMessage.includes("invalid captcha")) {
                return {
                    success: false,
                    error: "invalid_captcha"
                };
            }
            if (errorMessage.includes("no seats available")) {
                window.isBookingStopped = true;
                ui.showMessage("No seats available after captcha verification. Stopping automation.", "error", 0);
                return {
                    success: false,
                    error: "no_seats_available"
                };
            }
        }
        return {
            success: false,
            error: data.error || "verification_failed"
        };

    } catch (error) {
        clog(`[Captcha Verification] Network error during verification: ${error.message}`);
        return {
            success: false,
            error: "network_error"
        };
    }
}

async function initiatePaymentProcess(amount) {
    const maxFareValue = window.bookingConfig.maxFare;

    const maxFare = parseInt(maxFareValue, 10);
    const totalAmount = Math.ceil(parseFloat(amount));

    if (maxFare > 0 && totalAmount > maxFare) {
        const proceed = confirm(`FARE ALERT!\n\nThe actual ticket fare is ₹${totalAmount}, which is higher than your set maximum fare of ₹${maxFare}.\n\nDo you still want to proceed with the booking?`);

        if (!proceed) {
            ui.hideLoading();
            ui.showMessage("Booking cancelled as the fare exceeded your maximum limit.", "warning");
            return false;
        }
        clog("[Payment] User approved to proceed despite fare exceeding the max limit.");
    }
    ui.showLoading("Initiating Payment...");
    if (window.isBookingStopped) {
        ui.hideLoading();
        clog("[Payment] Booking stopped before payment initiation.");
        return false;
    }

    const paymentMethod = els.paymentMethod.value;
    try {
        let paymentInitiationResult = null;
        switch (paymentMethod) {
        case "paytm":
        //    await new Promise(resolve => setTimeout(resolve, 1668)); // Important VERY Much!!
            paymentInitiationResult = await initiatePayTMQRPayment(amount);
            if (paymentInitiationResult)
                await handlePayTMQRRedirection();
            break;
        case "irctcqr":
      //      await new Promise(resolve => setTimeout(resolve, 1668)); // Important VERY Much!!
            paymentInitiationResult = await initiateIrctcQRPayment(amount);
            if (paymentInitiationResult)
                await handleIrctcQRRedirection();
            break;
        case "phonepay":
      //      await new Promise(resolve => setTimeout(resolve, 1668)); // Important VERY Much!!
            paymentInitiationResult = await initiatePhonePeQR(amount);
            break;
        case "debitcard":
      //      await new Promise(resolve => setTimeout(resolve, 1668)); // Important VERY Much!!
            paymentInitiationResult = await initiateDebitCardPayment(amount);
            if (paymentInitiationResult) {
                await handleDebitCardRedirection_And_LoadCardPage();
            }
            break;
        default:
            ui.showMessage(`Payment method "${paymentMethod}" is not supported.`, "error", 0);
            return false;
        }
        if (!paymentInitiationResult) {
            clog(`[Payment] Payment initiation failed for ${paymentMethod}.`);
            return false;
        }
        clog(`[Payment] Payment initiation successful for ${paymentMethod}.`);
        return true;
    } catch (error) {
        clog(`[Payment] Critical error during payment process dispatch: ${error.message}`);
        ui.showMessage(`A critical error occurred during payment dispatch: ${error.message}`, "error", 0);
        return false;
    }
}

// Payment Methods : Starting with PhonePay

// Step 1
async function initiatePhonePeQR(amount) {
    if (window.isBookingStopped) {
        ui.hideLoading();
        return null;
    }
    ui.showLoading("Initiating PhonePe...");

    const apiUrl = `https://www.irctc.co.in/eticketing/protected/mapps1/bookingInitPayment/${window.clientTransactionId}?insurenceApplicable=NA`;
    const headers = {
        "greq": window.greq,
        "Authorization": `Bearer ${window.accessToken}`,
        "bmirak": "webbm",
        "bmiyek": window.bmiyek,
        "Spa-Csrf-Token": window.csrfToken || "",
        "Content-Type": "application/json; charset=UTF-8",
    };
    const requestBody = {
        bankId: "116",
        txnType: 1,
        paramList: [],
        amount: amount,
        transationId: 0,
        txnStatus: 1,
    };

    try {
        clog(`[PhonePe] Calling IRCTC for payment initiation. Amount: ${amount}`);
        const response = await fetch(apiUrl, {
            method: "POST",
            headers,
            body: JSON.stringify(requestBody),
            credentials: "include"
        });

        CSRFTokenResponse(response);

        if (!response.ok) {
            const errText = await response.text();
            throw {
                status: response.status,
                message: errText.substring(0, 200)
            };
        }

        const data = await response.json();
        if (ui.processErrorMsg(data)) {
            return null;
        }

        window.paymentResponse = data;
        clog("[PhonePe] IRCTC initiation successful. Proceeding to PhonePe redirection.");
        await initiatePhonePeQRRedirect();
        return data;

    } catch (error) {
        clog(`[PhonePe] IRCTC initiation failed. Status: ${error.status}, Message: ${error.message}`);
        ui.showMessage(`PhonePe initiation failed: ${error.message}`, "error", 0);
        ui.hideLoading();
        return null;
    }
}
// Step 2
async function initiatePhonePeQRRedirect() {
    ui.showLoading("Redirecting to PhonePe Gateway...");
    if (window.isBookingStopped) {
        ui.hideLoading();
        clog("[PhonePe] Booking stopped before redirection.");
        return false;
    }

    const randomString = Array.from({
        length: 8
    }, () => Math.floor(10 * Math.random())).join("");
    const txnString = `${els.username.value.trim()}:${window.clientTransactionId}`;
    const requestBody = `token=${encodeURIComponent(window.accessToken)}&txn=${encodeURIComponent(txnString)}&${encodeURIComponent(txnString)}=${encodeURIComponent(randomString)}.${encodeURIComponent(window.csrfToken || '')}`;

    try {
        const responseText = await (await fetch("https://www.wps.irctc.co.in/eticketing/PaymentRedirect", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: requestBody,
            credentials: "include",
            redirect: "manual",
        })).text();

        const doc = new DOMParser().parseFromString(responseText, "text/html");
        const form = doc.querySelector("form");
        const actionUrl = form?.getAttribute("action");
        const tokenInput = form?.querySelector("input[name='token']");

        if (!actionUrl || !tokenInput?.value) {
            ui.showMessage("Failed to retrieve PhonePe redirect data.", "error", 0);
            clog("[PhonePe] Missing form or token in redirect response.");
            return false;
        }

        clog("[PhonePe] Redirection data extracted. Proceeding to PhonePe session setup.");
        await phonePeEncData(actionUrl, tokenInput.value);
        return true;

    } catch (error) {
        clog(`[PhonePe] Error during redirection: ${error.message}`);
        ui.showMessage("Network error during PhonePe redirection.", "error", 0);
        return false;
    }
}
// Step 3
async function phonePeEncData(actionUrl, token) {
    ui.showLoading("PhonePe: Establishing Secure Session...");
    const fullActionUrl = new URL(actionUrl,"https://mercury-t2.phonepe.com").href;
    const body = "token=" + encodeURIComponent(token);

    try {
        await fetch(fullActionUrl, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            credentials: "include",
            body: body,
        });

        clog("[PhonePe] Session established. Exchanging token for authentication.");
        await exchangePhonePeToken(token);
    } catch (error) {
        clog(`[PhonePe] Error establishing secure session: ${error.message}`);
        ui.showMessage("An error occurred during PhonePe secure session setup.", "error", 0);
    }
}
// Step 4
async function exchangePhonePeToken(initialToken) {
    if (window.isBookingStopped)
        return clog("⛔ Booking stopped.");

    const browserFingerprint = getBrowserFingerprint();
    const commonHeaders = {
        accept: "application/json, text/plain, */*",
        "accept-language": navigator.language || "en-GB",
        origin: "https://mercury-t2.phonepe.com",
        referer: "https://mercury-t2.phonepe.com/",
        "user-agent": navigator.userAgent,
    };
    let authToken;

    try {
        // Step 1: Exchange Token
        ui.showLoading("PhonePe: Authenticating...");
        const exchangeRes = await fetch(`https://api.phonepe.com/apis/pg/checkout/ui/v2/token/exchange?t=${Date.now()}__5`, {
            method: "GET",
            credentials: "include",
            headers: {
                ...commonHeaders,
                "x-auth-token": initialToken,
                "x-browser-fingerprint": browserFingerprint
            },
        });
        if (!exchangeRes.ok)
            throw new Error(`Token exchange failed (Status ${exchangeRes.status})`);
        authToken = (await exchangeRes.json()).token;
        if (!authToken)
            throw new Error("No auth token in exchange response");

        // Step 2: Fetch Encryption Key (Required by flow)
        const encKeyRes = await fetch(`https://api.phonepe.com/apis/pg/checkout/ui/v2/encryption-key?t=${Date.now()}__5`, {
            method: "GET",
            credentials: "include",
            headers: {
                ...commonHeaders,
                authorization: `Bearer ${authToken}`,
                "x-auth-token": authToken,
                "x-browser-fingerprint": browserFingerprint
            },
        });
        if (!encKeyRes.ok)
            throw new Error(`Encryption key fetch failed (Status ${encKeyRes.status})`);

        // Step 3: Fetch Transaction Details (This is the critical step with specific headers)
        const detailsRes = await fetch(`https://api.phonepe.com/apis/pg/checkout/ui/v2/transaction/details?t=${Date.now()}__5`, {
            method: "POST",
            credentials: "include",
            headers: {
                ...commonHeaders,
                Checkouttype: "STANDARD_CHECKOUT",
                "X-App-Package-Name": "",
                "X-Browser-Fingerprint": browserFingerprint,
                "X-Client": "browser",
                "X-Client-Major-Version": "137",
                "X-Client-Name": "Chrome",
                "X-Client-Subtype": "dweb",
                "X-Client-Type": "desktop",
                "X-Client-Version": "137.0.0.0",
                "X-Device-Type": "desktop",
                "X-Merchant-Domain": "https://www.wps.irctc.co.in/",
                "X-Source": "API",
                "X-Source-Channel": "Mac OS",
                "X-Source-Channel-Version": "10.15.7",
                "X-Source-Integration-Mode": "REDIRECTION",
                "Content-Type": "application/json; charset=UTF-8",
                authorization: `Bearer ${authToken}`,
                "x-auth-token": authToken,
            },
            body: JSON.stringify({
                retryConsentGranted: false
            }),
        });
        if (!detailsRes.ok)
            throw new Error(`Transaction details fetch failed (Status ${detailsRes.status})`);

        // Step 4: Fetch UPI QR Code
        ui.showLoading("PhonePe: Fetching UPI QR Code...");
        const qrRes = await fetch(`https://api.phonepe.com/apis/pg/checkout/ui/v2/upi-qr?t=${Date.now()}__5`, {
            method: "GET",
            credentials: "include",
            headers: {
                ...commonHeaders,
                authorization: `Bearer ${authToken}`,
                "x-auth-token": authToken,
                "x-browser-fingerprint": browserFingerprint
            },
        });
        if (!qrRes.ok)
            throw new Error(`QR code fetch failed (Status ${qrRes.status})`);
        const qrCode = (await qrRes.json()).qrCode;
        if (!qrCode)
            throw new Error("No QR code data received from PhonePe");

        ui.hideLoading();
        ui.showPhonePeQR(qrCode);
        // This function needs to be created in your UI module
        pollPhonePeStatus(authToken);

    } catch (error) {
        clog(`❌ PhonePe flow failed: ${error.message}`);
        ui.showMessage(`PhonePe Error: ${error.message}`, "error", 0);
    }
}
// Step 5
async function pollPhonePeStatus(authToken) {
    const headers = {
        ...buildCommonHeaders(),
        authorization: `Bearer ${authToken}`,
        "x-auth-token": authToken,
        "x-browser-fingerprint": getBrowserFingerprint(),
    };
    const pollUrl = `https://api.phonepe.com/apis/pg/checkout/ui/v2/status?t=${Date.now()}__5`;

    const pollInterval = setInterval(async () => {
        if (window.isBookingStopped) {
            clearInterval(pollInterval);
            return;
        }

        try {
            const statusRes = await fetch(pollUrl, {
                method: "GET",
                credentials: "include",
                headers
            });
            if (!statusRes.ok)
                throw new Error(`Polling status ${statusRes.status}`);

            const statusData = await statusRes.json();
            clog(`[PhonePe Polling] Status: ${statusData.state}`);

            if (statusData.state === "COMPLETED") {
                clearInterval(pollInterval);
                clog("✅ PhonePe Payment COMPLETED. Fetching redirect URL...");

                const redirectRes = await fetch(`https://api.phonepe.com/apis/pg/checkout/ui/v2/redirect-url?t=${Date.now()}__5`, {
                    method: "GET",
                    credentials: "include",
                    headers,
                });

                if (!redirectRes.ok)
                    throw new Error(`Redirect URL fetch failed (Status ${redirectRes.status})`);
                const redirectData = (await redirectRes.json()).notificationResponse?.response;
                if (!redirectData)
                    throw new Error("No redirect response data found");

                if (window.closePhonePeQR)
                    window.closePhonePeQR();
                await PhonePeQRBankResponse(redirectData);
            }
        } catch (error) {
            clearInterval(pollInterval);
            clog(`❌ PhonePe polling error: ${error.message}`);
            ui.showMessage("Failed to poll PhonePe status. Please check your PhonePe app.", "error", 0);
        }
    }
    , 500);
}
// Step 6
async function PhonePeQRBankResponse(responseData) {
    if (window.isBookingStopped)
        return;
    ui.showLoading("Verifying PhonePe QR Payment with IRCTC...");

    const body = "response=" + encodeURIComponent(responseData);
    let isRedirected = false;

    try {
        for (let attempt = 1; attempt <= 5; attempt++) {
            const response = await fetch("https://www.wps.irctc.co.in/eticketing/BankResponse", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                credentials: "include",
                redirect: "follow",
                body,
            });

            if (response.redirected || response.url.includes("booking-confirm")) {
                clog(`[Bank Response] PhonePe payment confirmed by IRCTC on attempt #${attempt}.`);
                isRedirected = true;
                break;
            }
            clog(`[Bank Response] IRCTC still processing PhonePe payment. Retrying in 4.5s... (Attempt ${attempt}/5)`);
            await new Promise(resolve => setTimeout(resolve, 4500));
        }

        if (!isRedirected)
            throw new Error("IRCTC did not confirm the transaction after multiple attempts.");

        clog("✅ PhonePe Bank Response completed. Fetching booking info...");
        await retrieveBookingInformation();

    } catch (error) {
        ui.showMessage(`Final payment confirmation failed: ${error.message}`, "error", 0);
    } finally {
        ui.hideLoading();
    }
}

// Completed PhonePay Method

// -- Payment Methods : Paytm --

// Step 1
async function initiatePayTMQRPayment(amount) {
    const maxAttempts = 4;
    const retryDelay = 4500;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        if (window.isBookingStopped) {
            ui.hideLoading();
            clog("[PayTM QR] Booking stopped before PayTM QR initiation.");
            return null;
        }

        ui.showLoading(`Initiating PayTM Gateway... (Attempt ${attempt}/${maxAttempts})`);

        const apiUrl = `https://www.irctc.co.in/eticketing/protected/mapps1/bookingInitPayment/${window.clientTransactionId}?insurenceApplicable=NA`;

        const headers = {
            "greq": window.greq,
            "Authorization": `Bearer ${window.accessToken}`,
            "bmirak": "webbm",
            "bmiyek": window.bmiyek,
            "Spa-Csrf-Token": window.csrfToken || "",
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json; charset=UTF-8",
            "Origin": "https://www.irctc.co.in",
            "Referer": "https://www.irctc.co.in/nget/payment/bkgPaymentOptions",
        };

        const requestBody = {
            bankId: "78",
            txnType: 1,
            paramList: [],
            amount: amount,
            transationId: 0,
            txnStatus: 1
        };

        try {
            clog(`[PayTM QR] Calling IRCTC API for payment initiation. Amount: ${amount}, Attempt: ${attempt}`);
            const response = await fetch(apiUrl, {
                method: "POST",
                headers,
                body: JSON.stringify(requestBody),
                credentials: "include"
            });

            CSRFTokenResponse(response);

            if (!response.ok) {
                const errText = await response.text();
                throw {
                    status: response.status,
                    message: errText.substring(0, 200)
                };
            }

            const data = await response.json();
            if (ui.processErrorMsg(data)) {
                clog("[PayTM QR] Business logic error from UI handler. Stopping retries.");
                return null;
            }

            window.paymentResponse = data;
            clog("[PayTM QR] PayTM payment initiation successful. Response data stored.");
            ui.hideLoading();
            return data;

        } catch (error) {
            const status = error.status || 0;
            const errText = error.message || "";
            clog(`[PayTM QR] Attempt ${attempt} failed. Status: ${status}, Message: ${errText}`);

            const retryableStatuses = [401, 403, 409, 503, 510];
            const isRetryableStatus = retryableStatuses.includes(status);
            const isRetryableMessage = errText.includes("Unable to process Payment request now") || errText.includes("Sorry !! Unable to process the request due to issue at Bank end");

            // Check if we should retry
            if ((isRetryableStatus || isRetryableMessage) && attempt < maxAttempts) {
                ui.showMessage(`PayTM initiation failed. Retrying in 4 seconds...`, "warning");
                await new Promise(resolve => setTimeout(resolve, retryDelay));
                continue;
                // Continue to the next iteration of the loop with the updated token
            }

            // --- If not retrying, handle final error ---
            if (status === 401) {
                ui.showMessage("Session expired or unauthorized. Please re-login.", "error", 0);
                clearSessionData();
            } else if (status === 403) {
                ui.showMessage("IP Address blocked temporarily. Please try again later.", "error", 0);
            } else if (status === 409) {
                ui.showMessage("Conflict detected (e.g., multiple logins/sessions).", "error", 0);
            } else if (status === 510) {
                ui.showMessage("Account/Profile rate-limited or Fingerprint Issues after multiple retries.", "error", 0);
            } else if (status === 503) {
                ui.showMessage("IRCTC Server (503) is unavailable after multiple retries.", "error", 0);
            } else if (errText.includes("Unable to process Payment request now") || errText.includes("Sorry !! Unable to process the request due to issue at Bank end")) {
                ui.showMessage("PayTM Gateway seems down after multiple attempts.", "error", 0);
            } else if (errText.includes("Unable to Process Request")) {
                ui.showMessage("Fingerprint Issues detected. Consider changing browser profile settings.", "error", 0);
            } else if (errText.includes("Unable to process your request")) {
                ui.showMessage("IRCTC Account is being blocked at payment. Please use a different IRCTC account.", "error", 0);
            } else {
                ui.showMessage(`PayTM initiation failed: ${errText.substring(0, 100)}...`, "error", 0);
            }

            ui.hideLoading();
            return null;
            // Return null after handling the final error.
        }
    }

    // This part should not be reached if logic is correct, but it's a good safeguard.
    clog("[PayTM QR] All retry attempts for payment initiation have failed.");
    ui.hideLoading();
    return null;
}

// Step 2
async function handlePayTMQRRedirection() {
    if (window.isBookingStopped) {
        ui.hideLoading();
        return false;
    }

    const randomString = Array.from({
        length: 8
    }, () => Math.floor(10 * Math.random())).join("");
    const txnString = `${els.username.value.trim()}:${window.clientTransactionId}`;
    const requestBody = `token=${encodeURIComponent(window.accessToken)}&txn=${encodeURIComponent(txnString)}&${encodeURIComponent(txnString)}=${encodeURIComponent(randomString)}.${encodeURIComponent(window.csrfToken || '')}`;

    try {
        const response = await fetch("https://www.wps.irctc.co.in/eticketing/PaymentRedirect", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept-Encoding": "br, gzip, deflate"
            },
            body: requestBody,
            credentials: "include",
            cache: "no-store",
            redirect: "manual"
        });
        const responseText = await response.text();
        if (responseText.includes("Unable to process your request")) {
            ui.showMessage("IRCTC Account is getting blocked at Payment. Please use a different IRCTC account.", "error", 0);
            clog("[PayTM QR] 'Unable to process your request' found in redirect response - IRCTC account issue.");
            return false;
        }
        const doc = new DOMParser().parseFromString(responseText, "text/html");
        const form = doc.querySelector("form");
        if (!form) {
            ui.showMessage("Failed to retrieve PayTM redirect form from response.", "error", 0);
            clog("[PayTM QR] No form element found in PaymentRedirect response.");
            return false;
        }
        const actionUrl = form.getAttribute("action");
        const encDataInput = form.querySelector("input[name='ENC_DATA']");
        const midInput = form.querySelector("input[name='MID']");
        const checksumHashInput = form.querySelector("input[name='CHECKSUMHASH']");
        if (!actionUrl || !encDataInput?.value || !midInput?.value || !checksumHashInput?.value) {
            ui.showMessage("Failed to extract essential PayTM redirect data (action URL, ENC_DATA, MID, CHECKSUMHASH).", "error", 0);
            clog("[PayTM QR] Missing essential form inputs for PayTM redirection.");
            return false;
        }
        window.paytmMid = midInput.value;
        window.paytmActionUrl = actionUrl;
        clog(`[PayTM QR] Successfully extracted PayTM redirection parameters. MID: ${midInput.value}, Action URL: ${actionUrl}.`);
        await sendPayTMEncryptedData(actionUrl, encDataInput.value, midInput.value, checksumHashInput.value);
        return true;
    } catch (error) {
        clog(`[PayTM QR] Network or unexpected error during handlePayTMQRRedirection: ${error.message}`);
        ui.showMessage("Network error during PayTM QR redirect.", "error", 0);
        return false;
    }
}

// Step 3
async function sendPayTMEncryptedData(actionUrl, encData, mid, checksumHash, attempt=0) {
    ui.showLoading("Generating QR for Payment..");
    if (window.isBookingStopped) {
        ui.hideLoading();
        clog("[PayTM QR] Booking stopped before fetching QR code.");
        return false;
    }

    const fullActionUrl = new URL(actionUrl,"https://secure.paytmpayments.com").href;
    const requestBody = `MID=${encodeURIComponent(mid)}&ENC_DATA=${encodeURIComponent(encData)}&CHECKSUMHASH=${encodeURIComponent(checksumHash)}`;

    try {
        const response = await fetch(fullActionUrl, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept-Encoding": "br, gzip, deflate"
            },
            credentials: "include",
            cache: "no-store",
            body: requestBody
        });
        ui.hideLoading();
        if (!response.ok) {
            ui.showMessage(`PayTM payment submission failed. Status: ${response.status}. Please retry.`, "error", 0);
            return false;
        }
        const responseText = await response.text();
        const pushAppData = /var\s+pushAppData\s*=\s*["']([^"']+)["']/.exec(responseText)?.[1];
        if (!pushAppData && attempt < 1) {
            clog("[PayTM QR] pushAppData not found in response. Retrying once.");
            return await sendPayTMEncryptedData(actionUrl, encData, mid, checksumHash, attempt + 1);
        }
        if (!pushAppData) {
            ui.showMessage("No QR code data found in PayTM response after retries. Payment flow interrupted.", "error", 0);
            clog("[PayTM QR] pushAppData consistently not found in response.");
            return false;
        }
        const decodedAppData = atob(pushAppData);
        const qrDataJson = JSON.parse(decodedAppData);
        if (qrDataJson.qr && qrDataJson.qr.enabled && qrDataJson.qr.dataurl) {
            clog("[PayTM QR] Successfully extracted QR code data. Displaying QR modal.");
            ui.showPayTMQR(qrDataJson.qr.dataurl, fullActionUrl, mid, finalizePayTMTransactionStatus);
            return true;
        }
        ui.showMessage("No QR code found in PayTM response, or QR not enabled. Payment flow interrupted.", "error", 0);
        return false;
    } catch (error) {
        ui.showMessage("Network error during PayTM QR data operation. Please retry.", "error", 0);
        return false;
    }
}

// Step 4
async function finalizePayTMTransactionStatus() {
    if (window.isBookingStopped) {
        ui.hideLoading();
        clog("[PayTM QR Status] Booking stopped before finalizing PayTM transaction status.");
        return null;
    }
    ui.hideLoading();
    ui.showLoading("Verifying PayTM Transaction Status with PayTM server...");

    const paytmWSData = window.paytmWSData;
    if (!paytmWSData) {
        ui.showMessage("Payment data missing from PayTM WebSocket. Cannot verify status.", "error", 0);
        clog("[PayTM QR Status] PayTM WebSocket data missing. Cannot proceed with status verification.");
        return null;
    }

    const {merchantId, acquirementId, cashierRequestId, paymentMode, orderId, topicName, status, _id} = paytmWSData;
    const requestBody = new URLSearchParams({
        merchantId,
        acquirementId,
        cashierRequestId,
        paymentMode,
        orderId,
        topicName,
        status,
        _id,
        transId: acquirementId
    }).toString();
    const apiUrl = `https://secure.paytmpayments.com/theia/transactionStatus?MID=${encodeURIComponent(merchantId)}&ORDER_ID=${encodeURIComponent(orderId)}`;

    try {
        clog(`[PayTM QR Status] Requesting final transaction status from PayTM for Order ID: ${orderId}.`);
        const response = await fetch(apiUrl, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": "https://secure.paytm.com",
                "Referer": `https://secure.paytm.com/oltp-web/processTransaction?orderid=${encodeURIComponent(orderId)}`,
                "Accept-Encoding": "br, gzip, deflate"
            },
            credentials: "include",
            cache: "no-store",
            body: requestBody
        });
        if (!response.ok) {
            ui.showMessage(`Error retrieving final PayTM status. Server responded with status: ${response.status}.`, "error", 0);
            clog(`[PayTM QR Status] Failed to retrieve status from PayTM. HTTP Status: ${response.status}.`);
            return null;
        }
        const doc = new DOMParser().parseFromString(await response.text(), "text/html");
        const form = doc.querySelector("form");
        if (!form) {
            ui.showMessage("PayTM payment rejected by server or final form missing. Please check PayTM app.", "error", 0);
            clog("[PayTM QR Status] No form element found in final PayTM status response. Payment likely failed or rejected.");
            return null;
        }
        const finalMid = form.querySelector("input[name='MID']")?.value;
        const finalEncData = form.querySelector("input[name='ENC_DATA']")?.value;
        const finalChecksumHash = form.querySelector("input[name='CHECKSUMHASH']")?.value;
        if (!finalMid || !finalEncData || !finalChecksumHash) {
            ui.showMessage("Failed to extract final bank response data from PayTM. Critical payment data missing.", "error", 0);
            clog("[PayTM QR Status] Missing essential form inputs (MID, ENC_DATA, CHECKSUMHASH) from final PayTM response.");
            return null;
        }
        clog("[PayTM QR Status] Successfully extracted final bank response data from PayTM. Submitting to IRCTC.");
        await submitPayTMBankResponseToIRCTC(finalMid, finalEncData, finalChecksumHash);
        return true;
    } catch (error) {
        clog(`[PayTM QR Status] Network or parsing error retrieving final PayTM status: ${error.message}`);
        ui.showMessage("Network error during final PayTM status check. Please check your PayTM app.", "error", 0);
        return null;
    } finally {
        ui.hideLoading();
    }
}

// Step 5
async function submitPayTMBankResponseToIRCTC(mid, encData, checksumHash) {
    if (window.isBookingStopped) {
        ui.hideLoading();
        clog("[Bank Response] Booking stopped before submitting PayTM bank response to IRCTC.");
        return false;
    }
    ui.showLoading("IRCTC Verifying PayTM Payment Status...");

    const requestBody = `MID=${encodeURIComponent(mid)}&ENC_DATA=${encodeURIComponent(encData)}&CHECKSUMHASH=${encodeURIComponent(checksumHash)}`;
    let redirectedSuccessfully = false;

    try {
        for (let i = 1; i <= 5; i++) {
            clog(`[Bank Response] Submitting PayTM bank response to IRCTC. Attempt #${i}.`);
            const responseObj = await fetch("https://www.wps.irctc.co.in/eticketing/BankResponse", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Accept-Encoding": "br, gzip, deflate"
                },
                credentials: "include",
                cache: "no-store",
                redirect: "follow",
                body: requestBody
            });
            if (responseObj.redirected) {
                redirectedSuccessfully = true;
                clog(`[Bank Response] Redirected successfully on attempt #${i}.`);
                break;
            }
            clog(`[Bank Response] No redirect yet on attempt #${i} — transaction still processing. Retrying in 4.5s...`);
            await new Promise(resolve => setTimeout(resolve, 4500));
        }
        if (!redirectedSuccessfully) {
            clog("[Bank Response] IRCTC still processing the transaction after multiple attempts. No redirect occurred.");
            throw new Error("IRCTC still processing the transaction after multiple attempts. Please check your IRCTC account manually.");
        }
        clog("[Bank Response] PayTM Bank Response completed — proceeding to booking info retrieval.");
        await retrieveBookingInformation();
        return true;
    } catch (error) {
        clog(`[Bank Response] Network or unexpected error during final bank response submission: ${error.message}`);
        ui.showMessage(`Network error during final payment confirmation: ${error.message}. Please check your IRCTC account manually.`, "error", 0);
        return false;
    } finally {
        ui.hideLoading();
    }
}

// -- Paytm Payment Method Completed -- 

// -- IRCTC QR Payment Method --

// Step 1: Initiate payment with IRCTC.
async function initiateIrctcQRPayment(amount) {
    const maxAttempts = 4;
    const retryDelay = 4500;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        if (window.isBookingStopped) {
            ui.hideLoading();
            clog("[IRCTC QR] Booking stopped before initiation.");
            return null;
        }

        ui.showLoading(`Initiating IRCTC QR... (Attempt ${attempt}/${maxAttempts})`);

        const apiUrl = `https://www.irctc.co.in/eticketing/protected/mapps1/bookingInitPayment/${window.clientTransactionId}?insurenceApplicable=NA`;
        const headers = {
            "greq": window.greq,
            "Authorization": `Bearer ${window.accessToken}`,
            "bmirak": "webbm",
            "bmiyek": window.bmiyek,
            "Spa-Csrf-Token": window.csrfToken || "",
            "Content-Type": "application/json; charset=UTF-8",
            "Accept": "application/json, text/plain, */*",
            "Origin": "https://www.irctc.co.in",
            "Referer": "https://www.irctc.co.in/nget/payment/bkgPaymentOptions",
        };
        const requestBody = {
            bankId: "113",
            txnType: 1,
            paramList: [],
            amount: amount,
            transationId: 0,
            txnStatus: 1,
        };

        try {
            clog(`[IRCTC QR] Calling IRCTC for payment initiation. Amount: ${amount}, Attempt: ${attempt}`);
            const response = await fetch(apiUrl, {
                method: "POST",
                headers,
                body: JSON.stringify(requestBody),
                credentials: "include",
                cache: "no-store",
            });

            CSRFTokenResponse(response);

            if (!response.ok) {
                const errText = await response.text();
                throw {
                    status: response.status,
                    message: errText.substring(0, 200)
                };
            }

            const data = await response.json();
            if (ui.processErrorMsg(data)) {
                clog("[IRCTC QR] Business logic error from UI handler. Stopping retries.");
                return null;
            }

            window.paymentResponse = data;
            clog("[IRCTC QR] IRCTC payment initiation successful.");
            ui.hideLoading();
            return data;

        } catch (error) {
            const status = error.status || 0;
            const errText = error.message || "";
            clog(`[IRCTC QR] Attempt ${attempt} failed. Status: ${status}, Message: ${errText}`);

            const retryableStatuses = [401, 403, 409, 503, 510];
            const isRetryableStatus = retryableStatuses.includes(status);
            const isRetryableMessage = errText.includes("Unable to process Payment request now") || errText.includes("Sorry !! Unable to process the request due to issue at Bank end");

            if ((isRetryableStatus || isRetryableMessage) && attempt < maxAttempts) {
                ui.showMessage(`IRCTC QR initiation failed. Retrying...`, "warning");
                await new Promise(resolve => setTimeout(resolve, retryDelay));
                continue;
            }

            // Final Error Handling
            if (status === 401) {
                ui.showMessage("Session expired or unauthorized. Please re-login.", "error", 0);
                clearSessionData();
            } else if (status === 403) {
                ui.showMessage("IP Address blocked temporarily. Please try again later.", "error", 0);
            } else if (status === 409) {
                ui.showMessage("Conflict detected (e.g., multiple logins/sessions).", "error", 0);
            } else if (status === 510) {
                ui.showMessage("Account/Profile rate-limited or Fingerprint Issues after multiple retries.", "error", 0);
            } else if (status === 503) {
                ui.showMessage("IRCTC Server (503) is unavailable after multiple retries.", "error", 0);
            } else if (isRetryableMessage) {
                ui.showMessage("IRCTC QR Gateway seems down after multiple attempts.", "error", 0);
            } else if (errText.includes("Unable to Process Request")) {
                ui.showMessage("Fingerprint Issues detected. Consider changing browser profile settings.", "error", 0);
            } else if (errText.includes("Unable to process your request")) {
                ui.showMessage("IRCTC Account is being blocked at payment. Please use a different IRCTC account.", "error", 0);
            } else {
                ui.showMessage(`IRCTC QR initiation failed: ${errText.substring(0, 100)}...`, "error", 0);
            }

            ui.hideLoading();
            return null;
        }
    }
    clog("[IRCTC QR] All retry attempts for payment initiation have failed.");
    ui.hideLoading();
    return null;
}

// Step 2: Redirect to IRCTC's payment gateway.
async function handleIrctcQRRedirection() {
    ui.showLoading("Redirecting to IRCTC iPay Gateway...");
    if (window.isBookingStopped) {
        ui.hideLoading();
        clog("[IRCTC QR] Booking stopped before redirection.");
        return false;
    }

    const randomString = Array.from({
        length: 8
    }, () => Math.floor(10 * Math.random())).join("");
    const txnString = `${els.username.value.trim()}:${window.clientTransactionId}`;
    const requestBody = `token=${encodeURIComponent(window.accessToken)}&txn=${encodeURIComponent(txnString)}&${encodeURIComponent(txnString)}=${encodeURIComponent(randomString)}.${encodeURIComponent(window.csrfToken || '')}`;

    try {
        const response = await fetch("https://www.wps.irctc.co.in/eticketing/PaymentRedirect", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: requestBody,
            credentials: "include",
            redirect: "manual",
        });

        const responseText = await response.text();
        if (responseText.includes("Unable to process your request")) {
            ui.showMessage("IRCTC Account is getting blocked at Payment. Please use a different IRCTC account.", "error", 0);
            clog("[IRCTC QR] 'Unable to process your request' found in redirect response - IRCTC account issue.");
            return false;
        }

        const doc = new DOMParser().parseFromString(responseText, "text/html");
        const form = doc.querySelector("form");
        const actionUrl = form?.getAttribute("action");
        const encDataInput = form?.querySelector("input[name='encdata']");

        if (!actionUrl || !encDataInput?.value) {
            ui.showMessage("Failed to retrieve IRCTC iPay redirect data.", "error", 0);
            clog("[IRCTC QR] Error: Missing form, action, or encdata in PaymentRedirect response.");
            return false;
        }

        await irctcQRProcessIPayGateway(actionUrl, encDataInput.value);
        return true;

    } catch (error) {
        clog(`❌ [IRCTC QR] Error during handleIrctcQRRedirection: ${error.message}`);
        ui.showMessage(`Network error during IRCTC iPay redirection: ${error.message}`, "error", 0);
        return false;
    }
}

// Step 3, 4, 5 Combined: Interact with iPay gateway to get QR code.
async function irctcQRProcessIPayGateway(actionUrl, encData) {
    ui.showLoading("Fetching IRCTC QR Code...");
    if (window.isBookingStopped) {
        ui.hideLoading();
        clog("⛔ Booking stopped during iPay process.");
        return false;
    }

    try {
        const surchargeResponse = await fetch(actionUrl, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: `encdata=${encodeURIComponent(encData)}`,
            credentials: "include",
            redirect: "follow",
        });

        if (!surchargeResponse.ok)
            throw new Error(`iPay gateway request failed: HTTP ${surchargeResponse.status}.`);

        const surchargeHtml = await surchargeResponse.text();
        const doc = new DOMParser().parseFromString(surchargeHtml, "text/html");
        const customToken = doc.querySelector("input[name='customToken']")?.value;
        const totalAmount = doc.querySelector("input#ccsurchargeTotal")?.value;
        if (!customToken || !totalAmount)
            throw new Error("Could not extract customToken or totalAmount from iPay page.");

        const upiPayFormData = new FormData();
        upiPayFormData.append("token", customToken);
        upiPayFormData.append("IsQr", "Y");
        upiPayFormData.append("paymentType", "UP");
        upiPayFormData.append("mopType", "UP");

        const upiPayResponse = await fetch("https://www.irctcipay.com/pgui/jsp/upiPay", {
            method: "POST",
            credentials: "include",
            body: upiPayFormData,
        });
        if (!upiPayResponse.ok)
            throw new Error(`upiPay fetch failed: HTTP ${upiPayResponse.status}.`);

        const upiPayJson = await upiPayResponse.json();
        const {pgRefHash, pgRefNum, imageData} = upiPayJson;
        if (!pgRefHash || !pgRefNum || !imageData)
            throw new Error("Missing critical QR data in upiPay response.");

        window.irctcQrPollDetails = {
            token: customToken,
            pgRefNum,
            pgRefHash
        };

        ui.hideLoading();
        ui.showIrctcQR(imageData);
        pollIrctcQRStatus();
        return true;

    } catch (error) {
        clog(`❌ [IRCTC QR Flow] Critical error during iPay gateway process: ${error.message}`);
        ui.showMessage(`Error in IRCTC iPay process: ${error.message}`, "error", 0);
        ui.hideLoading();
        return false;
    }
}

// Step 6: Poll the iPay gateway for payment status
async function pollIrctcQRStatus(maxAttempts=500, interval=500) {
    clog("[IRCTC QR Polling] Starting polling (Final Version - No UI Changes).");

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        if (window.isBookingStopped) {
            clog("⛔ Booking stopped during polling loop.");
            if (typeof window.closeIrctcQR === 'function')
                window.closeIrctcQR();
            ui.hideLoading();
            return false;
        }
        ui.showLoading(`Waiting for QR payment... (${attempt})`);

        try {
            const {token, pgRefNum, pgRefHash} = window.irctcQrPollDetails || {};

            const pollFormData = new FormData();
            pollFormData.append("token", token);
            pollFormData.append("pgRefNum", pgRefNum);
            pollFormData.append("pgRefHash", pgRefHash);

            const response = await fetch("https://www.irctcipay.com/pgui/jsp/verifyUpiResponse", {
                method: "POST",
                credentials: "include",
                body: pollFormData,
                cache: 'no-store'
            });

            const responseText = await response.text();

            if (responseText.trim()) {
                const pollResult = JSON.parse(responseText);
                const finalMessage = pollResult?.responseFields?.PG_TXN_MESSAGE;
                if (finalMessage) {
                    clog(`[IRCTC QR Polling] Final status received on attempt ${attempt}: "${finalMessage}"`);
                    if (typeof window.closeIrctcQR === 'function') {
                        window.closeIrctcQR();
                    }
                    const finalEncData = pollResult?.responseFields?.encdata;
                    if (!finalEncData) {
                        ui.showMessage(`Payment status is "${finalMessage}", but final transaction data is missing.`, "error", 0);
                        return false;
                    }
                    await submitIrctcQRBankResponseToIRCTC(finalEncData);
                    return true;
                }
            }
        } catch (error) {
            clog(`[IRCTC QR Polling] Error caught on attempt ${attempt}: ${error.message}`);
        }
        clog(`[IRCTC QR Polling] Still pending (attempt ${attempt}/${maxAttempts}). Retrying...`);
        await new Promise(r => setTimeout(r, interval));
    }
    clog("[IRCTC QR Polling] Max attempts reached. Payment not confirmed.");
    if (typeof window.closeIrctcQR === 'function')
        window.closeIrctcQR();
    ui.hideLoading();
    ui.showMessage("IRCTC QR Payment not confirmed in time. Please check your IRCTC account.", "error", 0);
    return false;
}

// Step 7: Submit the final encrypted data back to IRCTC.
async function submitIrctcQRBankResponseToIRCTC(encData) {
    if (window.isBookingStopped) {
        ui.hideLoading();
        clog("⛔ Booking stopped before submitting bank response.");
        return false;
    }
    ui.showLoading("Verifying IRCTC QR Payment with IRCTC...");

    const requestBody = `encdata=${encodeURIComponent(encData)}`;
    let redirectedSuccessfully = false;

    try {
        for (let i = 1; i <= 5; i++) {
            clog(`[Bank Response] Submitting IRCTC QR bank response. Attempt #${i}.`);
            const response = await fetch("https://www.wps.irctc.co.in/eticketing/BankResponse", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: requestBody,
                credentials: "include",
                redirect: "follow"
            });

            if (response.redirected || response.url.includes("booking-confirm")) {
                redirectedSuccessfully = true;
                clog(`[Bank Response] Successfully redirected on attempt #${i}.`);
                break;
            }
            clog(`[Bank Response] No redirect yet on attempt #${i}. Retrying in 4.5s...`);
            await new Promise(resolve => setTimeout(resolve, 4500));
        }

        if (!redirectedSuccessfully) {
            throw new Error("IRCTC did not confirm the transaction after multiple attempts.");
        }

        clog("[Bank Response] IRCTC QR Bank Response completed. Fetching booking information...");
        await retrieveBookingInformation();
        return true;

    } catch (error) {
        clog(`❌ [Bank Response] Final submission error: ${error.message}`);
        ui.showMessage(`Final payment confirmation failed: ${error.message}. Please check your IRCTC account manually.`, "error", 0);
        return false;
    } finally {
        ui.hideLoading();
    }
}

// -- IRCTC QR Flow completed.

function preconnect(url) {
    try {
        const domain = new URL(url).origin;
        clog(`[Optimize] Pre-connecting to ${domain}...`);

        // Use OPTIONS for the most reliable and semantically correct pre-connection.
        fetch(domain, { method: "OPTIONS", mode: 'cors', cache: 'no-store' })
            .catch(err => clog(`[Optimize] Pre-connect to ${domain} failed silently: ${err.message}`)); // Errors are still ignored as the goal is achieved.
    
    } catch (e) {
        clog(`[Optimize] Invalid URL for pre-connect: ${url}`);
    }
}

// --- START: DEBIT CARD (IRCTC iPay / Static Password) PAYMENT METHOD ---

 // Hashes a plain-text password using the specific dual SHA-256 algorithm
async function hdfcHashPassword(password) {
    const salt = "6265661568";
    const encoder = new TextEncoder();

    // Helper to convert an ArrayBuffer to a lowercase hex string
    const bufferToHex = (buffer) => Array.from(new Uint8Array(buffer)).map(b => b.toString(16).padStart(2, '0')).join('');

    // 1. First hash of the plain password
    const passData1 = encoder.encode(password);
    const hashBuffer1 = await crypto.subtle.digest('SHA-256', passData1);
    const hashHex1 = bufferToHex(hashBuffer1);

    // 2. Append salt and perform the second hash
    const combinedData = encoder.encode(hashHex1 + salt);
    const hashBuffer2 = await crypto.subtle.digest('SHA-256', combinedData);
    const finalHashHex = bufferToHex(hashBuffer2);

    clog("[Hashing] Static password hashed successfully.");
    return finalHashHex;
}

// Step 1: Initiates the payment process with IRCTC to get the iPay gateway token.
async function initiateDebitCardPayment(amount) {
    if (window.isBookingStopped) return null;
    ui.showLoading("Initiating Debit Card via iPay...");

    const iPayBankId = "113"; // ID for the IRCTC iPay gateway
    const apiUrl = `https://www.irctc.co.in/eticketing/protected/mapps1/bookingInitPayment/${window.clientTransactionId}?insurenceApplicable=NA`;
    const headers = {
        "greq": window.greq,
        "Authorization": `Bearer ${window.accessToken}`,
        "bmirak": "webbm",
        "bmiyek": window.bmiyek,
        "Spa-Csrf-Token": window.csrfToken || "",
        "Content-Type": "application/json; charset=UTF-8"
    };
    const requestBody = {
        bankId: iPayBankId,
        txnType: 1,
        paramList: [],
        amount: amount,
        transationId: 0,
        txnStatus: 1,
    };

    try {
        clog(`[Debit Card] Step 1: Calling IRCTC for payment initiation (Bank ID: ${iPayBankId}).`);
        const response = await fetch(apiUrl, { method: "POST", headers, body: JSON.stringify(requestBody), credentials: "include" });
        CSRFTokenResponse(response);

        if (!response.ok) throw new Error(`HTTP ${response.status}: ${(await response.text()).substring(0, 200)}`);
        
        const data = await response.json();
        if (ui.processErrorMsg(data)) return null;

        window.paymentResponse = data;
        clog("[Debit Card] Step 1 successful: IRCTC iPay initiation complete.");
        return data;
    } catch (error) {
        clog(`[Debit Card] Step 1 failed: ${error.message}`);
        ui.showMessage(`iPay gateway initiation failed: ${error.message}`, "error", 0);
        return null;
    }
}

//  Step 2 & 3: Handles the multi-step redirect from IRCTC to the iPay gateway
async function handleDebitCardRedirection_And_LoadCardPage() {
    ui.showLoading("Redirecting to iPay Gateway...");
    if (window.isBookingStopped) return false;

    const randomString = Array.from({ length: 8 }, () => Math.floor(10 * Math.random())).join("");
    const txnString = `${els.username.value.trim()}:${window.clientTransactionId}`;
    const requestBody = `token=${encodeURIComponent(window.accessToken)}&txn=${encodeURIComponent(txnString)}&${encodeURIComponent(txnString)}=${encodeURIComponent(randomString)}.${encodeURIComponent(window.csrfToken || '')}`;

    try {
        clog("[Debit Card] Step 2: Posting to PaymentRedirect to get gateway form.");
        const redirectResponse = await fetch("https://www.wps.irctc.co.in/eticketing/PaymentRedirect", {
            method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: requestBody, credentials: "include"
        });
        const redirectHtml = await redirectResponse.text();
        if (redirectHtml.includes("Unable to process your request")) throw new Error("IRCTC Account may be blocked at Payment.");

        const doc = new DOMParser().parseFromString(redirectHtml, "text/html");
        const form = doc.querySelector("form");
        const actionUrl = form?.getAttribute("action");
        const encDataInput = form?.querySelector("input[name='encdata']");
        if (!actionUrl || !encDataInput?.value) throw new Error("Failed to retrieve iPay redirect form data (encdata).");
        
        clog("[Debit Card] Step 3: Submitting encdata and following redirect to card page.");
        const surchargeResponse = await fetch(actionUrl, {
            method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: `encdata=${encodeURIComponent(encDataInput.value)}`, credentials: "include", redirect: "follow"
        });
        if (!surchargeResponse.ok) throw new Error(`iPay gateway request failed: HTTP ${surchargeResponse.status}.`);
        
        const surchargePageHtml = await surchargeResponse.text();
        clog("[Debit Card] Step 3 successful: Loaded card details page.");
        
        await fillCardDetailsAndFinalize(surchargePageHtml, surchargeResponse.url);
        return true;
    } catch (error) {
        clog(`❌ [Debit Card] Steps 2/3 failed: ${error.message}`);
        ui.showMessage(`Gateway redirection error: ${error.message}`, "error", 0);
        return false;
    }
}

// Steps 4-8: The main logic for the iPay gateway. It performs the BIN check
async function fillCardDetailsAndFinalize(surchargePageHtml, pageUrl) {
    ui.showLoading("Submitting Card Details...");
    try {
        const doc = new DOMParser().parseFromString(surchargePageHtml, "text/html");
        const customToken = doc.querySelector("input[name='customToken']")?.value;
        const totalAmount = doc.querySelector("input#ccsurchargeTotal")?.value;
        if (!customToken || !totalAmount) throw new Error("Could not extract customToken or totalAmount from iPay page.");
        clog(`[Debit Card] Extracted customToken: ${customToken}`);

        const { number, expiryMonth, expiryYear, cvv, holderName, staticPassword } = window.bookingConfig.cardDetails;
        if (!staticPassword) throw new Error("Static Password is required but was not provided.");
        
        // --- Step 4: Perform BIN Check ---
        ui.showLoading("Verifying card type...");
        const cardBin = number.substring(0, 9);
        const binFormData = new FormData();
        binFormData.append('token', customToken);
        binFormData.append('bin', cardBin);
        const binResponse = await fetch(new URL("/pgui/jsp/binResolver", pageUrl).href, { method: "POST", body: binFormData, credentials: "include" });
        if (!binResponse.ok) throw new Error(`BIN check failed with status ${binResponse.status}`);
        const binData = await binResponse.json();
        if (binData.notSupported === "Y") throw new Error("This card is not supported by the payment gateway.");
        clog(`[Debit Card] Step 4 successful. Card Type: ${binData.paymentType}, MOP: ${binData.mopType}`);

        // --- Step 6: Submit Card Details to '/pay' endpoint ---
        ui.showLoading("Submitting card details to gateway...");
        const cardPayload = new URLSearchParams({
            browserName: "Chrome", browserVersion: "135", paymentType: binData.paymentType, mopType: binData.mopType,
            issuerBankName: binData.issuerBankName, issuerCountry: binData.issuerCountry, cardHolderType: binData.cardHolderType || "",
            paymentsRegion: binData.paymentsRegion || "", cardNumber: number.replace(/(\d{4})/g, '$1 ').trim(),
            expiryYear, expiryMonth, cvvNumber: cvv, cardName: holderName, amount: totalAmount, customToken,
            cardsaveflag: "false", tokenizeCard: "false"
        }).toString();
        
        const payResponse = await fetch(new URL("/pgui/jsp/pay", pageUrl).href, {
            method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: cardPayload, credentials: "include"
        });
        const bankRedirectHtml = await payResponse.text();
        
        // --- Step 7: Redirect to Bank's 3D Secure Page ---
        ui.showLoading("Redirecting to Bank for authentication...");
        const bankRedirectDoc = new DOMParser().parseFromString(bankRedirectHtml, "text/html");
        const bankRedirectForm = bankRedirectDoc.querySelector("form");
        if (!bankRedirectForm) throw new Error("Could not find the redirect form to the bank's page.");
        const bankUrl = bankRedirectForm.getAttribute("action");
        const creq = bankRedirectForm.querySelector("input[name='creq']").value;
        preconnect(bankUrl);
        const bankAuthPageResponse = await fetch(bankUrl, {
            method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: `creq=${encodeURIComponent(creq)}`, credentials: "include"
        });
        const bankAuthPageHtml = await bankAuthPageResponse.text();
        const bankAuthPageDoc = new DOMParser().parseFromString(bankAuthPageHtml, "text/html");
        const staticPasswordForm = bankAuthPageDoc.querySelector('form[name="AuthPasswordSet1"]');
        if (!staticPasswordForm) throw new Error("Could not find the STATIC PASSWORD form on the bank's page.");
        clog("[Debit Card] Step 7 successful: Loaded bank's static password page.");

        // --- Step 8: Hash and Submit the Static Password to the Bank ---
        ui.showLoading("Submitting static password...");
        const hashedPassword = await hdfcHashPassword(staticPassword);

        const submissionUrl = new URL(staticPasswordForm.getAttribute("action"), bankAuthPageResponse.url).href;
        const staticPasswordPayload = new URLSearchParams(new FormData(staticPasswordForm));
        staticPasswordPayload.set("passCode", hashedPassword);
        staticPasswordPayload.set("formReqType", "SUBMIT");
        staticPasswordPayload.set("flowMode", "VERIFICATION");
        staticPasswordPayload.set("activeSection", "staticSection");

        const passwordSubmitResponse = await fetch(submissionUrl, {
            method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: staticPasswordPayload.toString(), credentials: "include"
        });
        const bankReturnHtml_from_Step8 = await passwordSubmitResponse.text();
        
        // --- Step 9: Handle the Bank's Return to the iPay Gateway ---
        clog("[Debit Card] Step 8 successful. Handling bank's return to iPay gateway.");
        const bankReturnDoc = new DOMParser().parseFromString(bankReturnHtml_from_Step8, "text/html");
        const iPayReturnForm = bankReturnDoc.querySelector("form[action*='iciciIpgV2Return']");

        if (!iPayReturnForm) {
            const errorMsg = bankReturnDoc.querySelector('#challengeInfoText, .errorMessages')?.textContent.trim();
            if (errorMsg) throw new Error(`Bank Error: ${errorMsg}`);
            throw new Error("Could not find the return form from the bank back to the iPay gateway. Payment may have failed.");
        }
        
        const iPayReturnUrl = iPayReturnForm.getAttribute("action");
        const cresData = new URLSearchParams(new FormData(iPayReturnForm)).toString();

        clog("[Debit Card] Step 9: Submitting 'cres' authentication data back to iPay gateway.");
        const iPayReturnResponse = await fetch(iPayReturnUrl, {
            method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: cresData, credentials: "include"
        });
        const finalHtmlFromIPay = await iPayReturnResponse.text();

        // --- Final Step: Handle response and submit back to IRCTC ---
        const finalDoc = new DOMParser().parseFromString(finalHtmlFromIPay, "text/html");
        const finalFormToIrctc = finalDoc.querySelector("form[action*='BankResponse']");

        if (!finalFormToIrctc) {
            throw new Error("Payment failed. Could not find the final form to submit to IRCTC's BankResponse.");
        }
        
        const finalEncData = new URLSearchParams(new FormData(finalFormToIrctc)).get("encdata");
        if (!finalEncData) throw new Error("Final 'encdata' for IRCTC is missing.");

        clog("[Debit Card] Step 9 successful. Finalizing with IRCTC.");
        await submitIrctcQRBankResponseToIRCTC(finalEncData);
        return true;

    } catch (error) {
        clog(`❌ [Debit Card Flow] Critical error: ${error.message}`);
        ui.showMessage(`Debit Card Error: ${error.message}`, "error", 0);
        return false;
    }
}

// --- END: DEBIT CARD (IRCTC iPay / Static Password) PAYMENT METHOD ---

async function retrieveBookingInformation() {
    ui.showLoading("Fetching Booking Information (PNR)...");
    if (window.isBookingStopped || !validateCurrentSession()) {
        ui.hideLoading();
        clog("[Booking Info] Booking stopped or session invalid before fetching booking info.");
        return null;
    }

    const apiUrl = `https://www.wps.irctc.co.in/eticketing/protected/mapps1/bookingData/${window.clientTransactionId}`;
    const headers = {
        "Host": "www.wps.irctc.co.in",
        "greq": window.greq,
        "bmirak": "webbm",
        "bmiyek": window.bmiyek,
        "Authorization": `Bearer ${window.accessToken}`,
        "Spa-Csrf-Token": window.csrfToken || "",
        "Accept": "application/json, text/plain, */*",
        "Content-Type": "application/json; charset=UTF-8",
        "Origin": "https://www.irctc.co.in",
        "Referer": "https://www.irctc.co.in/nget/payment/bkgPaymentOptions",
        "Accept-Encoding": "br, gzip, deflate"
    };

    try {
        clog(`[Booking Info] Attempting to retrieve booking data from IRCTC for client transaction ID: ${window.clientTransactionId}.`);
        const response = await fetch(apiUrl, {
            method: "GET",
            headers,
            credentials: "omit",
            cache: "no-store"
        });
        CSRFTokenResponse(response);

        if (!response.ok) {
            if (response.status === 401) {
                ui.showMessage("Session expired or unauthorized during PNR retrieval. Please re-login.", "error", 0);
                clearSessionData();
                clog("[Booking Info] HTTP 401 - Session expired during PNR retrieval.");
            } else {
                ui.showMessage(`Failed to retrieve booking info: HTTP ${response.status}. Please check your IRCTC account.`, "error", 0);
                clog(`[Booking Info] Failed to retrieve booking info. HTTP Status: ${response.status}.`);
            }
            return null;
        }

        const data = await response.json();
        if (data.bankErrorFlag === true || data.bankErrorFlag === "true") {
            ui.showMessage("Payment Not Captured By IRCTC. Please check your IRCTC account manually.", "error", 0);
            clog("[Booking Info] 'bankErrorFlag' is true/boolean true in response. Payment not captured.");
            return null;
        }
        if (data.bookingResponseDTO && data.bookingResponseDTO.length > 0) {
            clog("[Booking Info] Successfully retrieved booking details. Displaying booking success page.");
            await ui.displayBookingInfo(data, els);
            return data;
        }
        ui.showMessage("No booking details found after payment. Please check your IRCTC account manually.", "error", 0);
        clog("[Booking Info] No bookingResponseDTO found or it's empty after payment. Booking details not retrieved.");
        return null;
    } catch (error) {
        clog(`[Booking Info] Network or unexpected error during retrieveBookingInformation: ${error.message}`);
        ui.showMessage("Network error during PNR retrieval. Please check your IRCTC account manually.", "error", 0);
        return null;
    } finally {
        ui.hideLoading();
    }
}

// New Main Entry Point for the API Login Flow
async function APIMode() {
    ui.hideMessage();
    ui.showLoading("Starting Blazing Mode..");
    window.isBookingStopped = false;

    if (!els.username.value || !els.password.value) {
        ui.showMessage("Username and Password are required for API login.", "error", 0);
        ui.hideLoading();
        return;
    }

    const loginSuccess = await retrieveCaptcha(els.username.value.trim(), els.password.value.trim());

    if (loginSuccess && await validateUser()) {
        if (validateCurrentSession()) {
            els.startAutomationBtn.textContent = "Start Booking (Session Active)";
            await SequenceFlow();
        } else {
            ui.showMessage("API login succeeded, but session is not valid. Please try again.", "error", 0);
            ui.hideLoading();
        }
    } else {
        ui.showMessage("API Login failed. Please check your credentials or try Simulation Mode.", "error", 0);
        ui.hideLoading();
    }
}

// Initiates the entire automated booking sequence.
async function SequenceFlow() {
    window.isTatkalFlowActive = false;
    ui.hideMessage();
    ui.showLoading("Starting Origin !!!");

    if (!validateMainFormFields() || !validateCurrentSession()) {
        ui.hideLoading();
        return false;
    }

    BookingUI();
    GenerateTransactionId();
    buildAllPayloadTemplates();
    runWarmups();

    const bookingFlowInitiated = await MainFlow();

    if (!bookingFlowInitiated) {
        clog("[Booking Sequence] Booking sequence failed or was stopped prematurely.");
        ui.hideLoading();
        return false;
    }

    clog("[Booking Sequence] Booking sequence initiated successfully.");
    return true;
}

function getBrowserFingerprint() {
    let fingerprint = sessionStorage.getItem("browserFingerprint");
    if (!fingerprint) {
        const randomArray = new Uint8Array(16);
        crypto.getRandomValues(randomArray);
        fingerprint = Array.from(randomArray).map(b => b.toString(16).padStart(2, "0")).join("");
        sessionStorage.setItem("browserFingerprint", fingerprint);
    }
    return fingerprint;
}

function buildCommonHeaders() {
    return {
        accept: "application/json, text/plain, */*",
        origin: "https://mercury-t2.phonepe.com",
        referer: "https://mercury-t2.phonepe.com/",
    };
}
