window.stationData = null;
window.trainData = [];
let isCurrentlyLoading = false;

// For logging to console and internal log array
window.__logs = [];
["log", "info", "warn", "error", "debug"].forEach(level => {
    let originalConsoleMethod = console[level];
    console[level] = function(...args) {
        try {
            window.__logs.push({
                type: "console",
                level: level,
                timestamp: new Date().toISOString(),
                args: args.map(arg => {
                    try {
                        if (typeof arg === 'object')
                            return JSON.stringify(arg);
                        return String(arg);
                    } catch {
                        return String(arg);
                    }
                }
                )
            });
        } catch (e) {}
        originalConsoleMethod.apply(console, args);
    }
    ;
}
);

// Intercept fetch requests for logging
let originalFetch = window.fetch;
window.fetch = function(...args) {
    let timestamp = new Date().toISOString();
    window.__logs.push({
        type: "network",
        phase: "request",
        timestamp: timestamp,
        details: {
            args: args
        }
    });
    return originalFetch.apply(this, args).then(response => {
        let clonedResponse = response.clone();
        clonedResponse.text().then(body => {
            window.__logs.push({
                type: "network",
                phase: "response",
                timestamp: new Date().toISOString(),
                details: {
                    url: clonedResponse.url,
                    status: clonedResponse.status,
                    body: body
                }
            });
        }
        ).catch( () => {}
        );
        return response;
    }
    );
}
;

// Intercept XMLHttpRequest for logging
let originalXHRopen = XMLHttpRequest.prototype.open;
let originalXHRsend = XMLHttpRequest.prototype.send;

XMLHttpRequest.prototype.open = function(method, url, ...args) {
    this._logMethod = method;
    this._logUrl = url;
    originalXHRopen.call(this, method, url, ...args);
}
;

XMLHttpRequest.prototype.send = function(body) {
    let timestamp = new Date().toISOString();
    window.__logs.push({
        type: "network",
        phase: "request",
        timestamp: timestamp,
        details: {
            method: this._logMethod,
            url: this._logUrl,
            body: body
        }
    });

    this.addEventListener("loadend", () => {
        let responseTimestamp = new Date().toISOString();
        window.__logs.push({
            type: "network",
            phase: "response",
            timestamp: responseTimestamp,
            details: {
                method: this._logMethod,
                url: this._logUrl,
                status: this.status,
                response: this.response
            }
        });
    }
    );

    originalXHRsend.call(this, body);
}
;

// UI Elements (populated here and accessible to other scripts via `window.els`)
const els = {
    username: document.getElementById("username"),
    password: document.getElementById("password"),
    trainNumber: document.getElementById("trainNumber"),
    fromStation: document.getElementById("fromStation"),
    toStation: document.getElementById("toStation"),
    journeyDate: document.getElementById("journeyDate"),
    coach: document.getElementById("coach"),
    quota: document.getElementById("quota"),
    mobileNumber: document.getElementById("mobileNumber"),
    boardingStation: document.getElementById("boardingStation"),
    paymentMethod: document.getElementById("paymentMethod"),
    upiId: document.getElementById("upiId"),
    maxFare: document.getElementById("maxFare"),
    autoCaptchaCheckbox: document.getElementById("autoCaptchaCheckbox"),
    bookOnlyIfCnf: document.getElementById("bookOnlyIfCnf"),
    loginMode: document.getElementById("loginMode"),
    passengerTableBody: document.getElementById("passengerTableBody"),
    loadingOverlay: document.getElementById("loadingOverlay"),
    loadingMessage: document.getElementById("loadingMessage"),
    togglePassword: document.getElementById("togglePassword"),
    currentTimeBox: document.getElementById("currentTime"),
    startAutomationBtn: document.getElementById("startBooking"),
    hardResetBtn: document.getElementById("factoryResetBtn"),
    importJsonBtn: document.getElementById("importJsonBtn"),
    exportJsonBtn: document.getElementById("exportJsonBtn"),
    notificationPane: document.getElementById("notificationPane"),
    notificationTitle: document.getElementById("notificationTitle"),
    notificationMessage: document.getElementById("notificationMessage"),
    closeNotificationBtn: document.getElementById("closeNotificationBtn"),
    darkModeToggle: document.getElementById("darkModeToggle"),
    paxDelay: document.getElementById("paxDelay"),
    debitCardSection: document.getElementById("debitCardSection"),
    cardNumber: document.getElementById("cardNumber"),
    cardExpiry: document.getElementById("cardExpiry"),
    cardCvv: document.getElementById("cardCvv"),
    cardHolderName: document.getElementById("cardHolderName"),
    staticPassword: document.getElementById("staticPassword"),
};
window.els = els;

// Utility for console logging
function clog(message) {
    console.log(new Date().toLocaleTimeString() + ": " + message);
}

function saveFormData() {
    if (isCurrentlyLoading) {
        return;
    }

    const configData = {
        username: els.username.value.trim(),
        password: els.password.value.trim(),
        loginMode: els.loginMode.value,
        paxDelay: els.paxDelay.value,
        trainNumber: els.trainNumber.value.trim(),
        fromStation: els.fromStation.value.trim(),
        toStation: els.toStation.value.trim(),
        journeyDate: els.journeyDate.value.trim(),
        coach: els.coach.value.trim(),
        quota: els.quota.value.trim(),
        mobileNumber: els.mobileNumber.value.trim(),
        boardingStation: els.boardingStation.value.trim(),
        paymentMethod: els.paymentMethod.value.trim(),
        upiId: els.upiId.value.trim(),
        maxFare: els.maxFare.value.trim(),
        autoCaptchaCheckbox: els.autoCaptchaCheckbox.checked,
        bookOnlyIfCnf: els.bookOnlyIfCnf.checked,
        passengers: getPassengerList(),
        cardNumber: els.cardNumber.value.trim(),
        cardExpiry: els.cardExpiry.value.trim(),
        cardCvv: els.cardCvv.value.trim(),
        cardHolderName: els.cardHolderName.value.trim(),
        staticPassword: els.staticPassword.value.trim()
    };

    const dataToSave = {
        Origin_config: configData,
        username: els.username.value.trim(),
        password: els.password.value.trim()
    };

    if (window.accessToken)
        dataToSave.accessToken = window.accessToken;
    if (window.csrfToken)
        dataToSave.csrfToken = window.csrfToken;
    if (window.greq)
        dataToSave.greq = window.greq;
    if (window.bmiyek)
        dataToSave.bmiyek = window.bmiyek;
    if (window.lastSessionTime)
        dataToSave.lastSessionTime = window.lastSessionTime;

    chrome.storage.local.set(dataToSave, () => {
        clog("Form configuration and session data saved.");
    }
    );
}

function loadFromStorage() {
    // Load theme first to prevent flash of wrong theme
    chrome.storage.local.get("theme", (items) => {
        if (items.theme === 'dark') {
            document.body.classList.add('dark-mode');
            if (els.darkModeToggle)
                els.darkModeToggle.checked = true;
        } else {
            document.body.classList.remove('dark-mode');
            if (els.darkModeToggle)
                els.darkModeToggle.checked = false;
        }
    });

    chrome.storage.local.get(["Origin_config", "username", "password", "csrfToken", "accessToken", "greq", "bmiyek", "lastSessionTime"], (items) => {
        isCurrentlyLoading = true;
        try {
            clog("Attempting to load configuration and session data from storage.");

            const config = items.Origin_config || {};

            if (config.username)
                els.username.value = config.username;
            if (config.password)
                els.password.value = config.password;
            if (config.loginMode)
                els.loginMode.value = config.loginMode;
            if (config.paxDelay)
                els.paxDelay.value = config.paxDelay;
            if (config.trainNumber)
                els.trainNumber.value = config.trainNumber;
            if (config.fromStation)
                els.fromStation.value = config.fromStation;
            if (config.toStation)
                els.toStation.value = config.toStation;
            // MODIFIED: Simplified for native date input
            if (config.journeyDate) {
                els.journeyDate.value = config.journeyDate;
            }
            if (config.coach)
                els.coach.value = config.coach;

            if (config.quota) {
                els.quota.value = config.quota;
                clog(`Restored Quota from storage: ${config.quota}`);
            }

            if (config.mobileNumber)
                els.mobileNumber.value = config.mobileNumber;
            if (config.boardingStation) {
                els.boardingStation.value = config.boardingStation;
            } else {
                els.boardingStation.placeholder = "Defaults to From Station";
            }
            if (config.paymentMethod) {
                els.paymentMethod.value = config.paymentMethod;
            }
            if (config.upiId)
                els.upiId.value = config.upiId;
            if (config.maxFare)
                els.maxFare.value = config.maxFare;
            if (typeof config.autoCaptchaCheckbox !== 'undefined')
                els.autoCaptchaCheckbox.checked = config.autoCaptchaCheckbox;
            if (typeof config.bookOnlyIfCnf !== 'undefined')
                els.bookOnlyIfCnf.checked = config.bookOnlyIfCnf;

            // --- DEBIT CARD FIELDS LOADING ---
            if (config.cardNumber) els.cardNumber.value = config.cardNumber;
            if (config.cardExpiry) els.cardExpiry.value = config.cardExpiry;
            if (config.cardCvv) els.cardCvv.value = config.cardCvv;
            if (config.cardHolderName) els.cardHolderName.value = config.cardHolderName;
            if (config.staticPassword) els.staticPassword.value = config.staticPassword;
            // --- END DEBIT CARD FIELDS ---

            // Manually trigger change event to update UI visibility after loading data
            els.paymentMethod.dispatchEvent(new Event('change'));

            window.csrfToken = items.csrfToken || "";
            window.accessToken = items.accessToken || "";
            window.greq = items.greq || "";
            window.bmiyek = items.bmiyek || "";
            window.lastSessionTime = items.lastSessionTime || null;

            clog("Configuration and session data loaded.");

            if (els.passengerTableBody) {
                els.passengerTableBody.innerHTML = '';
                if (config.passengers && config.passengers.length > 0) {
                    config.passengers.forEach(p => ui.addPassengerRow(p));
                    clog(`Restored ${config.passengers.length} passenger(s).`);
                } else {
                    ui.addPassengerRow();
                }
            } else {
                clog("Warning: passengerTableBody not found during loadFromStorage.");
            }

            if (validateCurrentSession()) {
                els.startAutomationBtn.textContent = "Start Booking (Session Active)";
            } else {
                els.startAutomationBtn.textContent = "Start Booking (Login Required)";
            }
        } finally {
            isCurrentlyLoading = false;
        }
    });
}

function clearSessionData() {
    window.csrfToken = "";
    window.accessToken = "";
    window.greq = "";
    window.bmiyek = "";
    window.lastSessionTime = null;
    chrome.storage.local.remove(["csrfToken", "accessToken", "greq", "bmiyek", "lastSessionTime", "sensorData"], () => {
        clog("Session data cleared from storage.");
    }
    );
}

async function fetchAndCache(cacheKey, url, fetchOptions={}, processFn= (data) => data) {
    const cached = await new Promise(resolve => chrome.storage.local.get(cacheKey, items => resolve(items[cacheKey])));
    if (cached && Array.isArray(cached) && cached.length > 0) {
        clog(`Using cached data for '${cacheKey}'.`);
        return cached;
    }

    clog(`Fetching fresh data for '${cacheKey}' from ${url}`);
    ui.showLoading(`Fetching ${cacheKey.replace('Data', '')} data...`);
    try {
        const response = await fetch(url, fetchOptions);

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        const processedData = processFn(data);

        await new Promise(resolve => chrome.storage.local.set({
            [cacheKey]: processedData
        }, resolve));
        clog(`'${cacheKey}' data fetched and cached.`);

        return processedData;

    } catch (error) {
        clog(`❌ Error fetching '${cacheKey}': ${error.message}`);
        ui.showMessage(`Failed to fetch ${cacheKey.replace('Data', '')} data. Please try again.`, "error", 0);
        throw error;
    } finally {
        ui.hideLoading();
    }
}

async function fetchStationData() {
    try {
        window.stationData = await fetchAndCache('stationData', 'https://www.irctc.co.in/eticketing/protected/mapps1/stationData', {
            method: "GET",
            credentials: "include",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
        });
        ui.attachAutocomplete("fromStation");
        ui.attachAutocomplete("toStation");
        ui.attachAutocomplete("boardingStation");
        return window.stationData;
    } catch (error) {
        return null;
    }
}

async function fetchTrainData() {
    try {
        window.trainData = await fetchAndCache('trainData', 'https://www.indianrail.gov.in/enquiry/FetchTrainData', {
            method: "GET",
            headers: {
                "Connection": "close",
                "sec-ch-ua-platform": "\"Android\"",
                "X-Requested-With": "XMLHttpRequest",
                "Accept": "*/*",
                "sec-ch-ua": "\"Chromium\";v=\"134\", \"Not:A-Brand\";v=\"24\", \"Google Chrome\";v=\"134\"",
                "DNT": "1",
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Dest": "empty",
                "Accept-Encoding": "gzip, deflate, br",
                "Accept-Language": "en-US,en;q=0.9"
            }
        }, (rawData) => rawData.map(item => {
            const [number,name] = item.split(" - ").map(s => s.trim());
            return {
                number,
                name
            };
        }
        ));
        ui.attachTrainAutocomplete("trainNumber");
        return window.trainData;
    } catch (error) {
        return null;
    }
}

// --- Dynamic Passenger Table Management ---
function getPassengerList() {
    const passengerRows = document.querySelectorAll("#passengerTableBody tr");
    const passengers = [];
    passengerRows.forEach( (row, index) => {
        const inputs = row.querySelectorAll("input, select");
        const passengerName = inputs[0].value.trim();
        const passengerAge = inputs[1].value.trim();
        const passengerGender = inputs[2].value || "";
        let passengerBerthChoice = inputs[3].value.trim();
        if (!passengerBerthChoice)
            passengerBerthChoice = "";
        let passengerFoodChoice = inputs[4].value.trim();
        if (passengerFoodChoice === "Meal Not Applicable")
            passengerFoodChoice = null;
        const needsChildBerth = row.dataset.childBerth === "true";

        passengers.push({
            passengerName,
            passengerAge,
            passengerGender,
            passengerBerthChoice,
            passengerFoodChoice,
            passengerNationality: "IN",
            passengerSerialNumber: index + 1,
            passengerBedrollChoice: null,
            passengerCardTypeMaster: "NULL_IDCARD",
            passengerCardNumberMaster: "",
            psgnConcType: null,
            psgnConcCardId: null,
            psgnConcDOB: null,
            psgnConcCardExpiryDate: null,
            psgnConcDOBP: null,
            softMemberId: null,
            softMemberFlag: false,
            psgnConcCardExpiryDateP: null,
            passengerVerified: false,
            masterPsgnId: null,
            mpMemberFlag: false,
            passengerForceNumber: null,
            passConcessionType: "0",
            passUPN: null,
            passBookingCode: null,
            childBerthFlag: needsChildBerth,
            passengerCardType: "NULL_IDCARD",
            passengerIcardFlag: false,
            passengerCardNumber: null
        });
    }
    );
    return passengers;
}

const validationRules = [{
    el: () => els.username,
    test: (v) => v.trim() !== '',
    msg: "Please fill the 'Username' field."
}, {
    el: () => els.password,
    test: (v) => v.trim() !== '',
    msg: "Please fill the 'Password' field."
}, {
    el: () => els.mobileNumber,
    test: (v) => v.trim() !== '',
    msg: "Please fill the 'Mobile Number' field."
}, {
    el: () => els.mobileNumber,
    test: (v) => /^\d{10}$/.test(v.trim()),
    msg: "Mobile number must be exactly 10 digits."
}, {
    el: () => els.trainNumber,
    test: (v) => v.trim() !== '',
    msg: "Please fill the 'Train Number' field."
}, {
    el: () => els.fromStation,
    test: (v) => v.trim() !== '',
    msg: "Please fill the 'From Station' field."
}, {
    el: () => els.toStation,
    test: (v) => v.trim() !== '',
    msg: "Please fill the 'To Station' field."
}, {
    el: () => els.coach,
    test: (v) => v.trim() !== '',
    msg: "Please select a 'Class'."
}, {
    el: () => els.quota,
    test: (v) => v.trim() !== '',
    msg: "Please select a 'Quota'."
}, {
    el: () => els.journeyDate,
    test: (v) => v.trim() !== '',
    msg: "Please select a 'Date of Journey'."
}, {
    el: () => els.paymentMethod,
    test: (v) => v.trim() !== '',
    msg: "Please select a 'Payment Method'."
}, {
    el: () => els.upiId,
    test: (v) => /^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z0-9]{2,64}$/.test(v.trim()),
    msg: "Please enter a valid UPI ID (e.g., yourname@bank).",
    condition: () => ["upi", "paytmupi"].includes(els.paymentMethod.value)
}, 
{
    el: () => els.cardNumber,
    test: (v) => /^\d{15,16}$/.test(v.replace(/\s/g, '')),
    msg: "Please enter a valid 15 or 16-digit card number.",
    condition: () => els.paymentMethod.value === 'debitcard'
}, {
    el: () => els.cardHolderName,
    test: (v) => v.trim() !== '',
    msg: "Please enter the name on the card.",
    condition: () => els.paymentMethod.value === 'debitcard'
}, {
    el: () => els.cardExpiry,
    test: (v) => /^(0[1-9]|1[0-2])\/\d{2}$/.test(v.trim()),
    msg: "Please enter a valid expiry date in MM/YY format.",
    condition: () => els.paymentMethod.value === 'debitcard'
}, {
    el: () => els.cardCvv,
    test: (v) => /^\d{3}$/.test(v.trim()),
    msg: "Please enter a valid 3-digit CVV.",
    condition: () => els.paymentMethod.value === 'debitcard'
}, {
    el: () => els.staticPassword,
    test: (v) => v.trim() !== '',
    msg: "Please enter the static password for your card.",
    condition: () => els.paymentMethod.value === 'debitcard'
},
{
    el: () => els.passengerTableBody,
    test: () => getPassengerList().length > 0,
    msg: "Please add at least one passenger."
}, {
    el: () => els.passengerTableBody,
    test: () => {
        const passengers = getPassengerList();
        const quota = els.quota.value.trim().toUpperCase();
        const max = (quota === "TQ" || quota === "PT") ? 4 : 6;
        return passengers.length <= max;
    },
    msg: () => {
        const quota = els.quota.value.trim().toUpperCase();
        const max = (quota === "TQ" || quota === "PT") ? 4 : 6;
        return `A maximum of ${max} passengers are allowed for the selected quota (${quota}).`;
    }
}];

function validateMainFormFields() {
    for (const rule of validationRules) {
        if (rule.condition && !rule.condition()) {
            continue;
        }

        const value = rule.el().value;
        if (!rule.test(value)) {
            const errorMessage = typeof rule.msg === 'function' ? rule.msg() : rule.msg;
            ui.showMessage(errorMessage, "error", 0);
            return false;
        }
    }

    const passengers = getPassengerList();
    for (const passenger of passengers) {
        const name = passenger.passengerName.trim();
        const age = parseInt(passenger.passengerAge, 10);

        if (!/^[A-Za-z\s]+$/.test(name) || name === "") {
            ui.showMessage(`Invalid passenger name: "${passenger.passengerName}". Only letters and spaces are allowed, and it cannot be empty.`, "error", 0);
            return false;
        }
        if (!Number.isInteger(age) || age <= 0 || age > 150) {
            ui.showMessage(`Invalid age for ${name}: "${passenger.passengerAge}". It must be a positive number.`, "error", 0);
            return false;
        }
        if (!["M", "F"].includes(passenger.passengerGender)) {
            ui.showMessage(`Invalid gender for ${name}.`, "error", 0);
            return false;
        }
    }

    const berthCounts = {};
    const restrictedBerths = ["LB", "MB", "UB", "SL", "SU", "WS"];
    for (const passenger of passengers) {
        const berthChoice = (passenger.passengerBerthChoice || "").toUpperCase();
        if (restrictedBerths.includes(berthChoice)) {
            berthCounts[berthChoice] = (berthCounts[berthChoice] || 0) + 1;
            if (berthCounts[berthChoice] > 2) {
                ui.showMessage(`No more than 2 passengers can choose the same berth preference "${berthChoice}".`, "error", 0);
                return false;
            }
        }
        if ((els.coach.value === "1A" || els.coach.value === "2A") && berthChoice === "MB") {
            ui.showMessage(`Middle Berth (MB) is not available in ${els.coach.value}.`, "error", 0);
            return false;
        }
    }

    return true;
}

// --- Event Listeners and Initialization ---
document.addEventListener("DOMContentLoaded", () => {
    loadFromStorage();

    // Native Date Picker Initialization
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    if (els.journeyDate) {
        els.journeyDate.min = `${yyyy}-${mm}-${dd}`;
        // Set default to tomorrow only if no value was loaded from storage
        if (!els.journeyDate.value) {
            const tomorrow = new Date();
            tomorrow.setDate(today.getDate() + 1);
            const yyyy_t = tomorrow.getFullYear();
            const mm_t = String(tomorrow.getMonth() + 1).padStart(2, '0');
            const dd_t = String(tomorrow.getDate()).padStart(2, '0');
            els.journeyDate.value = `${yyyy_t}-${mm_t}-${dd_t}`;
        }
    }

    const formElementsToSave = [
        els.username, els.password, els.trainNumber, els.fromStation, els.toStation,
        els.journeyDate, els.coach, els.quota, els.mobileNumber, els.boardingStation,
        els.paymentMethod, els.upiId, els.maxFare, els.autoCaptchaCheckbox, els.bookOnlyIfCnf,
        els.paxDelay,
        // Add debit card fields to auto-save
        els.cardNumber, els.cardExpiry, els.cardCvv, els.cardHolderName, els.staticPassword
    ];

    formElementsToSave.forEach(element => {
        if (element) {
            element.addEventListener("input", saveFormData);
            element.addEventListener("change", saveFormData);
        }
    });

    // Theme Toggle Logic
    if (els.darkModeToggle) {
        els.darkModeToggle.addEventListener('change', () => {
            if (els.darkModeToggle.checked) {
                document.body.classList.add('dark-mode');
                chrome.storage.local.set({ theme: 'dark' });
                clog("Theme changed to Dark Mode and saved.");
            } else {
                document.body.classList.remove('dark-mode');
                chrome.storage.local.set({ theme: 'light' });
                clog("Theme changed to Light Mode and saved.");
            }
        });
    }

    // Populate PAX Delay Dropdown
    if (els.paxDelay) {
        const autoOption = document.createElement('option');
        autoOption.value = 'auto';
        autoOption.textContent = 'Auto';
        autoOption.selected = true;
        els.paxDelay.appendChild(autoOption);
        for (let i = 1; i <= 50; i++) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = `${i} sec`;
            els.paxDelay.appendChild(option);
        }
    }

    document.getElementById("addPassenger").addEventListener("click", () => {
        ui.addPassengerRow();
        saveFormData();
    });

    // --- CORRECTED PAYMENT METHOD LISTENER ---
    els.paymentMethod.addEventListener('change', () => {
        const selectedMethod = els.paymentMethod.value;
        const upiInputGroup = document.getElementById("upiInputGroup");

        // Hide all conditional sections first by ADDING the .hidden class
        upiInputGroup.classList.add("hidden");
        if (els.debitCardSection) {
            els.debitCardSection.classList.add("hidden");
        }

        // Show the relevant section by REMOVING the .hidden class
        if (selectedMethod === "upi" || selectedMethod === "paytmupi") {
            upiInputGroup.classList.remove("hidden");
        } else if (selectedMethod === "debitcard") {
            if (els.debitCardSection) {
                els.debitCardSection.classList.remove("hidden");
            }
        }
        
        saveFormData();
    });
    // --- END OF CORRECTION ---

    els.togglePassword.addEventListener("click", () => {
        const type = els.password.type === "password" ? "text" : "password";
        els.password.type = type;
        els.togglePassword.textContent = type === "password" ? "👁️" : "🙈";
    });

    fetchStationData();
    fetchTrainData();
    ui.showCurrentTimeBox();

    els.hardResetBtn.addEventListener("click", () => {
        if (confirm("This will clear ALL extension data and settings. This cannot be undone.\n\nProceed with HARD RESET?")) {
            chrome.runtime.sendMessage({ action: "factoryReset" }, (response) => {
                if (response && response.success) {
                    ui.showMessage("Extension reset successfully. Please reload the extension.", "success");
                    setTimeout(() => window.location.reload(), 2000);
                } else {
                    ui.showMessage("Failed to reset extension. Check console for errors.", "error", 0);
                }
            });
        }
    });

    els.coach.addEventListener("change", () => {
        document.querySelectorAll("#passengerTableBody tr").forEach(row => {
            const berthSelect = row.querySelector(".passenger-berth");
            if (berthSelect) {
                ui.updateBerthOptions(berthSelect, berthSelect.value);
            }
        });
        saveFormData();
    });

    // Import/Export JSON Logic
        els.exportJsonBtn.addEventListener("click", () => {
    // 1. Gather data from the form
        const configData = {
        username: els.username.value.trim(),
        password: els.password.value.trim(),
        loginMode: els.loginMode.value,
        trainNumber: els.trainNumber.value.trim(),
        fromStation: els.fromStation.value.trim(),
        toStation: els.toStation.value.trim(),
        journeyDate: els.journeyDate.value.trim(),
        coach: els.coach.value.trim(),
        quota: els.quota.value.trim(),
        mobileNumber: els.mobileNumber.value.trim(),
        boardingStation: els.boardingStation.value.trim(),
        paymentMethod: els.paymentMethod.value.trim(),
        upiId: els.upiId.value.trim(),
        maxFare: els.maxFare.value.trim(),
        autoCaptchaCheckbox: els.autoCaptchaCheckbox.checked,
        bookOnlyIfCnf: els.bookOnlyIfCnf.checked,
        passengers: getPassengerList(),
        cardNumber: els.cardNumber.value.trim(),
        cardExpiry: els.cardExpiry.value.trim(),
        cardCvv: els.cardCvv.value.trim(),
        cardHolderName: els.cardHolderName.value.trim(),
        staticPassword: els.staticPassword.value.trim()
    };

    // 2. Convert to a JSON string and create a Blob
    const jsonString = JSON.stringify(configData, null, 2);
    const blob = new Blob([jsonString], {
        type: "application/json"
    });

    // 3. Create a temporary link to trigger the download
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `TicketDump-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();

    // 4. Clean up the temporary link and URL
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    ui.showMessage("Configuration exported successfully.", "success");
});

els.importJsonBtn.addEventListener("click", () => {
    // 1. Create a temporary file input element
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.json,application/json';
    fileInput.style.display = 'none';

    // 2. Add a 'change' listener to handle file selection
    fileInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (!file)
            return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importedData = JSON.parse(e.target.result);

                // Prevent auto-saving during population
                isCurrentlyLoading = true;

                // Populate fields, checking if each key exists
                if (importedData.username) els.username.value = importedData.username;
                if (importedData.password) els.password.value = importedData.password;
                if (importedData.loginMode) els.loginMode.value = importedData.loginMode;
                if (importedData.trainNumber) els.trainNumber.value = importedData.trainNumber;
                if (importedData.fromStation) els.fromStation.value = importedData.fromStation;
                if (importedData.toStation) els.toStation.value = importedData.toStation;
                if (importedData.coach) els.coach.value = importedData.coach;
                if (importedData.quota) els.quota.value = importedData.quota;
                if (importedData.mobileNumber) els.mobileNumber.value = importedData.mobileNumber;
                if (importedData.boardingStation) els.boardingStation.value = importedData.boardingStation;
                if (importedData.paymentMethod) els.paymentMethod.value = importedData.paymentMethod;
                if (importedData.upiId) els.upiId.value = importedData.upiId;
                if (importedData.maxFare) els.maxFare.value = importedData.maxFare;
                if (importedData.journeyDate) els.journeyDate.value = importedData.journeyDate;
                if (typeof importedData.autoCaptchaCheckbox !== 'undefined') els.autoCaptchaCheckbox.checked = importedData.autoCaptchaCheckbox;
                if (typeof importedData.bookOnlyIfCnf !== 'undefined') els.bookOnlyIfCnf.checked = importedData.bookOnlyIfCnf;
                if (importedData.cardNumber) els.cardNumber.value = importedData.cardNumber;
                if (importedData.cardExpiry) els.cardExpiry.value = importedData.cardExpiry;
                if (importedData.cardCvv) els.cardCvv.value = importedData.cardCvv;
                if (importedData.cardHolderName) els.cardHolderName.value = importedData.cardHolderName;
                if (importedData.staticPassword) els.staticPassword.value = importedData.staticPassword;

                // Populate passengers
                if (els.passengerTableBody && Array.isArray(importedData.passengers)) {
                    els.passengerTableBody.innerHTML = ''; // Clear existing
                    importedData.passengers.forEach(p => ui.addPassengerRow(p));
                }

                // Manually trigger change events for UI updates
                els.paymentMethod.dispatchEvent(new Event('change'));
                els.coach.dispatchEvent(new Event('change'));

                // Re-enable saving and save the new state
                isCurrentlyLoading = false;
                saveFormData();
                ui.showMessage("Configuration imported successfully.", "success");

            } catch (error) {
                console.error("Error parsing or applying JSON file:", error);
                ui.showMessage("Import failed. The file may be invalid.", "error", 0);
            } finally {
                isCurrentlyLoading = false; // Ensure saving is always re-enabled
            }
        };
        reader.onerror = () => ui.showMessage("Error reading the file.", "error", 0);
        reader.readAsText(file);
    });

    // 3. Trigger the file dialog and clean up
    document.body.appendChild(fileInput);
    fileInput.click();
    document.body.removeChild(fileInput);
});

    els.closeNotificationBtn.addEventListener('click', ui.hideMessage);
});

els.startAutomationBtn.addEventListener("click", async (event) => {
    event.preventDefault();
    saveFormData();

    if (!validateMainFormFields()) {
        return;
    }

    ui.hideMessage();

    // If session is already active, proceed directly to booking.
    if (validateCurrentSession()) {
        await SequenceFlow();
        return;
    }

    // If session is not active, determine which login method to use.
    const selectedLoginMode = els.loginMode.value;
    clog(`No active session. Selected login mode: ${selectedLoginMode.toUpperCase()}`);

    if (selectedLoginMode === 'simulation') {
        ui.showLoading("IRCTC Website - Opened Login !!");
        clog("Triggering IRCTC login simulation in background...");
        chrome.runtime.sendMessage({
            action: "SimulationMode"
        }, (response) => {
            if (response && response.success) {
                clog("IRCTC login simulation started successfully.");
            } else {
                clog("❌ Failed to start IRCTC login simulation: " + (response ? response.error : "Unknown error"));
                ui.showMessage("Failed to start automation. Please ensure IRCTC is accessible.", "error", 0);
                ui.hideLoading();
            }
        }
        );

    } else if (selectedLoginMode === 'api') {
        ui.showLoading("Starting Direct LOGIN!");
        clog("Requesting background script to establish initial session...");
        chrome.runtime.sendMessage({
            action: "APIMode"
        }, (response) => {
            if (response && response.success) {
                clog("Background session preparation complete.");
                APIMode();
            } else {
                clog("❌ Failed to prepare API session: " + (response ? response.error : "Unknown error"));
                ui.showMessage("Failed to prepare API session. Please try again.", "error", 0);
                ui.hideLoading();
            }
        }
        );
    }
}
);

chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    if (message.action === "simulationComplete") {
        clog("✅ Browser automation simulation complete. Status: " + message.status);
        ui.hideLoading();
        ui.showMessage("Login simulation completed. Retrieving session tokens...", "info");

        if (message.status === "success") {
            await new Promise(resolve => {
                chrome.storage.local.get(["accessToken", "csrfToken", "greq", "bmiyek", "lastSessionTime"], (items) => {
                    window.accessToken = items.accessToken || "";
                    window.csrfToken = items.csrfToken || "";
                    window.greq = items.greq || "";
                    window.bmiyek = items.bmiyek || "";
                    window.lastSessionTime = items.lastSessionTime || null;
                    if (window.accessToken && window.csrfToken && window.greq && window.bmiyek) {
                        window.lastSessionTime = Date.now();
                    }
                    saveFormData();
                    resolve();
                }
                );
            }
            );

            if (validateCurrentSession()) {
                ui.showMessage("Tokens retrieved! Starting booking sequence...", "success");
                clog("Tokens captured: accessToken, csrfToken, greq, bmiyek");
                els.startAutomationBtn.textContent = "Start Booking (Session Active)";
                await SequenceFlow();
            } else {
                ui.showMessage("Automation completed, but crucial tokens were not captured. Please try again.", "error", 0);
                clog("❌ Tokens missing or invalid after simulation.");
                els.startAutomationBtn.textContent = "Start Booking (Login Required)";
            }
        } else {
            ui.showMessage("IRCTC browser automation failed: " + message.error, "error", 0);
            clog("❌ Browser automation failed: " + message.error);
            els.startAutomationBtn.textContent = "Start Booking (Login Required)";
        }
    } else if (message.action === "showPopup") {
        ui.showMessage(message.message, "error", 0);
        ui.hideLoading();
    } else if (message.action === "cookiesReady") {
        clog("Received cookiesReady signal from background.");
        await new Promise(resolve => {
            chrome.storage.local.get(["accessToken", "csrfToken", "greq", "bmiyek", "lastSessionTime"], (items) => {
                window.accessToken = items.accessToken || "";
                window.csrfToken = items.csrfToken || "";
                window.greq = items.greq || "";
                window.bmiyek = items.bmiyek || "";
                window.lastSessionTime = items.lastSessionTime || null;
                if (window.accessToken && window.csrfToken && window.greq && window.bmiyek) {
                    window.lastSessionTime = Date.now();
                }
                saveFormData();
                resolve();
            }
            );
        }
        );

        if (validateCurrentSession()) {
            clog("Tokens confirmed. Starting booking sequence.");
            ui.showMessage("IRCTC session established. Starting booking sequence...", "success");
            els.startAutomationBtn.textContent = "Start Booking (Session Active)";
            await SequenceFlow();
        } else {
            clog("Tokens still not fully available after cookiesReady signal.");
            ui.showMessage("IRCTC session could not be fully established. Please try re-running automation.", "error", 0);
            els.startAutomationBtn.textContent = "Start Booking (Login Required)";
        }
    }
}
);
