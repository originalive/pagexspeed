let irctcTabId = null;
let isSimulating = false;
let currentDebugTab = null;
const pendingRequests = new Map();
let bmiyekCaptured = false;
let isWaitingForInitialLoad = false;
let isWaitingForPostReloadLoad = false;

chrome.runtime.onMessage.addListener( (message, sender, sendResponse) => {
    if (message.action === "SimulationMode") {
        const openTrainSearchTab = () => {
            chrome.tabs.create({
                url: "https://www.irctc.co.in/nget/train-search",
                active: true
            }, (tab) => {
                irctcTabId = tab.id;
                isWaitingForInitialLoad = true;
                isWaitingForPostReloadLoad = false;
                console.log(`IRCTC Tab created with ID: ${irctcTabId}. Waiting for initial load.`);
            }
            );
        }
        ;
        if (irctcTabId !== null) {
            chrome.tabs.remove(irctcTabId, () => {
                irctcTabId = null;
                isSimulating = false;
                isWaitingForInitialLoad = false;
                isWaitingForPostReloadLoad = false;
                openTrainSearchTab();
            }
            );
        } else if (isSimulating || isWaitingForInitialLoad || isWaitingForPostReloadLoad) {
            sendResponse({
                success: false,
                error: "Simulation or wait sequence in progress"
            });
            return true;
        } else {
            openTrainSearchTab();
        }
        sendResponse({
            success: true
        });
        return true;
    }

    // Handle other messages like APIMode, clearCookies, showPopup, factoryReset
    if (message.action === "APIMode") {
        let tempTabId = null;
        chrome.tabs.create({
            url: "https://www.irctc.co.in/nget/train-search",
            active: true
        }, (tab) => {
            tempTabId = tab.id;
            const tabUpdateListener = (updatedTabId, changeInfo, tabInfo) => {
                if (updatedTabId === tempTabId && changeInfo.status === "complete") {
                    chrome.tabs.onUpdated.removeListener(tabUpdateListener);
                    setTimeout( () => {
                        chrome.tabs.remove(tempTabId, () => {
                            if (chrome.runtime.lastError) {
                                sendResponse({
                                    success: false,
                                    error: "Failed to close temp tab."
                                });
                            } else {
                                sendResponse({
                                    success: true
                                });
                            }
                        }
                        );
                    }
                    , 14500);
                }
            }
            ;
            chrome.tabs.onUpdated.addListener(tabUpdateListener);
        }
        );
        return true;
    }

    if (message.action === "clearCookies") {
        chrome.cookies.getAll({
            domain: "irctc.co.in"
        }, cookies => {
            cookies.forEach(c => {
                const url = (c.secure ? "https://" : "http://") + c.domain.replace(/^\./, "") + c.path;
                chrome.cookies.remove({
                    url,
                    name: c.name
                });
            }
            );
            sendResponse({
                success: true
            });
        }
        );
        return true;
    }

    if (message.action === "showPopup") {
        alert(message.message);
        // Fixed variable name from 'msg' to 'message'
        sendResponse({
            success: true
        });
        // Good practice to respond
        return true;
    }

    if (message.action === "factoryReset") {
        // Call the consolidated factory reset function
        factoryResetExtension().then( () => {
            sendResponse({
                success: true,
                message: "Factory reset completed."
            });
        }
        ).catch( (error) => {
            console.error("Factory reset failed:", error);
            sendResponse({
                success: false,
                error: error.message || "Factory reset failed."
            });
        }
        );
        return true;
        // Indicates asynchronous response
    }

    // Handle getStoredCredentials
    if (message.action === "getStoredCredentials") {
        chrome.storage.local.get(['username', 'password'], items => {
            sendResponse({
                username: items.username || '',
                password: items.password || ''
            });
        }
        );
        return true;
    }

    // Handle attachDebugger
    if (message.action === "attachDebugger") {
        setupDebuggerForTab(message.tabId);
        sendResponse({
            success: true
        });
        return true;
        // Ensure response is sent for attachDebugger
    }

    // Handle fetchTrainData - Fixed variable name from 'request' to 'message'
    if (message.action === "fetchTrainData") {
        fetch("https://www.indianrail.gov.in/enquiry/FetchTrainData", {
            method: "GET",
            headers: {
                "Connection": "close",
                "sec-ch-ua-platform": "\"macOS\"",
                "X-Requested-With": "XMLHttpRequest",
                "Accept": "*/*",
                "sec-ch-ua": "\"Chromium\";v=\"134\", \"Not:A-Brand\";v=\"24\", \"Google Chrome\";v=\"134\"",
                "DNT": "1",
                "sec-ch-ua-mobile": "?0",
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Dest": "empty",
                "Accept-Encoding": "gzip, deflate, br",
                "Accept-Language": "en-US,en;q=0.9"
            }
        }).then(res => {
            if (!res.ok)
                throw new Error(`Status ${res.status}`);
            return res.json();
        }
        ).then(data => {
            const processed = data.map(item => {
                const [number,name] = item.split(" - ").map(s => s.trim());
                return {
                    number,
                    name
                };
            }
            );
            sendResponse({
                success: true,
                processed
            });
        }
        ).catch(err => sendResponse({
            success: false,
            error: err.toString()
        }));
        return true;
    }
}
);

initializeDebuggerListener();

// Initializes the debugger listener for network events.
function initializeDebuggerListener() {
    chrome.debugger.onEvent.addListener( (debuggeeId, method, params) => {
        if (debuggeeId.tabId !== currentDebugTab)
            return;
        const urlPattern = /getUserProfile/;
        if (method === "Network.requestWillBeSent") {
            const {request} = params;
            const url = request.url;
            if (urlPattern.test(url)) {
                const headers = request.headers;
                const bmiyek = Object.entries(headers).find( ([name]) => name.toLowerCase() === "bmiyek")?.[1];
                if (bmiyek) {
                    bmiyekCaptured = true;
                    chrome.storage.local.set({
                        bmiyek
                    });
                }
                const authHeader = Object.entries(headers).find( ([name]) => name.toLowerCase() === "authorization")?.[1];
                if (authHeader && authHeader.startsWith("Bearer ")) {
                    const accessToken = authHeader.substring(7);
                    chrome.storage.local.set({
                        accessToken
                    });
                }
                const greq = Object.entries(headers).find( ([name]) => name.toLowerCase() === "greq")?.[1];
                if (greq)
                    chrome.storage.local.set({
                        greq
                    });
            }
            if (request.method === "POST" && /https?:\/\/(www\.)?irctc\.co\.in/.test(url) && !(/loginCaptcha/.test(url) || /webtoken/.test(url) || /validateUser/.test(url) || /avlFarenquiry/.test(url) || /boardingStationEnq/.test(url) || /allLapAvlFareEnq/.test(url) || /addonServices/.test(url) || /bookingInitPayment/.test(url))) {
                const postData = request.postData;
                if (postData) {
                    try {
                        const bodyJson = JSON.parse(postData);
                        if (bodyJson.sensor_data) {
                            chrome.storage.local.set({
                                sensorData: bodyJson.sensor_data
                            });
                        }
                    } catch (e) {// Silently ignore JSON parse errors for sensor data
                    }
                }
            }
        } else if (method === "Network.responseReceived") {
            const {requestId, response} = params;
            const url = response.url;
            if (urlPattern.test(url)) {
                const headers = response.headers || {};
                const csrfToken = Object.entries(headers).find( ([name]) => name.toLowerCase() === "csrf-token")?.[1];
                if (csrfToken) {
                    chrome.storage.local.set({
                        csrfToken
                    });
                }
                const greq = Object.entries(headers).find( ([name]) => name.toLowerCase() === "x-greq")?.[1];
                if (greq)
                    chrome.storage.local.set({
                        greq
                    });
                const authHeader = Object.entries(headers).find( ([name]) => name.toLowerCase() === "authorization")?.[1];
                if (authHeader && authHeader.startsWith("Bearer ")) {
                    const accessToken = authHeader.substring(7);
                    chrome.storage.local.set({
                        accessToken
                    });
                }
                checkAllTokensCaptured();
            }
            if (/allLapAvlFareEnq/.test(url) || /addonServices/.test(url)) {
                pendingRequests.set(requestId, {
                    url,
                    headers: /allLapAvlFareEnq/.test(url) ? response.headers : undefined
                });
            }
        } else if (method === "Network.loadingFinished") {
            const {requestId} = params;
            const entry = pendingRequests.get(requestId);
            if (!entry)
                return;
            pendingRequests.delete(requestId);
            chrome.debugger.sendCommand({
                tabId: debuggeeId.tabId
            }, "Network.getResponseBody", {
                requestId
            }, (result) => {
                if (chrome.runtime.lastError)
                    return;
                let data;
                try {
                    data = JSON.parse(result.body || "");
                } catch {
                    return;
                }
                const url = entry.url;
                if (/allLapAvlFareEnq/.test(url)) {
                    chrome.storage.local.get("paymentMethod", ({paymentMethod}) => {
                        if (paymentMethod === "paytm") {
                            const details = data.bankDetailDTO || [];
                            const paytmUp = details.some(d => d.bankId === "78" || d.bankId === "117");
                            if (paytmUp) {
                                chrome.storage.local.set({
                                    bankId: "78"
                                });
                            } else {
                                chrome.runtime.sendMessage({
                                    action: "showPopup",
                                    message: "PayTM Gateway is Down, Use IRCTC UPI or Wallet"
                                });
                                cleanupDebugger(debuggeeId.tabId);
                                chrome.tabs.remove(debuggeeId.tabId, () => {
                                    currentDebugTab = null;
                                }
                                );
                            }
                        }
                    }
                    );
                } else if (/addonServices/.test(url)) {
                    chrome.storage.local.get(["paymentMethod", "bankId"], ({paymentMethod, bankId}) => {
                        if (paymentMethod === "paytm" && !bankId) {
                            const details = data.bankDetailDTO || [];
                            const paytmUp = details.some(d => d.bankId === "78" || d.bankId === "117");
                            if (paytmUp) {
                                chrome.storage.local.set({
                                    bankId: "78"
                                });
                            } else {
                                chrome.runtime.sendMessage({
                                    action: "showPopup",
                                    message: "PayTM Gateway is Down, Use IRCTC UPI or Wallet"
                                });
                                cleanupDebugger(debuggeeId.tabId);
                                chrome.tabs.remove(debuggeeId.tabId, () => {
                                    currentDebugTab = null;
                                }
                                );
                            }
                        }
                    }
                    );
                }
            }
            );
        } else if (method === "Network.loadingFailed") {
            pendingRequests.delete(params.requestId);
        }
    }
    );
}

// Checks if all required tokens (bmiyek, csrfToken, greq, accessToken) are captured.
function checkAllTokensCaptured() {
    chrome.storage.local.get(["bmiyek", "csrfToken", "greq", "accessToken"], (items) => {
        if (items.bmiyek && items.csrfToken && items.greq && items.accessToken) {
            chrome.runtime.sendMessage({
                action: "cookiesReady"
            });
            if (currentDebugTab) {
                cleanupDebugger(currentDebugTab);
                chrome.tabs.remove(currentDebugTab, () => {
                    currentDebugTab = null;
                    irctcTabId = null;
                    isSimulating = false;
                }
                );
            }
        }
    }
    );
}

// Sets up the Chrome debugger for a specific tab to monitor network activity.
function setupDebuggerForTab(tabId) {
    chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError || !tab) {
            console.warn("Failed to get tab for debugger setup:", chrome.runtime.lastError?.message);
            return;
        }
        currentDebugTab = tabId;
        chrome.debugger.attach({
            tabId
        }, "1.3", () => {
            if (chrome.runtime.lastError) {
                console.warn("Failed to attach debugger:", chrome.runtime.lastError.message);
                return;
            }
            chrome.debugger.sendCommand({
                tabId
            }, "Network.enable", {}, () => {
                if (chrome.runtime.lastError) {
                    console.warn("Failed to enable Network domain:", chrome.runtime.lastError.message);
                    cleanupDebugger(tabId);
                    // Cleanup on failure
                }
            }
            );
        }
        );
    }
    );
}

chrome.tabs.onUpdated.addListener( (tabId, changeInfo, tab) => {
    if (tabId !== irctcTabId) {
        return;
    }
    // --- Phase 1: Wait for Initial Load and Reload ---
    if (isWaitingForInitialLoad && changeInfo.status === 'complete') {
        console.log(`IRCTC Tab ${tabId} initial load complete. Scheduling reload.`);
        isWaitingForInitialLoad = false;
        // Schedule the reload after a short delay to ensure stability
        setTimeout( () => {
            chrome.tabs.get(tabId, (updatedTab) => {
                // Double-check the tab still exists and is the right one
                if (chrome.runtime.lastError || !updatedTab || updatedTab.id !== irctcTabId) {
                    console.warn(`Tab ${tabId} seems to be gone before reload. Aborting sequence.`);
                    isSimulating = false;
                    // Allow restarting
                    if (!chrome.runtime.lastError) {
                        irctcTabId = null;
                    }
                    // Clear if tab is gone
                    return;
                }
                console.log(`Reloading IRCTC Tab ${tabId}...`);
                chrome.tabs.reload(tabId, {}, () => {
                    if (chrome.runtime.lastError) {
                        console.error(`Failed to reload tab ${tabId}:`, chrome.runtime.lastError.message);
                        isSimulating = false;
                        irctcTabId = null;
                    } else {
                        console.log(`Reload command sent for IRCTC Tab ${tabId}.`);
                        // Enter Phase 2: Wait for the page to load after reload
                        isWaitingForPostReloadLoad = true;
                        console.log(`IRCTC Tab ${tabId} reload initiated. Waiting for post-reload load.`);
                    }
                }
                );
            }
            );
        }
        , 1000);
    }
    
    // --- Phase 2: Wait for Post-Reload Load and Inject Script ---
    else if (isWaitingForPostReloadLoad && changeInfo.status === 'complete') {
        console.log(`IRCTC Tab ${tabId} post-reload load complete. Injecting monitorLogin.`);
        isWaitingForPostReloadLoad = false;
        isSimulating = true;
        chrome.scripting.executeScript({
            target: {
                tabId: irctcTabId
            },
            func: monitorLogin,
            args: [irctcTabId]
        }).catch(error => {
            console.error("Failed to inject monitorLogin script after reload sequence:", error);
            chrome.runtime.sendMessage({
                action: "simulationFailed",
                error: "Failed to inject automation script after page reload."
            });
            cleanupDebugger(irctcTabId);
            chrome.tabs.remove(irctcTabId, () => {
            }
            );
            irctcTabId = null;
            isSimulating = false;
        }
        );
    }
}
);


// Cleans up the debugger for a given tab and resets related flags.
function cleanupDebugger(tabId) {
    try {
        chrome.debugger.detach({
            tabId
        });
    } catch (e) {
    }
    if (tabId === irctcTabId) {
        irctcTabId = null;
        isSimulating = false;
        isWaitingForInitialLoad = false;

        isWaitingForPostReloadLoad = false;
        console.log(`Cleaned up debugger and reset flags for tab ${tabId}`);
    }
}

// Generates random browser headers to mimic different user agents.
function generateRandomBrowserHeaders() {
    const majorVersion = Math.floor(Math.random() * 11) + 130;
    const minorVersion = Math.floor(Math.random() * 100);
    const buildVersion = Math.floor(Math.random() * 100);
    const androidVersion = Math.floor(Math.random() * 3) + 9;
    const deviceModels = ["Pixel 3", "Pixel 4", "Pixel 5", "SM-G960F", "SM-A515F", "Redmi Note 8"];
    const deviceModel = deviceModels[Math.floor(Math.random() * deviceModels.length)];
    const secChUa = `"Google Chrome";v="${majorVersion}", "Not-A.Brand";v="8", "Chromium";v="${majorVersion}"`;
    const userAgent = `Mozilla/5.0 (Linux; Android ${androidVersion}; ${deviceModel}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${majorVersion}.0.${minorVersion}.${buildVersion} Safari/537.36`;
    return {
        secChUa,
        userAgent
    };
}

chrome.runtime.onInstalled.addListener( () => {
    const {secChUa, userAgent} = generateRandomBrowserHeaders();
    chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22],
        addRules: [{
            id: 1,
            priority: 1,
            action: {
                type: "modifyHeaders",
                requestHeaders: [{
                    header: "Referer",
                    operation: "set",
                    value: "https://www.wps.irctc.co.in/"
                }]
            },
            condition: {
                urlFilter: "https://www.irctcipay.com/pgui/jsp/surchargelocale?request_localeA=&defaultLanguageA=",
                resourceTypes: ["main_frame", "xmlhttprequest"]
            }
        }, {
            id: 2,
            priority: 1,
            action: {
                type: "modifyHeaders",
                requestHeaders: [{
                    header: "Origin",
                    operation: "set",
                    value: "https://www.irctcipay.com"
                }, {
                    header: "Referer",
                    operation: "set",
                    value: "https://www.irctcipay.com/pgui/jsp/surchargePaymentPage.jsp"
                }]
            },
            condition: {
                urlFilter: "https://www.irctcipay.com/*",
                resourceTypes: ["main_frame", "xmlhttprequest"]
            }
        }, {
            id: 3,
            priority: 1,
            action: {
                type: "modifyHeaders",
                requestHeaders: [{
                    header: "Origin",
                    operation: "set",
                    value: "https://www.irctc.co.in"
                }, {
                    header: "Accept-Language",
                    operation: "set",
                    value: "en-US,en;q=0.9"
                }, {
                    header: "DNT",
                    operation: "set",
                    value: "1"
                }, {
                    header: "Cache-Control",
                    operation: "set",
                    value: "no-cache"
                }, {
                    header: "Referer",
                    operation: "set",
                    value: "https://www.irctc.co.in/nget/train-search"
                }, {
                    header: "bmirak",
                    operation: "set",
                    value: "webbm"
                }]
            },
            condition: {
                urlFilter: "|https://www.irctc.co.in/*",
                resourceTypes: ["main_frame", "xmlhttprequest", "sub_frame", "other"]
            }
        }, {
            id: 4,
            priority: 1,
            action: {
                type: "modifyHeaders",
                requestHeaders: [{
                    header: "Origin",
                    operation: "set",
                    value: "https://www.wps.irctc.co.in"
                }, {
                    header: "Referer",
                    operation: "set",
                    value: "https://www.wps.irctc.co.in/eticketing/PaymentRedirect"
                }, {
                    header: "User-Agent",
                    operation: "set",
                    value: userAgent
                }, {
                    header: "sec-ch-ua",
                    operation: "set",
                    value: secChUa
                }, {
                    header: "sec-ch-ua-platform",
                    operation: "set",
                    value: "Android"
                }, {
                    header: "sec-ch-ua-mobile",
                    operation: "set",
                    value: "?1"
                }]
            },
            condition: {
                urlFilter: "*://*.paytmpayments.com/*",
                resourceTypes: ["main_frame", "xmlhttprequest"]
            }
        }, {
            id: 5,
            priority: 1,
            action: {
                type: "modifyHeaders",
                requestHeaders: [{
                    header: "Accept",
                    operation: "set",
                    value: "application/json, text/plain, */*"
                }, {
                    header: "Accept-Encoding",
                    operation: "set",
                    value: "gzip, deflate, br"
                }, {
                    header: "Origin",
                    operation: "set",
                    value: "https://www.irctc.co.in"
                }, {
                    header: "bmirak",
                    operation: "set",
                    value: "webbm"
                }, {
                    header: "Referer",
                    operation: "set",
                    value: "https://www.irctc.co.in/"
                }]
            },
            condition: {
                urlFilter: "https://www.wps.irctc.co.in/*",
                resourceTypes: ["main_frame", "xmlhttprequest"]
            }
        }, {
            id: 6,
            priority: 1,
            action: {
                type: "modifyHeaders",
                requestHeaders: [{
                    header: "Accept",
                    operation: "set",
                    value: "application/json, text/plain, */*"
                }, {
                    header: "Accept-Encoding",
                    operation: "set",
                    value: "gzip, deflate, br"
                }, {
                    header: "Origin",
                    operation: "set",
                    value: "https://www.irctc.co.in"
                }, {
                    header: "Referer",
                    operation: "set",
                    value: "https://www.irctc.co.in/nget/train-search"
                }, {
                    header: "bmirak",
                    operation: "set",
                    value: "webbm"
                }]
            },
            condition: {
                urlFilter: "|https://www.irctc.co.in/authprovider/webtoken*",
                resourceTypes: ["main_frame", "xmlhttprequest"]
            }
        }, {
            id: 7,
            priority: 1,
            action: {
                type: "modifyHeaders",
                requestHeaders: [{
                    header: "Origin",
                    operation: "set",
                    value: "https://askdisha.irctc.co.in"
                }, {
                    header: "Referer",
                    operation: "set",
                    value: "https://askdisha.irctc.co.in/"
                }]
            },
            condition: {
                urlFilter: "https://askdisha.irctc.co.in/*",
                resourceTypes: ["main_frame", "xmlhttprequest"]
            }
        }, {
            id: 8,
            priority: 1,
            action: {
                type: "modifyHeaders",
                requestHeaders: [{
                    header: "Origin",
                    operation: "set",
                    value: "https://mercury-t2.phonepe.com"
                }, {
                    header: "Referer",
                    operation: "set",
                    value: "https://mercury-t2.phonepe.com/"
                }, {
                    header: "sec-ch-ua-mobile",
                    operation: "set",
                    value: "?0"
                }, {
                    header: "sec-ch-ua-platform",
                    operation: "set",
                    value: "macOS"
                }, {
                    header: "sec-fetch-dest",
                    operation: "set",
                    value: "document"
                }, {
                    header: "sec-fetch-mode",
                    operation: "set",
                    value: "navigate"
                }, {
                    header: "sec-fetch-site",
                    operation: "set",
                    value: "cross-site"
                }, {
                    header: "sec-gpc",
                    operation: "set",
                    value: "1"
                }, {
                    header: "upgrade-insecure-requests",
                    operation: "set",
                    value: "1"
                }, {
                    header: "User-Agent",
                    operation: "set",
                    value: userAgent
                }, {
                    header: "sec-ch-ua",
                    operation: "set",
                    value: secChUa
                }]
            },
            condition: {
                urlFilter: "https://api.phonepe.com/*",
                resourceTypes: ["main_frame", "xmlhttprequest"]
            }
        }, {
            id: 9,
            priority: 1,
            action: {
                type: "modifyHeaders",
                requestHeaders: [{
                    header: "Origin",
                    operation: "set",
                    value: "https://www.wps.irctc.co.in"
                }, {
                    header: "Referer",
                    operation: "set",
                    value: "https://www.wps.irctc.co.in/"
                }, {
                    header: "sec-ch-ua-mobile",
                    operation: "set",
                    value: "?0"
                }, {
                    header: "sec-ch-ua-platform",
                    operation: "set",
                    value: "macOS"
                }, {
                    header: "sec-fetch-dest",
                    operation: "set",
                    value: "document"
                }, {
                    header: "sec-fetch-mode",
                    operation: "set",
                    value: "navigate"
                }, {
                    header: "sec-fetch-site",
                    operation: "set",
                    value: "cross-site"
                }, {
                    header: "sec-gpc",
                    operation: "set",
                    value: "1"
                }, {
                    header: "upgrade-insecure-requests",
                    operation: "set",
                    value: "1"
                }, {
                    header: "User-Agent",
                    operation: "set",
                    value: userAgent
                }, {
                    header: "sec-ch-ua",
                    operation: "set",
                    value: secChUa
                }]
            },
            condition: {
                urlFilter: "https://mercury-t2.phonepe.com/*",
                resourceTypes: ["main_frame", "xmlhttprequest"]
            }
        }, {
            id: 10,
            priority: 1,
            action: {
                type: "modifyHeaders",
                requestHeaders: [{
                    header: "Origin",
                    operation: "set",
                    value: "https://securehdfc-acs2ui-b1-indmum-mumsif.hdfcbank.com"
                }, {
                    header: "Referer",
                    operation: "set",
                    value: "https://securehdfc-acs2ui-b1-indmum-mumsif.hdfcbank.com"
                }]
            },
            condition: {
                urlFilter: "*://*.hdfcbank.com/*",
                resourceTypes: ["main_frame", "xmlhttprequest"]
            }
        }, {
            id: 11,
            priority: 1,
            action: {
                type: "modifyHeaders",
                responseHeaders: [{
                    header: "Set-Cookie",
                    operation: "remove"
                }]
            },
            condition: {
                urlFilter: "|https://www.irctc.co.in/eticketing/protected/mapps1/allLapAvlFareEnq/*",
                resourceTypes: ["main_frame", "xmlhttprequest", "sub_frame", "other"]
            }
        }, {
            id: 12,
            priority: 1,
            action: {
                type: "block"
            },
            condition: {
                urlFilter: "||googlesyndication.com",
                resourceTypes: ["main_frame", "sub_frame", "script", "image", "xmlhttprequest"]
            }
        }, {
            id: 13,
            priority: 1,
            action: {
                type: "block"
            },
            condition: {
                urlFilter: "||doubleclick.net",
                resourceTypes: ["main_frame", "sub_frame", "script", "image", "xmlhttprequest"]
            }
        }, {
            id: 14,
            priority: 1,
            action: {
                type: "block"
            },
            condition: {
                urlFilter: "||google-analytics.com",
                resourceTypes: ["script", "xmlhttprequest"]
            }
        }, {
            id: 15,
            priority: 1,
            action: {
                type: "block"
            },
            condition: {
                urlFilter: "||googleadservices.com",
                resourceTypes: ["main_frame", "sub_frame", "script", "xmlhttprequest"]
            }
        }, {
            id: 16,
            priority: 1,
            action: {
                type: "block"
            },
            condition: {
                urlFilter: "||adservice.google.com",
                resourceTypes: ["main_frame", "sub_frame", "script", "xmlhttprequest"]
            }
        }, {
            id: 17,
            priority: 1,
            action: {
                type: "block"
            },
            condition: {
                urlFilter: "||criteo.com",
                resourceTypes: ["script", "image", "xmlhttprequest"]
            }
        }, {
            id: 18,
            priority: 1,
            action: {
                type: "block"
            },
            condition: {
                urlFilter: "||pubmatic.com",
                resourceTypes: ["main_frame", "sub_frame", "script", "xmlhttprequest"]
            }
        }, {
            id: 19,
            priority: 1,
            action: {
                type: "block"
            },
            condition: {
                urlFilter: "||adnxs.com",
                resourceTypes: ["main_frame", "sub_frame", "script", "xmlhttprequest"]
            }
        }, {
            id: 20,
            priority: 1,
            action: {
                type: "block"
            },
            condition: {
                urlFilter: "||cdn.jsdelivr.net/gh/corover/assets",
                resourceTypes: ["image", "sub_frame"]
            }
        }, {
            id: 21,
            priority: 1,
            action: {
                type: "block"
            },
            condition: {
                urlFilter: "||adgebra.net",
                resourceTypes: ["main_frame", "sub_frame", "script", "image", "xmlhttprequest"]
            }
        }, {
            id: 22,
            priority: 1,
            action: {
                type: "modifyHeaders",
                responseHeaders: [{
                    header: "Set-Cookie",
                    operation: "remove"
                }],
            },
            condition: {
                urlFilter: "|https://www.irctc.co.in/eticketing/protected/mapps1/avlFarenquiry/*",
                resourceTypes: ["main_frame", "xmlhttprequest", "sub_frame", "other"]
            }
        }]
    });
}
);

// 1. Clears cookies for specific target domains.
function clearAllTargetCookies() {
    const domains = ["askdisha.irctc.co.in", "www.irctc.co.in", "irctc.co.in", "wps.irctc.co.in", "irctcipay.com"];
    return Promise.all(domains.map(domain => new Promise(resolve => {
        chrome.cookies.getAll({
            domain
        }, cookies => {
            if (!cookies.length)
                return resolve();
            Promise.all(cookies.map(c => {
                const proto = c.secure ? "https://" : "http://";
                const url = `${proto}${c.domain.replace(/^\./, "")}${c.path}`;
                return new Promise(done => chrome.cookies.remove({
                    url,
                    name: c.name
                }, done));
            }
            )).then(resolve);
        }
        );
    }
    )));
}

// 2. Clears various browsing data (cookies, cache, etc.) for IRCTC origins.
function clearSiteDataForTargets() {
    const origins = ["https://www.irctc.co.in", "https://askdisha.irctc.co.in", "https://irctc.co.in", "https://www.wps.irctc.co.in", "https://wps.irctc.co.in", "https://www.irctcipay.com", "https://irctcipay.com"];
    return new Promise(resolve => {
        chrome.browsingData.remove({
            origins
        }, {
            cookies: true,
            cache: true,
            localStorage: true,
            indexedDB: true,
            serviceWorkers: true
        }, resolve);
    }
    );
}

// 3. Clears client-side storage (localStorage, sessionStorage, IndexedDB, Cache API, Service Workers) within a specific tab.
function clearClientStorage(tabId) {
    return new Promise( (resolve, reject) => {
        chrome.scripting.executeScript({
            target: {
                tabId
            },
            func: () => {
                localStorage.clear();
                sessionStorage.clear();
                indexedDB.databases().then(dbs => dbs.forEach(db => indexedDB.deleteDatabase(db.name)));
                caches.keys().then(keys => keys.forEach(k => caches.delete(k)));
                if (navigator.serviceWorker)
                    navigator.serviceWorker.getRegistrations().then(regs => regs.forEach(r => r.unregister()));
            }
        }, () => chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve());
    }
    );
}

// 4. Performs a comprehensive factory reset of the extension's state and data.
async function factoryResetExtension() {
    try {
        // Step 1: Clear Extension Storage (local, sync, session)
        await Promise.all([new Promise(r => chrome.storage.local.clear(r)), chrome.storage.sync ? new Promise(r => chrome.storage.sync.clear(r)) : Promise.resolve(), chrome.storage.session ? new Promise(r => chrome.storage.session.clear(r)) : Promise.resolve()]);

        // Step 2: Clear localStorage in all open tabs (as a precaution)
        chrome.tabs.query({}, tabs => {
            tabs.forEach( ({id}) => {
                chrome.scripting.executeScript({
                    target: {
                        tabId: id
                    },
                    func: () => localStorage.clear()
                }).catch( () => {}
                );
            }
            );
        }
        );

        // Step 3: Delete IndexedDB databases
        let dbs = [];
        try {
            if (indexedDB.databases)
                dbs = await indexedDB.databases();
        } catch (e) {}
        dbs.filter(d => d.name).forEach( ({name}) => {
            const req = indexedDB.deleteDatabase(name);
            req.onsuccess = () => {}
            ;
            req.onerror = () => {}
            ;
        }
        );

        // Step 4: Delete Cache Storage
        if (caches && caches.keys) {
            const keys = await caches.keys();
            await Promise.all(keys.map(k => caches.delete(k)));
        }

        // Step 5: Clear Cookies for All Domains
        const allCookies = await new Promise(resolve => chrome.cookies.getAll({}, resolve));
        const cookieDeletePromises = allCookies.map(c => {
            const url = (c.secure ? "https://" : "http://") + c.domain.replace(/^\./, "") + c.path;
            return new Promise(resolve => chrome.cookies.remove({
                url,
                name: c.name
            }, () => resolve()));
        }
        );
        await Promise.all(cookieDeletePromises);

        // Step 6: Clear Browsing Data for IRCTC Origins
        const IRCTC_ORIGINS = ["https://www.irctc.co.in", "https://askdisha.irctc.co.in", "https://irctc.co.in", "https://www.wps.irctc.co.in", "https://wps.irctc.co.in", "https://www.irctcipay.com", "https://irctcipay.com"];
        await new Promise(resolve => {
            chrome.browsingData.remove({
                origins: IRCTC_ORIGINS
            }, {
                cookies: true,
                cache: true,
                localStorage: true,
                indexedDB: true,
                serviceWorkers: true,
                cacheStorage: true
            }, resolve);
        }
        );

        // Step 7: Clear Pending Requests Map
        pendingRequests.clear();

        console.log("Factory reset completed. Reloading extension...");
        // Step 8: Reload the Extension
        chrome.runtime.reload();
    } catch (err) {
        console.error("Error during factory reset:", err);
        throw err;
        // Re-throw to be caught by the message listener
    }
}

// 5. Clears cookies for a specific hostname.
function clearCookiesByHostname(hostname) {
    return new Promise(resolve => {
        chrome.cookies.getAll({
            domain: hostname
        }, cookies => {
            if (!cookies.length)
                return resolve();
            Promise.all(cookies.map(c => {
                const url = (c.secure ? "https://" : "http://") + c.domain.replace(/^\./, "") + c.path;
                return new Promise(r => chrome.cookies.remove({
                    url,
                    name: c.name
                }, r));
            }
            )).then(resolve);
        }
        );
    }
    );
}

// 6. Clears various types of browsing data for a list of origins.
function clearBrowsingDataForOrigins(origins) {
    return new Promise(resolve => {
        chrome.browsingData.remove({
            origins
        }, {
            cookies: true,
            cache: true,
            localStorage: true,
            indexedDB: true,
            serviceWorkers: true,
            cacheStorage: true
        }, resolve);
    }
    );
}

// List of IRCTC-related origins.
const IRCTC_ORIGINS = ["https://www.irctc.co.in", "https://askdisha.irctc.co.in", "https://irctc.co.in", "https://www.wps.irctc.co.in", "https://wps.irctc.co.in", "https://www.irctcipay.com", "https://irctcipay.com"];

// 7. Clears IRCTC-specific data by combining cookie clearing and browsing data clearing.
function clearIrctcData() {
    const hosts = IRCTC_ORIGINS.map(url => new URL(url).hostname);
    return Promise.all(hosts.map(clearCookiesByHostname)).then( () => clearBrowsingDataForOrigins(IRCTC_ORIGINS));
}

// 8. Automates the IRCTC login process and subsequent navigation steps within a tab.
async function monitorLogin(tabId) {
    const delay = ms => new Promise(res => setTimeout(res, ms));
    // Realistic click simulation
    function simulateRealClick(element) {
        const mouseDownEvent = new MouseEvent("mousedown",{
            bubbles: true,
            cancelable: true
        });
        const mouseUpEvent = new MouseEvent("mouseup",{
            bubbles: true,
            cancelable: true
        });
        const clickEvent = new MouseEvent("click",{
            bubbles: true,
            cancelable: true
        });
        element.dispatchEvent(mouseDownEvent);
        element.dispatchEvent(mouseUpEvent);
        element.dispatchEvent(clickEvent);
    }
    // Realistic input simulation
    function simulateRealInput(element, value) {
        element.focus();
        element.value = value;
        element.dispatchEvent(new Event("input",{
            bubbles: true
        }));
        element.dispatchEvent(new Event("change",{
            bubbles: true
        }));
        element.dispatchEvent(new Event("blur",{
            bubbles: true
        }));
    }
function addInstruction(text) {
    let box = document.getElementById("instruction-box");
    if (!box) {
        box = document.createElement("div");
        box.id = "instruction-box";
        box.className = "instruction-popup";

        Object.assign(box.style, {
            position: "fixed",
            top: "10%",
            left: "50%",
            transform: "translate(-30%, -30%)",
            background: "linear-gradient(135deg, #3dc064ff, #4ca1af)",
            color: "#ffffff",
            padding: "16px 28px",
            borderRadius: "10px",
            border: "1px solid rgba(255, 255, 255, 0.15)",
            zIndex: "999999",
            fontFamily: "Inter, Segoe UI, sans-serif",
            fontSize: "15px",
            fontWeight: "500",
            boxShadow: "0 8px 20px rgba(0, 0, 0, 0.4)",
            textAlign: "center",
            lineHeight: "1.6",
            cursor: "pointer",
            backdropFilter: "blur(4px)"
        });

        const textSpan = document.createElement("span");
        textSpan.className = "instruction-text";
        textSpan.textContent = text;
        box.appendChild(textSpan);

        box.onclick = () => box.remove();
        document.body.appendChild(box);
    } else {
        const textEl = box.querySelector(".instruction-text");
        if (textEl) textEl.textContent = text;
    }
}
    async function waitForElement(selector, timeout=60000) {
        const start = Date.now();
        while (Date.now() - start < timeout) {
            const el = document.querySelector(selector);
            if (el)
                return el;
            await delay(500);
        }
        return null;
    }
    try {
        // Step 1: Remove unnecessary elements (if any)
        const splashScrollable = document.getElementById('splash-scrollable');
        if (splashScrollable && splashScrollable.parentElement) {
            splashScrollable.parentElement.remove();
        }
        const chatbot = document.getElementById('chatbot');
        if (chatbot) {
            chatbot.remove();
        }
        // Step 2: Locate and click the LOGIN button
        await delay(2000);
        const loginButton = document.querySelector('a.search_btn.loginText.ng-star-inserted[aria-label="Click here to Login in application"]');
        if (loginButton) {
            addInstruction("Clicking LOGIN button...");
            simulateRealClick(loginButton);
            // Updated to realistic click
        } else {
            addInstruction("LOGIN button not found!");
            chrome.runtime.sendMessage({
                action: "simulationFailed",
                error: "Login button not found"
            });
            return;
        }
        // Step 3: Wait for login form fields
        const userEl = await waitForElement('input[formcontrolname="userid"]', 30000);
        const passEl = await waitForElement('input[formcontrolname="password"]', 30000);
        await delay(2000);
        const capEl = document.querySelector('input[formcontrolname="captcha"]');
        if (!userEl || !passEl) {
            addInstruction("Login form fields not found!");
            chrome.runtime.sendMessage({
                action: "simulationFailed",
                error: "Login form fields not found"
            });
            return;
        }
        // Step 4: Fill login credentials
        const credentials = await new Promise( (resolve) => {
            chrome.runtime.sendMessage({
                action: "getStoredCredentials"
            }, (response) => {
                resolve(response);
            }
            );
        }
        );
        if (!credentials || !credentials.username || !credentials.password) {
            addInstruction("Stored credentials not found!");
            chrome.runtime.sendMessage({
                action: "simulationFailed",
                error: "Stored credentials not found"
            });
            return;
        }
        // Updated to realistic input simulation
        simulateRealInput(userEl, credentials.username);
        simulateRealInput(passEl, credentials.password);
        userEl.style.display = "none";
        passEl.style.display = "none";
        if (capEl) {
            capEl.style.display = "";
            capEl.focus();
        }
        addInstruction("Now Fill the Captcha and Click SIGN IN");
        // Step 5: Wait for login success
        let loginSuccess = false;
        for (let i = 0; i < 120; i++) {
            const logoutSpan = Array.from(document.querySelectorAll('span')).find(el => el.textContent.trim() === "Logout");
            if (logoutSpan) {
                loginSuccess = true;
                break;
            }
            await delay(1000);
        }
        if (loginSuccess) {
            addInstruction("Login Successful!");
            chrome.runtime.sendMessage({
                action: "attachDebugger",
                tabId: tabId
            }, (response) => {
                if (chrome.runtime.lastError || !response || !response.success) {
                    console.error("Failed to send attachDebugger message or received negative response:", chrome.runtime.lastError?.message, response);
                }
            }
            );
            // Step 6: Navigate to "MY ACCOUNT > My Transactions > Booked Ticket History"
            await delay(400);
            // Wait for page to settle
            // Hover over "MY ACCOUNT" to reveal the dropdown
            const myAccountMenu = document.querySelector('a[aria-label="Menu my Account"]');
            if (myAccountMenu) {
                myAccountMenu.dispatchEvent(new MouseEvent("mouseover",{
                    bubbles: true
                }));
                await delay(300);
                // Wait for dropdown to appear
            } else {
                addInstruction("MY ACCOUNT menu not found!");
                chrome.runtime.sendMessage({
                    action: "simulationFailed",
                    error: "MY ACCOUNT menu not found"
                });
                return;
            }
            // Click on "My Transactions" to expand its submenu
            const myTransactionsLink = document.querySelector('a[aria-label="Sub Menu of my Account, my Transactions. has sub menu"]');
            if (myTransactionsLink) {
                simulateRealClick(myTransactionsLink);
                // Updated to realistic click
                await delay(400);
                // Wait for submenu to expand
            } else {
                addInstruction("My Transactions link not found!");
                chrome.runtime.sendMessage({
                    action: "simulationFailed",
                    error: "My Transactions link not found"
                });
                return;
            }
            // Click on "Booked Ticket History" from the expanded submenu
            const bookedTicketHistoryLink = document.querySelector('a[aria-label="Sub Menu of my Transactions, Booked Ticket History"]');
            if (bookedTicketHistoryLink) {
                simulateRealClick(bookedTicketHistoryLink);
                // Updated to realistic click
            } else {
                addInstruction("Booked Ticket History link not found!");
                chrome.runtime.sendMessage({
                    action: "simulationFailed",
                    error: "Booked Ticket History link not found"
                });
                return;
            }
            // Step 7: Click on "ALL JOURNEYS" tab
            await delay(800);
            const allJourneysTab = await waitForElement('a.ui-menuitem-link span.ui-menuitem-text.ng-star-inserted', 30000);
            if (allJourneysTab && allJourneysTab.textContent.trim() === "ALL JOURNEYS") {
                // Get the parent <a> element
                const allJourneysLink = allJourneysTab.closest('a.ui-menuitem-link');
                if (allJourneysLink) {
                    simulateRealClick(allJourneysLink);
                    await delay(280);
                    simulateRealClick(allJourneysLink);
                } else {
                    addInstruction("ALL JOURNEYS link not found!");
                    chrome.runtime.sendMessage({
                        action: "simulationFailed",
                        error: "ALL JOURNEYS link not found"
                    });
                    return;
                }
            } else {
                addInstruction("ALL JOURNEYS tab not found!");
                chrome.runtime.sendMessage({
                    action: "simulationFailed",
                    error: "ALL JOURNEYS tab not found"
                });
                return;
            }
            await delay(700);
            if (myAccountMenu) {
                myAccountMenu.dispatchEvent(new MouseEvent("mouseover",{
                    bubbles: true
                }));
                await delay(300);
            } else {
                addInstruction("MY ACCOUNT menu not found!");
                chrome.runtime.sendMessage({
                    action: "simulationFailed",
                    error: "MY ACCOUNT menu not found"
                });
                return;
            }
            // Click on "My Profile" to expand its submenu
            const myProfileLink = document.querySelector('a[aria-label="Sub Menu of my Account, my Profile. has sub menu"]');
            if (myProfileLink) {
                simulateRealClick(myProfileLink);
                await delay(600);
            } else {
                addInstruction("My Profile link not found!");
                chrome.runtime.sendMessage({
                    action: "simulationFailed",
                    error: "My Profile link not found"
                });
                return;
            }
            // Click on "Update Profile" from the expanded submenu
            const updateProfileLink = document.querySelector('a[aria-label="Sub Menu of my Profile, update Profile"]');
            if (updateProfileLink) {
                await delay(800);
                simulateRealClick(updateProfileLink);
                addInstruction("Update Profile link clicked successfully.");
            } else {
                addInstruction("Update Profile link not found!");
                chrome.runtime.sendMessage({
                    action: "simulationFailed",
                    error: "Update Profile link not found"
                });
                return;
            }
            return;
        } else {
            addInstruction("Login failed or timed out. Please try again.");
            chrome.runtime.sendMessage({
                action: "simulationFailed",
                error: "Login timeout or failed"
            });
            return;
        }
    } catch (error) {
        console.error("Error in monitorLogin:", error);
        addInstruction("An error occurred during automation.");
        chrome.runtime.sendMessage({
            action: "simulationFailed",
            error: error.message
        });
    }
}

chrome.action.onClicked.addListener( () => {
    chrome.tabs.create({
        url: chrome.runtime.getURL("index.html")
    });
}
);
