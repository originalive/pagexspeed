window.ui = {
    notificationTimeout: null,
    loadingTimeout: null,
    loadingClockInterval: null,

    // Notification Pane
    showMessage: function(message, type="info", duration=7000) {
        if (!window.els.notificationPane)
            return;

        if (this.notificationTimeout)
            clearTimeout(this.notificationTimeout);

        const titles = {
            error: "Error",
            success: "Success",
            info: "Information",
            warning: "Warning"
        };
        window.els.notificationTitle.textContent = titles[type] || "Notification";
        window.els.notificationMessage.textContent = message;

        window.els.notificationPane.className = 'notification-pane';
        window.els.notificationPane.classList.add(type);
        window.els.notificationPane.classList.remove('hidden');

        if (type !== 'error' && duration > 0) {
            this.notificationTimeout = setTimeout(this.hideMessage.bind(this), duration);
        }
        clog(`[UI Notification] Displayed message: "${message}" of type "${type}" for ${duration > 0 ? duration + 'ms' : 'indefinite'}.`);
    },

    hideMessage: function() {
        if (window.els.notificationPane) {
            window.els.notificationPane.classList.add("hidden");
        }
        if (this.notificationTimeout)
            clearTimeout(this.notificationTimeout);
        clog("[UI Notification] Notification pane hidden.");
    },

    hideErrorMessage: function() {
        if (window.els.notificationPane) {
            window.els.notificationPane.classList.remove("visible");
            window.els.notificationPane.classList.add("hidden");
        }
        clog("[UI Notification] Error message pane hidden (specific to old 'visible' class removal).");
    },

    // Loading Overlay with Live Clock
    showLoading: function(message, duration=null) {
        const loaderWidget = document.querySelector('.loader-widget'); // Get the widget
        if (window.els.loadingMessage && window.els.loadingOverlay && loaderWidget) {
            window.els.loadingMessage.innerHTML = message;
            window.els.loadingOverlay.classList.remove("hidden");

            // Add-Remove tatkal animation class based on the global flag
            if (window.isTatkalFlowActive) {
                loaderWidget.classList.add('tatkal-active');
            } else {
                loaderWidget.classList.remove('tatkal-active');
            }

            if (this.loadingTimeout)
                clearTimeout(this.loadingTimeout);
            if (duration) {
                this.loadingTimeout = setTimeout(this.hideLoading.bind(this), duration);
            }
        }

        if (!this.loadingClockInterval) {
            const clockEl = document.getElementById('loadingClock');
            if (clockEl) {
                this.loadingClockInterval = setInterval( () => {
                    const now = new Date();
                    const hours = String(now.getHours()).padStart(2, '0');
                    const minutes = String(now.getMinutes()).padStart(2, '0');
                    const seconds = String(now.getSeconds()).padStart(2, '0');
                    const milliseconds = String(now.getMilliseconds()).padStart(3, '0');
                    clockEl.textContent = `${hours}:${minutes}:${seconds}.${milliseconds}`;
                }
                , 47);
                // Update ~21 times per second for smooth ms
            }
        }

        clog(`[UI Loading] Loading overlay displayed with message: "${message}". Timeout set for ${duration ? duration + 'ms' : 'indefinite'}.`);
    },

        hideLoading: function() {
        if (window.els.loadingOverlay) {
            if (this.loadingTimeout)
                clearTimeout(this.loadingTimeout);
            window.els.loadingOverlay.classList.add("hidden");
            // Always remove the class on hide to reset state
            const loaderWidget = document.querySelector('.loader-widget');
            if(loaderWidget) {
                loaderWidget.classList.remove('tatkal-active');
            }
        }
        if (this.loadingClockInterval) {
            clearInterval(this.loadingClockInterval);
            this.loadingClockInterval = null;
        }

        clog("[UI Loading] Loading overlay hidden.");
    },

    // Error Message Processor
    processErrorMsg: function(e) {
        let t = ["Invalid Captcha", "Unable to process your request", "Sorry !! Unable to process the request due to issue at Bank end", "Unable to Process Request", "Your Account Has Payment Issues"];
        // This array 't' is unused in the provided code
        if (e) {
            for (let n of ["errorMessage", "errorMsg", "error_description", "error"]) {
                let a = e[n]?.trim();
                if (a) {
                    if (a.includes("Your Account Has Payment Issues")) {
                        this.showMessage(a + ", Change IRCTC ID & Try Again", "error", 0);
                        clog(`[Error Processor] Processed specific error: "Account Payment Issues". Displayed error message.`);
                        return true;
                    }
                    if (a.includes("Unable to process your request") || a.includes("Unable to Process Request")) {
                        this.showMessage("Origin — Fingerprint/Account Issues, Change GoLogin Browser Profile Settings/IRCTC Account & Login Again", "error", 0);
                        clog(`[Error Processor] Processed specific error: "Unable to process request". Displayed error message.`);
                        return true;
                    }
                    if (a.includes("Sorry !! Unable to process the request due to issue at Bank end")) {
                        this.showMessage("Origin — Payment Gateway is down. Try another payment method.", "error", 0);
                        clog(`[Error Processor] Processed specific error: "Bank end issue". Displayed error message.`);
                        return true;
                    }
                    if (a.includes("Invalid Captcha")) {
                        clog(`[Error Processor] Ignored error: "${a}" - Handled by captcha retry logic.`);
                        return true;
                    }
                    this.showMessage(a, "error", 0);
                    clog(`[Error Processor] Processed generic error: "${a}". Displayed error message.`);
                    return true;
                }
            }
        }
        clog("[Error Processor] No specific or generic error message found to process.");
        return false;
    },

    // Time Display
    showCurrentTimeBox: function() {
        if (window.els.currentTimeBox) {
            window.els.currentTimeBox.classList.remove("hidden");
            const updateTime = () => {
                const now = new Date();
                const timeString = now.toLocaleTimeString("en-IN", {
                    hour12: true,
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit"
                });
                window.els.currentTimeBox.textContent = timeString;
            }
            ;
            updateTime();
            setInterval(updateTime, 1000);
            clog("[UI Time] Current time box displayed and updated every second.");
        } else {
            clog("[UI Time] Current time box element not found.");
        }
    },

    // Dynamic Passenger Table Management
    addPassengerRow: function(initialData={}) {
        if (!window.els.passengerTableBody) {
            clog("[Passenger Table] Error: passengerTableBody element not found.");
            return;
        }

        const currentPassengerCount = window.els.passengerTableBody.getElementsByTagName("tr").length;
        const quota = window.els.quota.value.trim().toUpperCase();
        const maxPassengers = (quota === "TQ" || quota === "PT") ? 4 : 6;

        if (currentPassengerCount >= maxPassengers) {
            this.showMessage(`Maximum of ${maxPassengers} passenger rows allowed for the selected quota.`, "error", 0);
            clog(`[Passenger Table] Attempted to add passenger row beyond limit (${maxPassengers} for ${quota}). Action blocked.`);
            return;
        }

        const row = document.createElement("tr");
        row.dataset.childBerth = initialData.needsChildBerth === true ? "true" : "false";

        let cell = document.createElement("td");
        let nameInput = document.createElement("input");
        nameInput.type = "text";
        nameInput.placeholder = "Name (Alphabets only)";
        nameInput.classList.add("google-input", "passenger-name");
        nameInput.maxLength = 16;
        nameInput.value = initialData.passengerName || "";
        nameInput.addEventListener("input", () => {
            nameInput.value = nameInput.value.replace(/[^a-zA-Z\s]/g, "");
            if (typeof saveFormData === 'function')
                saveFormData();
            clog(`[Passenger Table] Passenger name input changed to: "${nameInput.value}".`);
        }
        );
        nameInput.addEventListener("change", () => {
            if (typeof saveFormData === 'function')
                saveFormData();
        }
        );
        cell.appendChild(nameInput);
        row.appendChild(cell);

        cell = document.createElement("td");
        let ageInput = document.createElement("input");
        ageInput.type = "number";
        ageInput.placeholder = "Age";
        ageInput.classList.add("google-input", "passenger-age");
        ageInput.min = 1;
        ageInput.max = 99;
        ageInput.value = initialData.passengerAge || "";
        ageInput.addEventListener("input", () => {
            ageInput.value = ageInput.value.replace(/\D/g, "").slice(0, 2);
            if (typeof saveFormData === 'function')
                saveFormData();
            clog(`[Passenger Table] Passenger age input changed to: "${ageInput.value}".`);
        }
        );
        ageInput.addEventListener("change", () => {
            const age = parseInt(ageInput.value, 10);
            if (!isNaN(age) && age >= 5 && age <= 11) {
                const needsBerth = confirm(`Passenger is ${age} years old.\nDo you need a CHILD BERTH for them?`);
                row.dataset.childBerth = needsBerth ? "true" : "false";
                clog(`[Passenger Table] Child berth preference set to ${row.dataset.childBerth} for age ${age}.`);
            } else {
                row.dataset.childBerth = "false";
                clog(`[Passenger Table] Child berth preference set to false (age ${age}).`);
            }
            if (typeof saveFormData === 'function')
                saveFormData();
        }
        );
        cell.appendChild(ageInput);
        row.appendChild(cell);

        cell = document.createElement("td");
        let genderSelect = document.createElement("select");
        genderSelect.classList.add("google-select", "passenger-gender");
        [{
            value: "M",
            text: "Male"
        }, {
            value: "F",
            text: "Female"
        }].forEach(option => {
            let opt = document.createElement("option");
            opt.value = option.value;
            opt.textContent = option.text;
            if (option.value === (initialData.passengerGender || "M"))
                opt.selected = true;
            genderSelect.appendChild(opt);
        }
        );
        genderSelect.addEventListener("change", () => {
            if (typeof saveFormData === 'function')
                saveFormData();
            clog(`[Passenger Table] Passenger gender changed to: "${genderSelect.value}".`);
        }
        );
        cell.appendChild(genderSelect);
        row.appendChild(cell);

        cell = document.createElement("td");
        let berthSelect = document.createElement("select");
        berthSelect.classList.add("google-select", "passenger-berth");
        berthSelect.addEventListener("change", () => {
            if (typeof saveFormData === 'function')
                saveFormData();
            clog(`[Passenger Table] Passenger berth preference changed to: "${berthSelect.value}".`);
        }
        );
        cell.appendChild(berthSelect);
        row.appendChild(cell);

        cell = document.createElement("td");
        let mealSelect = document.createElement("select");
        mealSelect.classList.add("google-select", "passenger-meal");
        [{
            value: "Meal Not Applicable",
            text: "Not Applicable"
        }, {
            value: "D",
            text: "No Food"
        }, {
            value: "V",
            text: "Veg"
        }, {
            value: "N",
            text: "Non-Veg"
        }, {
            value: "E",
            text: "Snacks (Veg)"
        }].forEach(option => {
            let opt = document.createElement("option");
            opt.value = option.value;
            opt.textContent = option.text;
            if (option.value === (initialData.passengerFoodChoice || "Meal Not Applicable"))
                opt.selected = true;
            mealSelect.appendChild(opt);
        }
        );
        mealSelect.addEventListener("change", () => {
            if (typeof saveFormData === 'function')
                saveFormData();
            clog(`[Passenger Table] Passenger meal choice changed to: "${mealSelect.value}".`);
        }
        );
        cell.appendChild(mealSelect);
        row.appendChild(cell);

        cell = document.createElement("td");
        let removeBtn = document.createElement("button");
        removeBtn.type = "button";
        removeBtn.classList.add("google-button", "remove-passenger");
        removeBtn.textContent = "Remove";
        removeBtn.onclick = () => {
            row.remove();
            if (typeof saveFormData === 'function')
                saveFormData();
            clog(`[Passenger Table] Passenger row removed. Current passenger count: ${window.els.passengerTableBody.getElementsByTagName("tr").length}.`);
        }
        ;
        cell.appendChild(removeBtn);
        row.appendChild(cell);

        window.els.passengerTableBody.appendChild(row);
        this.updateBerthOptions(berthSelect, initialData.passengerBerthChoice);
        clog(`[Passenger Table] New passenger row added. Initial data: ${JSON.stringify(initialData)}. Current count: ${window.els.passengerTableBody.getElementsByTagName("tr").length}.`);
    },

    updateBerthOptions: function(berthSelectElement, selectedBerth="") {
        const coachClass = window.els.coach.value.trim().toUpperCase();
        let options = [];

        if (["CC", "EC", "2S", "EA"].includes(coachClass)) {
            options = [{
                value: "",
                text: "No Preference"
            }];
        } else if (coachClass === "1A") {
            options = [{
                value: "",
                text: "No Preference"
            }, {
                value: "LB",
                text: "Lower"
            }, {
                value: "UB",
                text: "Upper"
            }, {
                value: "CB",
                text: "Cabin"
            }, {
                value: "CP",
                text: "Couple"
            }];
        } else if (coachClass === "2A") {
            options = [{
                value: "",
                text: "No Preference"
            }, {
                value: "LB",
                text: "Lower"
            }, {
                value: "UB",
                text: "Upper"
            }, {
                value: "SL",
                text: "Side Lower"
            }, {
                value: "SU",
                text: "Side Upper"
            }];
        } else {
            // For SL, 3A, 3E, etc.
            options = [{
                value: "",
                text: "No Preference"
            }, {
                value: "UB",
                text: "Upper"
            }, {
                value: "LB",
                text: "Lower"
            }, {
                value: "MB",
                text: "Middle"
            }, {
                value: "SL",
                text: "Side Lower"
            }, {
                value: "SU",
                text: "Side Upper"
            }];
        }

        berthSelectElement.innerHTML = "";
        options.forEach(option => {
            const optElement = document.createElement("option");
            optElement.value = option.value;
            optElement.textContent = option.text;
            if (option.value === selectedBerth)
                optElement.selected = true;
            berthSelectElement.appendChild(optElement);
        }
        );

        if (![...berthSelectElement.options].some(opt => opt.value === selectedBerth)) {
            berthSelectElement.value = "";
            clog(`[Berth Options] Berth preference for class "${coachClass}" reset to "No Preference" as "${selectedBerth}" is not available.`);
        }
        clog(`[Berth Options] Berth options updated for coach class "${coachClass}". Selected: "${berthSelectElement.value}".`);
    },

    // Autocomplete functions
    attachAutocomplete: function(elementId) {
        const input = document.getElementById(elementId);
        if (!input) {
            clog(`[Autocomplete] Input element not found for ID: ${elementId}.`);
            return;
        }

        let timeout = null;

        input.addEventListener("input", () => {
            clearTimeout(timeout);
            timeout = setTimeout( () => {
                const query = input.value.toLowerCase();
                let suggestions = [];
                if (query.length >= 3 && window.stationData) {
                    suggestions = window.stationData.filter(s => s.en.toLowerCase().includes(query) || s.sc.toLowerCase().includes(query)).sort( (a, b) => {
                        if (a.sc.toLowerCase() === query)
                            return -2;
                        if (b.sc.toLowerCase() === query)
                            return 2;
                        if (a.sc.toLowerCase().startsWith(query))
                            return -1;
                        if (b.sc.toLowerCase().startsWith(query))
                            return 1;
                        if (a.en.toLowerCase().startsWith(query))
                            return -1;
                        if (b.en.toLowerCase().startsWith(query))
                            return 1;
                        return 0;
                    }
                    ).slice(0, 10);
                }
                clog(`[Autocomplete] Station autocomplete for '${elementId}', query: '${query}', found ${suggestions.length} suggestions.`);
                this.showSuggestions(input, suggestions, (s) => `${s.en} (${s.sc})`, (s) => s.sc);
            }
            , 300);
        }
        );

        input.addEventListener("blur", () => {
            setTimeout( () => {
                const existingBox = input.parentElement.querySelector('.autocomplete-suggestions');
                if (existingBox) {
                    existingBox.remove();
                    clog(`[Autocomplete] Station suggestions box removed on blur for '${elementId}'.`);
                }
            }
            , 200);
        }
        );
        clog(`[Autocomplete] Station autocomplete attached to element ID: ${elementId}.`);
    },

    attachTrainAutocomplete: function(elementId) {
        const input = document.getElementById(elementId);
        if (!input) {
            clog(`[Autocomplete] Input element not found for ID: ${elementId}.`);
            return;
        }

        let timeout = null;

        input.addEventListener("input", () => {
            clearTimeout(timeout);
            timeout = setTimeout( () => {
                const query = input.value.toLowerCase();
                let suggestions = [];
                if (query.length >= 2 && window.trainData) {
                    suggestions = window.trainData.filter(t => t.number.toLowerCase().includes(query) || t.name.toLowerCase().includes(query)).sort( (a, b) => {
                        if (a.number.toLowerCase() === query)
                            return -2;
                        if (b.number.toLowerCase() === query)
                            return 2;
                        if (a.number.toLowerCase().startsWith(query))
                            return -1;
                        if (b.number.toLowerCase().startsWith(query))
                            return 1;
                        if (a.name.toLowerCase().startsWith(query))
                            return -1;
                        if (b.name.toLowerCase().startsWith(query))
                            return 1;
                        return 0;
                    }
                    ).slice(0, 10);
                }
                clog(`[Autocomplete] Train autocomplete for '${elementId}', query: '${query}', found ${suggestions.length} suggestions.`);
                this.showSuggestions(input, suggestions, (t) => `${t.number} - ${t.name}`, (t) => t.number);
            }
            , 300);
        }
        );

        input.addEventListener("blur", () => {
            setTimeout( () => {
                const existingBox = input.parentElement.querySelector('.autocomplete-suggestions');
                if (existingBox) {
                    existingBox.remove();
                    clog(`[Autocomplete] Train suggestions box removed on blur for '${elementId}'.`);
                }
            }
            , 200);
        }
        );
        clog(`[Autocomplete] Train autocomplete attached to element ID: ${elementId}.`);
    },

    showSuggestions: function(inputElement, suggestions, textFormatter, valueSetter) {
        const parent = inputElement.parentElement;
        let existingBox = parent.querySelector('.autocomplete-suggestions');
        if (existingBox) {
            existingBox.remove();
        }

        if (suggestions.length === 0) {
            clog(`[Autocomplete] No suggestions to display for input "${inputElement.id}".`);
            return;
        }

        const suggestionBox = document.createElement("div");
        suggestionBox.classList.add("autocomplete-suggestions");

        suggestions.forEach(item => {
            const div = document.createElement("div");
            div.textContent = textFormatter(item);
            div.addEventListener("mousedown", (event) => {
                event.preventDefault();
                inputElement.value = valueSetter(item);
                suggestionBox.remove();
                if (typeof saveFormData === 'function')
                    saveFormData();
                clog(`[Autocomplete] Suggestion selected for "${inputElement.id}": "${inputElement.value}".`);
            }
            );
            suggestionBox.appendChild(div);
        }
        );
        parent.appendChild(suggestionBox);
        clog(`[Autocomplete] Displayed ${suggestions.length} suggestions for input "${inputElement.id}".`);
    },

    // PayTM QR Code Modal Display & WebSocket Handling
    showPayTMQR: function(base64Image, paytmActionUrl, paytmMid, callback, timeoutMs=600000) {
        let paymentSuccess = false;

        const existingSplash = document.getElementById("paytm-qr-splash");
        if (existingSplash) {
            existingSplash.remove();
            clog("[PayTM QR] Removed existing PayTM QR splash modal.");
        }

        const splashDiv = document.createElement("div");
        splashDiv.id = "paytm-qr-splash";
        splashDiv.setAttribute("role", "dialog");
        splashDiv.setAttribute("aria-modal", "true");
        splashDiv.setAttribute("aria-labelledby", "qr-title");

        const circleRadius = 23;
        const circumference = 2 * Math.PI * circleRadius;

        splashDiv.innerHTML = `
            <div class="starfield"></div>
            <div class="red-alert"></div>
            <div class="qr-card">
                <div class="qr-header">
                    <div class="qr-title">Origin</div>
                    <div class="qr-amount">₹ ${Math.ceil(window.totalCollectibleAmount)}</div>
                    <button class="qr-close" aria-label="Close payment dialog">✕</button>
                </div>
                <div class="qr-container">
                    <div class="qr-glow"></div>
                    <div class="qr-scan-line"></div>
                    <img src="data:image/png;base64,${base64Image}" alt="PayTM UPI QR Code">
                </div>
                <p class="qr-prompt">USE any QR Payment Scanner - Origin v1.0.27</p>
                <div class="qr-progress">
                    <svg viewBox="0 0 56 56">
                        <defs>
                            <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                <stop offset="0%" />
                                <stop offset="100%" />
                            </linearGradient>
                        </defs>
                        <circle cx="28" cy="28" r="${circleRadius}" class="progress-track" />
                        <circle class="progress-fill" cx="28" cy="28" r="${circleRadius}" 
                                style="stroke-dasharray: ${circumference}; stroke-dashoffset: ${circumference}; 
                                        animation-duration: ${timeoutMs}ms;" />
                    </svg>
                    <div class="countdown-text">${Math.floor(timeoutMs / 1000)}</div>
                </div>
            </div>
        `;
        document.body.appendChild(splashDiv);
        clog("[PayTM QR] PayTM QR modal created and appended to body.");

        const qrCloseBtn = splashDiv.querySelector(".qr-close");
        const redAlertDiv = splashDiv.querySelector(".red-alert");
        const qrProgressDiv = splashDiv.querySelector(".qr-progress");
        const countdownTextDiv = splashDiv.querySelector(".countdown-text");
        const progressFillCircle = splashDiv.querySelector(".qr-progress .progress-fill");

        progressFillCircle.style.strokeDashoffset = '0';
        progressFillCircle.style.animationName = 'progressCountdown';
        progressFillCircle.style.animationDuration = `${timeoutMs}ms`;
        progressFillCircle.style.animationTimingFunction = 'linear';
        progressFillCircle.style.animationFillMode = 'forwards';

        qrCloseBtn.onclick = () => {
            document.body.removeChild(splashDiv);
            if (window.paytmWebSocket) {
                if (window.paytmWebSocket.readyState === WebSocket.OPEN || window.paytmWebSocket.readyState === WebSocket.CONNECTING) {
                    window.paytmWebSocket.close(1000, "User cancelled");
                    clog("[PayTM QR] PayTM WebSocket explicitly closed by user.");
                }
            }
            clearInterval(window.paytmCountdownInterval);
            clearTimeout(window.paytmTimeoutTimer);
            if (window.paytmPollingInterval)
                clearInterval(window.paytmPollingInterval);

            if (!paymentSuccess) {
                clog("Paytm QR flow cancelled by user.");
                this.showMessage("Paytm QR payment flow cancelled.", "warning", 0);
                this.hideLoading();
            }
        }
        ;

        const focusableElements = [qrCloseBtn];
        if (focusableElements.length > 0) {
            focusableElements[0].focus();
            clog("[PayTM QR] Initial focus set to close button for accessibility.");
        }

        splashDiv.addEventListener("keydown", (e) => {
            if (e.key === "Escape") {
                qrCloseBtn.click();
            }
            if (e.key === "Tab") {
                if (document.activeElement === qrCloseBtn && !e.shiftKey) {
                    e.preventDefault();
                } else if (document.activeElement === qrCloseBtn && e.shiftKey) {
                    e.preventDefault();
                }
            }
        }
        );

        let remainingSeconds = timeoutMs / 1000;
        countdownTextDiv.textContent = remainingSeconds;
        window.paytmCountdownInterval = setInterval( () => {
            remainingSeconds--;
            countdownTextDiv.textContent = remainingSeconds;
            if (remainingSeconds <= 30 && !redAlertDiv.classList.contains("urgent")) {
                redAlertDiv.classList.add("urgent");
                qrProgressDiv.classList.add("urgent");
                clog("[PayTM QR] Countdown reached 30 seconds or less, urgent visual alert activated.");
            }
            if (remainingSeconds <= 0) {
                clearInterval(window.paytmCountdownInterval);
                qrCloseBtn.click();
                clog("Paytm QR countdown finished. Auto-closing modal.");
                this.showMessage("Paytm QR payment timed out.", "error", 0);
                this.hideLoading();
            }
        }
        , 1000);

        const extractOrderIdFromUrl = (url, mid) => {
            try {
                const urlObj = new URL(url);
                const orderId = urlObj.searchParams.get("orderid");
                if (!orderId)
                    throw new Error("orderid param missing");
                return mid + "_" + orderId;
            } catch (error) {
                clog("[PayTM QR] Error extracting orderId from URL:", error);
                return null;
            }
        }
        ;

        const paytmOrderId = extractOrderIdFromUrl(paytmActionUrl, paytmMid);
        if (!paytmOrderId) {
            clog("[PayTM QR] Missing room ID for WebSocket. Cannot initialize status check.");
            qrCloseBtn.click();
            this.showMessage("Could not initialize PayTM QR status check.", "error", 0);
            this.hideLoading();
            return;
        }

        const wsProtocol = location.protocol === "https:" ? "wss" : "ws";
        const wsUrl = `${wsProtocol}://secure.paytmpayments.com/websocket/?DEVICE=web&ID=${paytmOrderId}`;
        const paytmWS = new WebSocket(wsUrl);
        window.paytmWebSocket = paytmWS;
        clog(`[PayTM QR] Initiating WebSocket connection to: ${wsUrl}.`);

        let wsCid = 1;
        let handshakeComplete = false;
        let pollIntervalId = null;

        paytmWS.addEventListener("open", () => {
            clog("[PayTM QR WS] WebSocket opened. Sending handshake.");
            paytmWS.send(JSON.stringify({
                event: "#handshake",
                data: {
                    authToken: null
                },
                cid: wsCid++
            }));
        }
        );

        paytmWS.addEventListener("message", ({data: message}) => {
            let parsedData;
            try {
                parsedData = JSON.parse(message);
            } catch {
                clog("[PayTM QR WS] Received non-JSON message:", message);
                return;
            }

            if (parsedData.rid === wsCid - 1 && !handshakeComplete) {
                clog("[PayTM QR WS] Handshake successful. Joining room.");
                paytmWS.send(JSON.stringify({
                    event: "JOIN_ROOMS",
                    data: paytmOrderId
                }));
                handshakeComplete = true;
                wsCid++;
                pollIntervalId = setInterval( () => {
                    if (paytmWS.readyState === WebSocket.OPEN) {
                        paytmWS.send(JSON.stringify({
                            event: "#1",
                            data: {
                                roomId: paytmOrderId,
                                mid: paytmMid
                            },
                            cid: wsCid++
                        }));
                        clog(`[PayTM QR WS] Polling payment status for order ID: ${paytmOrderId}.`);
                    }
                }
                , 500);
                window.paytmPollingInterval = pollIntervalId;
            } else if (parsedData.event === paytmOrderId && parsedData.data) {
                clog("[PayTM QR WS] Payment status data received:", parsedData.data);
                paymentSuccess = true;
                window.paytmWSData = parsedData.data;

                clearInterval(pollIntervalId);
                clearInterval(window.paytmCountdownInterval);
                clearTimeout(window.paytmTimeoutTimer);

                if (paytmWS.readyState === WebSocket.OPEN) {
                    paytmWS.send(JSON.stringify({
                        event: "#disconnect",
                        data: {
                            code: 1000
                        }
                    }));
                    paytmWS.close();
                    clog("[PayTM QR WS] WebSocket gracefully disconnected after receiving payment status.");
                }

                qrCloseBtn.click();
                callback();
                clog("[PayTM QR WS] Callback triggered after successful payment status reception.");
            } else if (parsedData.event !== "#2") {
                clog("[PayTM QR WS] Received unexpected event:", parsedData.event);
            }
        }
        );

        paytmWS.addEventListener("error", (err) => {
            clog("❌ [PayTM QR WS] WebSocket error occurred:", err);
            clearInterval(pollIntervalId);
            clearInterval(window.paytmCountdownInterval);
            clearTimeout(window.paytmTimeoutTimer);
            if (paytmWS.readyState === WebSocket.OPEN)
                paytmWS.close();
            qrCloseBtn.click();
            this.showMessage("Paytm QR connection error. Please try again.", "error", 0);
            this.hideLoading();
        }
        );

        paytmWS.addEventListener("close", (event) => {
            clog(`[PayTM QR WS] WebSocket closed. Code: ${event.code}, Reason: ${event.reason}.`);
            clearInterval(pollIntervalId);
            if (event.code !== 1000 && event.code !== 1001) {
                if (!window.paytmWSData || !window.paytmWSData.status || window.paytmWSData.status !== "TXN_SUCCESS") {
                    clog("[PayTM QR WS] WebSocket closed unexpectedly before success status was received or payment processed.");
                }
            }
        }
        );

        window.paytmTimeoutTimer = setTimeout( () => {
            if ((paytmWS.readyState === WebSocket.OPEN || paytmWS.readyState === WebSocket.CONNECTING) && (!window.paytmWSData || !window.paytmWSData.status)) {
                clog("[PayTM QR WS] WebSocket timed out or no status received within the specified duration.");
                clearInterval(pollIntervalId);
                clearInterval(window.paytmCountdownInterval);
                if (paytmWS.readyState === WebSocket.OPEN)
                    paytmWS.close();
                qrCloseBtn.click();
                this.showMessage("Paytm QR payment timed out or failed to receive status.", "error", 0);
                this.hideLoading();
            }
        }
        , timeoutMs);
        clog(`[PayTM QR] PayTM QR modal displayed for MID: ${paytmMid}, URL: ${paytmActionUrl}. Timeout set for ${timeoutMs}ms.`);
    },

    showPhonePeQR: function(qrCodeBase64, timeoutMs=600000) {
        if (document.getElementById("phonepe-qr-splash"))
            return;

        const splash = document.createElement("div");
        splash.id = "phonepe-qr-splash";
        splash.setAttribute("role", "dialog");
        splash.setAttribute("aria-modal", "true");
        splash.setAttribute("aria-labelledby", "qr-title");

        const countdownSeconds = Math.floor(timeoutMs / 1000);
        const circleRadius = 23;
        const circumference = 2 * Math.PI * circleRadius;

        splash.innerHTML = `
            <div class="starfield"></div>
            <div class="red-alert"></div>
            <div class="qr-card">
                <div class="qr-particles">
                    ${Array.from({
            length: 8
        }, () => `<div style="left: ${Math.random() * 100}%; animation-delay: ${Math.random() * 6}s;"></div>`).join('')}
                </div>
                <div class="qr-header">
                    <div class="qr-title">Origin</div>
                    <div class="qr-amount">₹ ${Math.ceil(window.totalCollectibleAmount)}</div>
                    <button class="qr-close" aria-label="Close payment dialog">✕</button>
                </div>
                <div class="qr-container">
                    <div class="qr-glow"></div>
                    <div class="qr-scan-line"></div>
                    <img src="data:image/png;base64,${qrCodeBase64}" alt="PhonePe UPI QR Code">
                </div>
                <p class="qr-prompt">USE any QR Payment Scanner - Origin v1.0.27</p>
                <div class="qr-progress">
                    <svg viewBox="0 0 56 56">
                        <defs>
                            <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                <stop offset="0%" />
                                <stop offset="100%" />
                            </linearGradient>
                        </defs>
                        <circle cx="28" cy="28" r="${circleRadius}" />
                        <circle class="progress-fill" cx="28" cy="28" r="${circleRadius}" style="stroke-dasharray: ${circumference}; stroke-dashoffset: ${circumference}; animation-duration: ${timeoutMs}ms;" />
                    </svg>
                    <div class="countdown-text">${countdownSeconds}</div>
                </div>
            </div>
        `;
        document.body.appendChild(splash);
        clog("[PhonePe QR] PhonePe QR modal created and appended to body.");

        const closeBtn = splash.querySelector(".qr-close");
        const redAlertEl = splash.querySelector(".red-alert");
        const progressEl = splash.querySelector(".qr-progress");
        const countdownTextEl = splash.querySelector(".countdown-text");
        const progressFillCircle = splash.querySelector(".qr-progress .progress-fill");

        // Start animation
        progressFillCircle.style.strokeDashoffset = '0';
        progressFillCircle.style.animationName = 'progressCountdown';
        progressFillCircle.style.animationDuration = `${timeoutMs}ms`;
        progressFillCircle.style.animationTimingFunction = 'linear';
        progressFillCircle.style.animationFillMode = 'forwards';

        let countdownInterval = null;

        const closeQRModal = () => {
            if (document.getElementById("phonepe-qr-splash")) {
                document.body.removeChild(splash);
                clearInterval(countdownInterval);
                clog("[UI] PhonePe QR modal closed.");
            }
        }
        ;

        window.closePhonePeQR = closeQRModal;
        // Expose the close function

        closeBtn.addEventListener('click', closeQRModal);

        let remainingSeconds = timeoutMs / 1000;
        countdownTextEl.textContent = remainingSeconds;
        countdownInterval = setInterval( () => {
            remainingSeconds--;
            if (remainingSeconds >= 0) {
                countdownTextEl.textContent = remainingSeconds;
                if (remainingSeconds <= 30) {
                    redAlertEl.classList.add("urgent");
                    progressEl.classList.add("urgent");
                }
            } else {
                closeQRModal();
            }
        }
        , 1000);
    },

    showIrctcQR: function(qrCodeBase64, timeoutMs=600000) {
        if (document.getElementById("irctc-qr-splash"))
            return;

        const splash = document.createElement("div");
        splash.id = "irctc-qr-splash";
        splash.setAttribute("role", "dialog");
        splash.setAttribute("aria-modal", "true");
        splash.setAttribute("aria-labelledby", "qr-title");

        const countdownSeconds = Math.floor(timeoutMs / 1000);
        const circleRadius = 23;
        const circumference = 2 * Math.PI * circleRadius;

        splash.innerHTML = `
            <div class="starfield"></div>
            <div class="red-alert"></div>
            <div class="qr-card">
                <div class="qr-particles">
                    ${Array.from({
            length: 8
        }, () => `<div style="left: ${Math.random() * 100}%; animation-delay: ${Math.random() * 6}s;"></div>`).join('')}
                </div>
                <div class="qr-header">
                    <div class="qr-title">Origin</div>
                    <div class="qr-amount">₹ ${Math.ceil(window.totalCollectibleAmount)}</div>
                    <button class="qr-close" aria-label="Close payment dialog">✕</button>
                </div>
                <div class="qr-container">
                    <div class="qr-glow"></div>
                    <div class="qr-scan-line"></div>
                    <img src="${qrCodeBase64}" alt="IRCTC iPay UPI QR Code">
                </div>
                <p class="qr-prompt">USE any QR Payment Scanner - Origin v1.0.27</p>
                <div class="qr-progress">
                    <svg viewBox="0 0 56 56">
                        <defs>
                            <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                <stop offset="0%" />
                                <stop offset="100%" />
                            </linearGradient>
                        </defs>
                        <circle cx="28" cy="28" r="${circleRadius}" />
                        <circle class="progress-fill" cx="28" cy="28" r="${circleRadius}" style="stroke-dasharray: ${circumference}; stroke-dashoffset: ${circumference}; animation-duration: ${timeoutMs}ms;" />
                    </svg>
                    <div class="countdown-text">${countdownSeconds}</div>
                </div>
            </div>
        `;
        document.body.appendChild(splash);
        clog("[IRCTC QR] IRCTC QR modal created and appended to body.");

        const closeBtn = splash.querySelector(".qr-close");
        const redAlertEl = splash.querySelector(".red-alert");
        const progressEl = splash.querySelector(".qr-progress");
        const countdownTextEl = splash.querySelector(".countdown-text");
        const progressFillCircle = splash.querySelector(".qr-progress .progress-fill");

        progressFillCircle.style.strokeDashoffset = '0';
        progressFillCircle.style.animationName = 'progressCountdown';
        progressFillCircle.style.animationDuration = `${timeoutMs}ms`;
        progressFillCircle.style.animationTimingFunction = 'linear';
        progressFillCircle.style.animationFillMode = 'forwards';

        let countdownInterval = null;

        const closeQRModal = () => {
            if (document.getElementById("irctc-qr-splash")) {
                document.body.removeChild(splash);
                clearInterval(countdownInterval);
                clog("[UI] IRCTC QR modal closed.");
            }
        }
        ;

        window.closeIrctcQR = closeQRModal;
        // Expose the close function

        closeBtn.addEventListener('click', () => {
            window.isBookingStopped = true;
            // Stop polling if user manually closes
            closeQRModal();
        }
        );

        let remainingSeconds = timeoutMs / 1000;
        countdownTextEl.textContent = remainingSeconds;
        countdownInterval = setInterval( () => {
            remainingSeconds--;
            if (remainingSeconds >= 0) {
                countdownTextEl.textContent = remainingSeconds;
                if (remainingSeconds <= 30) {
                    redAlertEl.classList.add("urgent");
                    progressEl.classList.add("urgent");
                }
            } else {
                closeQRModal();
            }
        }
        , 1000);
    },

    // Booking Info Display
    displayBookingInfo: async function(bookingData, els) {
        this.hideLoading();
        this.hideErrorMessage();
        this.showMessage("Your ticket has been booked!", "success", 0);
        clog("[UI Booking Info] Initiating display of booking success page.");

        const paymentMethodUsed = els.paymentMethod.value.toUpperCase();
        const usernameLoggedIn = els.username.value.toUpperCase();
        const bookingResponses = bookingData?.bookingResponseDTO || [];

        if (!bookingResponses.length) {
            clog("[UI Booking Info] No booking response found for display.");
            this.showMessage("No booking details available to display.", "error", 0);
            return;
        }

        const mainBooking = bookingResponses[0];
        const pnrNumber = mainBooking.pnrNumber || "N/A";
        const boardingStationName = mainBooking.boardingStnName || "N/A";
        const reservationUptoStationName = mainBooking.resvnUptoStnName || "N/A";
        const bookingDateTime = mainBooking.bookingDate ? new Date(mainBooking.bookingDate) : null;

        const bookingTime = bookingDateTime ? bookingDateTime.toLocaleTimeString("en-IN", {
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
            hour12: true,
            timeZone: "Asia/Kolkata"
        }) : "N/A";
        const bookedQuota = mainBooking.bookedQuota || "N/A";
        const journeyDate = (mainBooking.boardingDate || "").split("T")[0] || "N/A";
        const trainName = mainBooking.trainName || "N/A";
        const trainNumber = mainBooking.trainNumber || "N/A";
        const journeyClass = mainBooking.journeyClass || "N/A";
        const passengersList = mainBooking.psgnDtlList || [];
        const isConfirmed = passengersList.some(p => p.bookingStatusDetails?.toUpperCase().includes("CNF"));

        await this.hideAllPageContent();
        clog("[UI Booking Info] All existing page content hidden.");

        let successPageContainer = document.getElementById("success-page-container");
        if (!successPageContainer) {
            successPageContainer = document.createElement("div");
            successPageContainer.id = "success-page-container";
            successPageContainer.className = "success-page-container";
            successPageContainer.tabIndex = -1;
            document.body.appendChild(successPageContainer);
            clog("[UI Booking Info] Created new success page container.");
        } else {
            successPageContainer.innerHTML = "";
            successPageContainer.className = "success-page-container";
            clog("[UI Booking Info] Cleared and reset existing success page container.");
        }

        const passengerRowsHTML = passengersList.map( (p, index) => {
            const statusClass = p.bookingStatusDetails?.toUpperCase().includes("CNF") ? "status-confirmed" : "status-waitlisted";
            return `
                <tr>
                    <td>${index + 1}</td>
                    <td class="sensitive passenger-name">${p.passengerName || "N/A"}</td>
                    <td class="sensitive passenger-age">${p.passengerAge || "N/A"}</td>
                    <td>
                        <span class="sensitive booking-status ${statusClass}">
                            ${p.bookingStatusDetails}
                        </span>
                    </td>
                </tr>
            `;
        }
        ).join("");

        successPageContainer.innerHTML = `
            <div class="container">
                <div class="premium-header-top">
                    <span class="premium-logo">Origin</span>
                    <p class="premium-slogan">Book with <span class="blazing-text">BLAZING</span> speed</p>
                </div>
                <div class="success-card">
                <br><br>
                    <div class="success-header">
                        <div class="success-icon">
                            <img src="https://speedxorigin.vercel.app/pnr_status.png" alt="PNR Logo">
                        </div>
                        <h2 class="success-title">Booking ${isConfirmed ? "Confirmed" : "Waitlisted"} - By Origin</h2>
                        <p class="success-subtitle">Your train ticket has been successfully booked!</p>
                    </div>
                    
                    <div class="booking-details">
                        <div class="detail-section">
                            <h3 class="section-title">Journey Details</h3>
                            <div class="detail-grid">
                                <div class="detail-item">
                                    <div class="detail-label">PNR Number</div>
                                    <div class="detail-value sensitive pnr-number">${pnrNumber}</div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-label">Train</div>
                                    <div class="detail-value sensitive train-number">${trainName} (${trainNumber})</div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-label">Class</div>
                                    <div class="detail-value">${journeyClass}</div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-label">Quota</div>
                                    <div class="detail-value">${bookedQuota}</div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-label">From</div>
                                    <div class="detail-value">${boardingStationName}</div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-label">To</div>
                                    <div class="detail-value">${reservationUptoStationName}</div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-label">Journey Date</div>
                                    <div class="detail-value">${journeyDate}</div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-label">Booking Time</div>
                                    <div class="detail-value">${bookingTime}</div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-label">Payment Method</div>
                                    <div class="detail-value paymentmethod">${paymentMethodUsed}</div>
                                </div>
                                <div class="detail-item">
                                    <div class="detail-label">Login ID</div>
                                    <div class="detail-value sensitive username">${usernameLoggedIn}</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="detail-section">
                            <h3 class="section-title">Passenger Information</h3>
                            <div class="passengers-section">
                                <table class="passengers-table">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>Passenger Name</th>
                                            <th>Age</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${passengerRowsHTML}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <div class="action-buttons">
                        <a href="https://www.irctc.co.in/eticketing/printTicket.jsp?pnr=${pnrNumber}" target="_blank" class="btn btn-primary">
                            \uD83D\uDCF1 Download Ticket
                        </a>
                        <button class="btn btn-secondary share-button">
                            \uD83D\uDD17 Share Details
                        </button>
                    </div>
                </div>
            </div>
        `;

        successPageContainer.classList.add('visible');

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
        successPageContainer.focus();
        clog("[UI Booking Info] Booking success page displayed. Scrolled to top and focused container.");

        const shareButton = successPageContainer.querySelector(".share-button");
        let isRedacted = false;
        shareButton.addEventListener("click", () => {
            isRedacted = !isRedacted;
            successPageContainer.querySelectorAll(".sensitive").forEach(el => {
                if (isRedacted) {
                    el.classList.add("redacted");
                    el.setAttribute("data-original", el.textContent);
                    el.textContent = "";
                    el.classList.add("active");
                    clog(`[UI Booking Info] Redacted sensitive element: ${el.className}.`);
                } else {
                    el.classList.remove("redacted", "active");
                    el.textContent = el.getAttribute("data-original");
                    clog(`[UI Booking Info] Unredacted sensitive element: ${el.className}.`);
                }
            }
            );
            shareButton.textContent = isRedacted ? "Show Details" : "Share Details";
            clog(`[UI Booking Info] Share button toggled. State: ${isRedacted ? 'Redacted' : 'Visible'}.`);
        }
        );
        clog("[UI Booking Info] Booking success page displayed with new UI. PNR: " + pnrNumber);
    },

    // Helper to hide all main page content
    hideAllPageContent: async function() {
        const elementsToHideSelectors = ["#stepsCard", "#availabilityStatusPane", "#main", "#header", "#nav", "#bookingForm", "#loginForm", "#passengerForm", "#paymentForm", ".top-bar", ".bottom-bar"];

        const allSelectors = elementsToHideSelectors.join(', ');

        document.querySelectorAll(allSelectors).forEach(el => {
            if (el) {
                el.style.display = "none";
                clog(`[UI Hide Content] Hidden element by selector: ${el.id || el.className}.`);
            }
        }
        );

        document.querySelectorAll("body > *:not(#paytm-qr-splash):not(#phonepe-qr-splash):not(#success-page-container):not(#loadingOverlay):not(#notificationPane):not(#countdownPopup)").forEach(el => {
            if (el.tagName !== 'SCRIPT' && el.tagName !== 'STYLE' && el.tagName !== 'LINK') {
                el.style.display = "none";
                clog(`[UI Hide Content] Hidden direct body child: ${el.tagName} ${el.id || el.className}.`);
            }
        }
        );

        clog("[UI Hide Content] All main page content hidden for full-screen display.");
    }
};